/**
 * InspireConnect progressive enhancement.
 *
 * Everything here is optional: every form, filter and action works with
 * JavaScript disabled. This layer only adds comfort (drawers, confirms, copy,
 * strength meters, loading states).
 */
(function () {
  'use strict';

  var doc = document;

  /* ------------------------------ mobile nav ----------------------------- */

  var sidebar = doc.querySelector('[data-sidebar]');
  var scrim = doc.querySelector('.sidebar-scrim');

  function setSidebar(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('is-open', open);
    if (scrim) scrim.hidden = !open;
    doc.body.style.overflow = open && window.innerWidth <= 1024 ? 'hidden' : '';
  }

  doc.addEventListener('click', function (event) {
    if (event.target.closest('[data-sidebar-open]')) { setSidebar(true); return; }
    if (event.target.closest('[data-sidebar-close]')) { setSidebar(false); return; }
  });

  doc.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      setSidebar(false);
      doc.querySelectorAll('details[open]').forEach(function (d) { d.open = false; });
    }
  });

  /* ------------------------------- confirms ------------------------------ */

  doc.addEventListener('submit', function (event) {
    var form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    var button = form.querySelector('[data-confirm]') || (event.submitter && event.submitter.matches('[data-confirm]') ? event.submitter : null);
    var message = (event.submitter && event.submitter.getAttribute('data-confirm')) || (button && button.getAttribute('data-confirm'));
    if (message && !window.confirm(message)) {
      event.preventDefault();
      return;
    }
    // Loading state so double submits cannot happen.
    var submitter = event.submitter || form.querySelector('button[type="submit"]');
    if (submitter && !submitter.disabled) {
      submitter.classList.add('is-loading');
      window.setTimeout(function () { submitter.classList.remove('is-loading'); }, 8000);
    }
  });

  /* -------------------------------- copying ------------------------------ */

  doc.addEventListener('click', function (event) {
    var trigger = event.target.closest('[data-copy]');
    if (!trigger) return;
    var selector = trigger.getAttribute('data-copy');
    var input = selector ? doc.querySelector(selector) : null;
    if (!input) return;
    event.preventDefault();
    var value = input.value || input.textContent || '';
    var done = function () {
      var original = trigger.innerHTML;
      trigger.innerHTML = 'Copied';
      window.setTimeout(function () { trigger.innerHTML = original; }, 1600);
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(value).then(done, function () { fallbackCopy(input, done); });
    } else {
      fallbackCopy(input, done);
    }
  });

  function fallbackCopy(input, done) {
    input.removeAttribute('readonly');
    input.select();
    input.setSelectionRange(0, 99999);
    try { doc.execCommand('copy'); done(); } catch (error) { /* clipboard unavailable */ }
    input.setAttribute('readonly', 'readonly');
  }

  /* --------------------------- dynamic theming --------------------------- */

  // Subject colours arrive as data-chip-colour attributes and are applied here
  // through the CSSOM. Setting a custom property this way is not affected by the
  // strict Content-Security-Policy, which forbids inline style attributes.
  doc.querySelectorAll('[data-chip-colour]').forEach(function (el) {
    var colour = (el.getAttribute('data-chip-colour') || '').trim();
    if (/^#[0-9a-f]{3,8}$/i.test(colour)) {
      el.style.setProperty('--chip-colour', colour);
    }
  });

  /* --------------------------------- toasts ------------------------------ */

  function wireToast(toast) {
    var close = toast.querySelector('[data-dismiss]');
    if (close) {
      close.addEventListener('click', function () { toast.remove(); });
    }
  }

  doc.querySelectorAll('[data-toast]').forEach(function (toast) {
    wireToast(toast);
    if (!toast.classList.contains('toast--danger')) {
      window.setTimeout(function () {
        toast.style.transition = 'opacity 0.25s ease';
        toast.style.opacity = '0';
        window.setTimeout(function () { toast.remove(); }, 260);
      }, 7000);
    }
  });

  doc.querySelectorAll('.alert__close').forEach(function (close) {
    close.addEventListener('click', function () {
      var alert = close.closest('.alert');
      if (alert) alert.remove();
    });
  });

  /* ------------------------------ menus/drawers -------------------------- */

  doc.addEventListener('click', function (event) {
    doc.querySelectorAll('details.menu[open]').forEach(function (menu) {
      if (!menu.contains(event.target)) menu.open = false;
    });
  });

  /* --------------------------- password strength ------------------------- */

  var strengthInput = doc.querySelector('[data-password-strength]');
  var strengthBox = doc.querySelector('[data-strength]');
  if (strengthInput && strengthBox) {
    var fill = strengthBox.querySelector('[data-strength-fill]');
    var label = strengthBox.querySelector('[data-strength-label]');
    strengthInput.addEventListener('input', function () {
      var value = strengthInput.value;
      strengthBox.hidden = !value;
      var score = 0;
      if (value.length >= 10) score += 1;
      if (value.length >= 14) score += 1;
      if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score += 1;
      if (/\d/.test(value)) score += 1;
      if (/[^\w\s]/.test(value)) score += 1;
      var labels = ['Very weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'];
      var colours = ['#c0362c', '#c0362c', '#b06f00', '#b06f00', '#0f8a5f', '#0f8a5f'];
      if (fill) {
        fill.style.width = Math.round((score / 5) * 100) + '%';
        fill.style.background = colours[score] || '#c0362c';
      }
      if (label) label.textContent = labels[score] || 'Weak';
    });
  }

  /* ------------------------------ table search --------------------------- */

  var tableSearch = doc.querySelector('[data-table-search]');
  if (tableSearch) {
    tableSearch.addEventListener('input', function () {
      var needle = tableSearch.value.trim().toLowerCase();
      var table = doc.querySelector(tableSearch.getAttribute('data-table-search'));
      if (!table) return;
      table.querySelectorAll('tbody tr').forEach(function (row) {
        row.hidden = needle.length > 0 && !row.textContent.toLowerCase().includes(needle);
      });
    });
  }
})();
