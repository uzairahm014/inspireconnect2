/**
 * End-to-end tests. These drive the real HTTP server, real sessions, real CSRF
 * checks and a real SQLite database, so they verify behaviour rather than
 * implementation details.
 */
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { client, csrfFrom, form, loginAsAdmin, startServer, ADMIN_PASSWORD, STRONG_PASSWORD } from './helpers.mjs';

let app;
let db;
let admin;
const created = {};

before(async () => {
  app = await startServer();
  db = await import('../src/db.mjs');
  admin = await loginAsAdmin(client(app.base));
});

after(async () => {
  await app.close();
});

const q = (sql, params = []) => db.get(sql, params);
const all = (sql, params = []) => db.all(sql, params);

/* -------------------------------------------------------------------------- */
/* Authentication & session security                                          */
/* -------------------------------------------------------------------------- */

test('unauthenticated visitors are redirected to sign-in, never to a dashboard', async () => {
  const c = client(app.base);
  const res = await c.get('/admin');
  assert.equal(res.status, 303);
  assert.match(res.location, /^\/login/);

  const tutorRes = await c.get('/tutor');
  assert.equal(tutorRes.status, 303);
  assert.match(tutorRes.location, /^\/login/);
});

test('the sign-in page never exposes the administrator password and is CSRF protected', async () => {
  const c = client(app.base);
  const page = await c.get('/login');
  assert.equal(page.status, 200);
  assert.doesNotMatch(page.html, /inspire/, 'the initial password must not appear in the UI');
  assert.match(page.html, /invitation only/i);

  const noToken = await c.post('/login', form({ identifier: 'admin', password: 'wrong' }));
  assert.equal(noToken.status, 403, 'a login without a CSRF token is rejected');
});

test('bad credentials are rejected and recorded', async () => {
  const c = client(app.base);
  const page = await c.get('/login');
  const res = await c.post('/login', form({ _csrf: csrfFrom(page.html), identifier: 'admin', password: 'definitely-wrong' }));
  assert.equal(res.status, 200);
  assert.match(res.html, /do not match our records/);
  const attempts = all('SELECT * FROM login_attempts WHERE success = 0');
  assert.ok(attempts.length >= 1, 'failed sign-in is logged');
});

test('a new administrator must change their password before the dashboard opens', async () => {
  // The harness has already completed this forced change for the seeded account,
  // so prove the gate with a fresh administrator created through the real UI.
  const csrf = csrfFrom((await admin.get('/admin/admins/new')).html);
  const made = await admin.post('/admin/admins', form({
    _csrf: csrf, username: 'gate.admin', email: 'gate@example.com', role: 'admin',
    status: 'active', password: STRONG_PASSWORD, password_confirm: STRONG_PASSWORD,
  }));
  assert.equal(made.status, 303);

  const gateAccount = q('SELECT * FROM users WHERE username = ?', ['gate.admin']);
  assert.ok(gateAccount, 'the administrator is created');
  assert.equal(gateAccount.must_change_password, 1, 'a new account starts awaiting a password change');

  const gate = client(app.base);
  const page = await gate.get('/login');
  const signedIn = await gate.post('/login', form({ _csrf: csrfFrom(page.html), identifier: 'gate.admin', password: STRONG_PASSWORD }));
  assert.equal(signedIn.status, 303);

  const blocked = await gate.get('/admin');
  assert.equal(blocked.status, 303);
  assert.equal(blocked.location, '/account/password', 'the dashboard stays closed until the password is changed');

  const change = await gate.get('/account/password');
  assert.equal(change.status, 200);
  const saved = await gate.post('/account/password', form({
    _csrf: csrfFrom(change.html),
    current_password: STRONG_PASSWORD,
    password: `${STRONG_PASSWORD}-gate`,
    password_confirm: `${STRONG_PASSWORD}-gate`,
  }));
  assert.equal(saved.status, 303);
  assert.equal(q('SELECT must_change_password FROM users WHERE id = ?', [gateAccount.id]).must_change_password, 0);
  assert.equal((await gate.get('/admin')).status, 200, 'the dashboard opens once the password has been changed');
});

test('the original seeded password stops working once it has been changed', async () => {
  const c = client(app.base);
  const page = await c.get('/login');
  const res = await c.post('/login', form({ _csrf: csrfFrom(page.html), identifier: 'admin', password: ADMIN_PASSWORD }));
  assert.equal(res.status, 200);
  assert.match(res.html, /do not match our records/i);
  assert.equal(q('SELECT COUNT(*) AS c FROM users WHERE username = ?', ['admin']).c, 1, 'the account still exists');
  assert.equal(q('SELECT must_change_password FROM users WHERE username = ?', ['admin']).must_change_password, 0);
});

test('the administrator dashboard loads with live statistics', async () => {
  const res = await admin.get('/admin');
  assert.equal(res.status, 200);
  assert.match(res.html, /Dashboard/);
  assert.match(res.html, /Tutors/);
  assert.match(res.html, /Sessions this week/);
  assert.match(res.html, /Quick actions|Schedule session/);
});

/* -------------------------------------------------------------------------- */
/* Subjects                                                                   */
/* -------------------------------------------------------------------------- */

test('administrators can add, rename and disable subjects', async () => {
  const subjects = await admin.get('/admin/subjects');
  const csrf = csrfFrom(subjects.html);
  const created1 = await admin.post('/admin/subjects', form({ _csrf: csrf, name: 'Geography', colour: '#0ea5e9', description: 'Physical and human geography' }));
  assert.equal(created1.status, 303);

  const subject = q('SELECT * FROM subjects WHERE name = ?', ['Geography']);
  assert.ok(subject, 'subject stored');
  created.subjectId = subject.id;

  const rename = await admin.post(`/admin/subjects/${subject.id}`, form({
    _csrf: csrf, name: 'Geography & Geology', colour: '#0ea5e9', description: 'Updated', sort_order: 5,
  }));
  assert.equal(rename.status, 303);
  assert.equal(q('SELECT name FROM subjects WHERE id = ?', [subject.id]).name, 'Geography & Geology');

  await admin.post(`/admin/subjects/${subject.id}`, form({ _csrf: csrf, name: 'Geography & Geology', active: '' }));
  assert.equal(q('SELECT active FROM subjects WHERE id = ?', [subject.id]).active, 0, 'subject can be disabled');

  await admin.post(`/admin/subjects/${subject.id}`, form({ _csrf: csrf, name: 'Geography & Geology', colour: '#0ea5e9', active: '1' }));
  assert.equal(q('SELECT active FROM subjects WHERE id = ?', [subject.id]).active, 1);
});

test('duplicate subject names are refused and unused subjects can be deleted', async () => {
  const csrf = csrfFrom((await admin.get('/admin/subjects')).html);

  const dupe = await admin.post('/admin/subjects', form({ _csrf: csrf, name: 'maths' }));
  assert.equal(dupe.status, 303);
  assert.equal(all("SELECT id FROM subjects WHERE name = 'Maths' COLLATE NOCASE").length, 1, 'duplicate names are rejected case-insensitively');

  await admin.post('/admin/subjects', form({ _csrf: csrf, name: 'Latin' }));
  const latin = q("SELECT id FROM subjects WHERE name = 'Latin'");
  assert.ok(latin, 'an unused subject was created');
  const del = await admin.post(`/admin/subjects/${latin.id}/delete`, form({ _csrf: csrf }));
  assert.equal(del.status, 303);
  assert.equal(q('SELECT id FROM subjects WHERE id = ?', [latin.id]), undefined, 'an unused subject is deleted');
});

/* -------------------------------------------------------------------------- */
/* Secure invitation registration                                             */
/* -------------------------------------------------------------------------- */

test('only administrators can create invitations and the link is single-use', async () => {
  const csrf = csrfFrom((await admin.get('/admin/invitations/new')).html);
  const res = await admin.post('/admin/invitations', form({
    _csrf: csrf, role: 'tutor', email: 'invited.tutor@example.com', full_name: 'Invited Tutor',
    expires_hours: 48, subjects: [q("SELECT id FROM subjects WHERE name = 'Maths'").id],
  }));
  assert.equal(res.status, 200);
  const link = /(\/register\/[A-Za-z0-9_-]{20,})/.exec(res.html);
  assert.ok(link, 'registration link is shown once');
  created.inviteToken = link[1];

  const invitation = q('SELECT * FROM invitations WHERE email = ?', ['invited.tutor@example.com']);
  assert.ok(invitation.token_hash);
  assert.ok(!invitation.token_hash.includes(link[1]), 'only the token hash is stored');
  created.tutorInviteUrl = link[1];
});

test('an invited tutor can register, choose subjects and set their own password', async () => {
  const tutorClient = client(app.base);
  const page = await tutorClient.get(created.tutorInviteUrl);
  assert.equal(page.status, 200);
  assert.match(page.html, /Create your tutor account/);
  assert.match(page.html, /single use|only be used once/i);

  const subjects = all("SELECT id FROM subjects WHERE active = 1").map((s) => s.id);
  const res = await tutorClient.post(created.tutorInviteUrl, form({
    _csrf: csrfFrom(page.html),
    full_name: 'Invited Tutor',
    preferred_name: 'Inv',
    phone: '07700 900999',
    qualifications: 'BSc Physics',
    experience: '3 years',
    subjects,
    password: STRONG_PASSWORD,
    password_confirm: STRONG_PASSWORD,
    avail_day_0: 2, avail_from_0: '16:00', avail_to_0: '18:00',
    avail_day_1: 4, avail_from_1: '16:00', avail_to_1: '19:00',
  }));
  assert.equal(res.status, 303);
  assert.equal(res.location, '/tutor', 'registration signs the tutor straight in');

  const user = q('SELECT * FROM users WHERE email = ?', ['invited.tutor@example.com']);
  assert.ok(user, 'account created');
  assert.equal(user.role, 'tutor');
  assert.equal(user.status, 'active');
  assert.ok(user.password_hash.startsWith('scrypt$'));
  assert.ok(!user.password_hash.includes(STRONG_PASSWORD), 'password is never stored in plain text');
  created.tutorId = user.id;
  created.tutorClient = tutorClient;

  const invite = q('SELECT * FROM invitations WHERE id = ?', [q('SELECT invitation_id FROM users WHERE id = ?', [user.id]).invitation_id]);
  assert.ok(invite.used_at, 'invitation is marked used');

  const teachSubjects = all('SELECT subject_id FROM user_subjects WHERE user_id = ? AND kind = ?', [user.id, 'teach']);
  assert.equal(teachSubjects.length, subjects.length);
  const availability = all('SELECT * FROM availability WHERE user_id = ?', [user.id]);
  assert.equal(availability.length, 2, 'optional availability captured at registration');
  assert.equal(availability[0].start_min, 16 * 60);
});

test('a subject in use cannot be deleted, only disabled', async () => {
  const csrf = csrfFrom((await admin.get('/admin/subjects')).html);
  const maths = q("SELECT id FROM subjects WHERE name = 'Maths'");
  assert.ok(q('SELECT COUNT(*) AS c FROM user_subjects WHERE subject_id = ?', [maths.id]).c > 0, 'the tutor registration put Maths in use');

  const del = await admin.post(`/admin/subjects/${maths.id}/delete`, form({ _csrf: csrf }));
  assert.equal(del.status, 303);
  assert.ok(q('SELECT id FROM subjects WHERE id = ?', [maths.id]), 'the in-use subject still exists');

  const page = await admin.get('/admin/subjects');
  assert.match(page.html, /in use by tutors, tutees, assignments or sessions/i, 'the administrator is told why');
  assert.ok(q('SELECT id FROM subjects WHERE id = ?', [maths.id]), 'and it was not removed by the attempted delete');
});

test('a used invitation cannot be reused and shows the right message', async () => {
  const c = client(app.base);
  const res = await c.get(created.tutorInviteUrl);
  assert.equal(res.status, 200);
  assert.match(res.html, /already been used/i);

  const blocked = all("SELECT action FROM audit_log WHERE action = 'registration_blocked'");
  assert.ok(blocked.length >= 1, 'blocked attempts are audited');
});

test('expired, revoked and invalid invitations are refused with clear messages', async () => {
  const csrf = csrfFrom((await admin.get('/admin/invitations/new')).html);
  await admin.post('/admin/invitations', form({ _csrf: csrf, role: 'tutee', email: 'revoked.tutee@example.com', expires_hours: 24 }));
  const pending = q('SELECT * FROM invitations WHERE email = ?', ['revoked.tutee@example.com']);
  await admin.post(`/admin/invitations/${pending.id}/revoke`, form({ _csrf: csrf }));

  // Revoke issues a fresh token internally; force a known raw token to test the page.
  const { sha256, randomToken } = await import('../src/util.mjs');
  const token = randomToken(32);
  db.run('UPDATE invitations SET token_hash = ?, revoked_at = datetime(\'now\') WHERE id = ?', [sha256(token), pending.id]);
  const revoked = await client(app.base).get(`/register/${token}`);
  assert.match(revoked.html, /revoked/i);

  const expiredToken = randomToken(32);
  db.run('UPDATE invitations SET token_hash = ?, revoked_at = NULL, expires_at = datetime(\'now\', \'-1 hour\') WHERE id = ?', [sha256(expiredToken), pending.id]);
  const expired = await client(app.base).get(`/register/${expiredToken}`);
  assert.match(expired.html, /expired/i);

  const invalid = await client(app.base).get(`/register/${randomToken(32)}`);
  assert.match(invalid.html, /not valid/i);
});

test('registration validation blocks weak passwords, duplicates and missing subjects', async () => {
  const csrf = csrfFrom((await admin.get('/admin/invitations/new')).html);
  const res = await admin.post('/admin/invitations', form({
    _csrf: csrf, role: 'tutee', email: 'validation.tutee@example.com', full_name: 'Validation Tutee', expires_hours: 24,
  }));
  const link = /(\/register\/[A-Za-z0-9_-]{20,})/.exec(res.html)[1];

  const c = client(app.base);
  const page = await c.get(link);
  const bad = await c.post(link, form({
    _csrf: csrfFrom(page.html), full_name: 'Validation Tutee', password: 'short', password_confirm: 'short',
  }));
  assert.equal(bad.status, 200);
  assert.match(bad.html, /at least 10 characters/i);
  assert.match(bad.html, /Select at least one subject/i);
  assert.equal(q('SELECT COUNT(*) AS c FROM users WHERE email = ?', ['validation.tutee@example.com']).c, 0, 'no account created on invalid input');

  const mismatch = await c.post(link, form({
    _csrf: csrfFrom(page.html), full_name: 'Validation Tutee', password: STRONG_PASSWORD, password_confirm: 'Other-Password1',
    subjects: [q("SELECT id FROM subjects WHERE name = 'Science'").id],
  }));
  assert.match(mismatch.html, /do not match/i);

  const good = await c.post(link, form({
    _csrf: csrfFrom(page.html), full_name: 'Validation Tutee', preferred_name: 'Val', year_level: 'Year 8',
    subjects: [q("SELECT id FROM subjects WHERE name = 'Science'").id],
    password: STRONG_PASSWORD, password_confirm: STRONG_PASSWORD,
  }));
  assert.equal(good.status, 303);
  assert.equal(good.location, '/student');
  created.tuteeId = q('SELECT id FROM users WHERE email = ?', ['validation.tutee@example.com']).id;
  created.tuteeClient = c;
});

/* -------------------------------------------------------------------------- */
/* Role separation & RBAC                                                     */
/* -------------------------------------------------------------------------- */

test('tutors and tutees are blocked from administrator areas and vice versa', async () => {
  const tutorAdmin = await created.tutorClient.get('/admin');
  assert.equal(tutorAdmin.status, 403);
  assert.match(tutorAdmin.html, /Access denied|administrators only/i);

  const tuteeAdmin = await created.tuteeClient.get('/admin/tutors');
  assert.equal(tuteeAdmin.status, 403);

  const adminPortal = await admin.get('/tutor');
  assert.equal(adminPortal.status, 403);

  const tuteeInTutorArea = await created.tuteeClient.get('/tutor/sessions');
  assert.equal(tuteeInTutorArea.status, 403);
});

test('tutors and tutees only see their own records', async () => {
  const otherTutee = client(app.base);
  // A different session for the same tutor: a tutee may not open the tutor pages at all.
  const res = await created.tutorClient.get(`/student`);
  assert.equal(res.status, 403);

  // Create a second tutor-owned session and confirm the tutee cannot read it via the portal.
  const detail = await created.tuteeClient.get('/student/sessions');
  assert.equal(detail.status, 200);
  assert.match(detail.html, /My sessions/);

  const stranger = await otherTutee.get('/student/sessions');
  assert.equal(stranger.status, 303, 'signed-out request is redirected to sign-in');
});

test('a non-super administrator cannot manage administrators', async () => {
  const csrf = csrfFrom((await admin.get('/admin/admins/new')).html);
  const res = await admin.post('/admin/admins', form({
    _csrf: csrf, username: 'ops.admin', email: 'ops@example.com', role: 'admin', status: 'active',
    password: STRONG_PASSWORD, password_confirm: STRONG_PASSWORD,
  }));
  assert.equal(res.status, 303);

  const opsClient = client(app.base);
  const login = await opsClient.get('/login');
  const signIn = await opsClient.post('/login', form({ _csrf: csrfFrom(login.html), identifier: 'ops.admin', password: STRONG_PASSWORD }));
  assert.equal(signIn.status, 303);
  const change = await opsClient.get('/account/password');
  await opsClient.post('/account/password', form({
    _csrf: csrfFrom(change.html), current_password: STRONG_PASSWORD, password: `${STRONG_PASSWORD}-ops`, password_confirm: `${STRONG_PASSWORD}-ops`,
  }));

  assert.equal((await opsClient.get('/admin')).status, 200, 'admins can use the dashboard');
  assert.equal((await opsClient.get('/admin/admins/new')).status, 403, 'only a super admin creates administrators');
  assert.equal((await opsClient.get('/admin/admins')).status, 200, 'admins can view the administrator list');
  assert.equal((await opsClient.get('/admin/audit')).status, 200);
});

/* -------------------------------------------------------------------------- */
/* Availability & matching                                                    */
/* -------------------------------------------------------------------------- */

test('administrators can record availability on someone else’s behalf', async () => {
  const csrf = csrfFrom((await admin.get(`/admin/availability/${created.tutorId}`)).html);
  const res = await admin.post(`/admin/availability/${created.tutorId}/weekly`, form({
    _csrf: csrf, weekday: 1, start: '17:00', end: '19:00', state: 'available', note: 'Added by admin',
  }));
  assert.equal(res.status, 303);

  const invalid = await admin.post(`/admin/availability/${created.tutorId}/weekly`, form({
    _csrf: csrf, weekday: 1, start: '19:00', end: '17:00',
  }));
  assert.equal(invalid.status, 303, 'end before start is rejected');

  const rows = all('SELECT * FROM availability WHERE user_id = ?', [created.tutorId]);
  assert.equal(rows.length, 3, 'two from registration plus one from the administrator');
  assert.ok(rows.every((r) => r.end_min > r.start_min));

  const overview = await admin.get('/admin/availability?day=2');
  assert.equal(overview.status, 200);
  assert.match(overview.html, /Invited Tutor/);
});

test('matching ranks tutors by subject and availability, and hides nothing sensitive', async () => {
  const res = await admin.get(`/admin/matches?tutee=${created.tuteeId}&days=14`);
  assert.equal(res.status, 200);
  assert.match(res.html, /Tutors for/);
  assert.match(res.html, /Invited Tutor/, 'the tutor who teaches Science is suggested');
  assert.match(res.html, /Matching availability/);
  assert.match(res.html, /Available|Partially available|No matching availability/);
  assert.doesNotMatch(res.html, /password_hash|scrypt\$/, 'no credential material is ever rendered');
});

test('matching reports no-match reasons when availability is missing', async () => {
  const res = await admin.get(`/admin/matches?tutor=${created.tutorId}&days=14`);
  assert.equal(res.status, 200);
  assert.match(res.html, /Tutees for/, 'reverse matching works too');
});

/* -------------------------------------------------------------------------- */
/* Sessions: conflicts, rescheduling, status, notes                           */
/* -------------------------------------------------------------------------- */

test('scheduling a session notifies participants and appears on both timetables', async () => {
  const maths = q("SELECT id FROM subjects WHERE name = 'Maths'");
  const date = '2026-09-16'; // Wednesday
  const csrf = csrfFrom((await admin.get('/admin/sessions/new')).html);
  const res = await admin.post('/admin/sessions', form({
    _csrf: csrf, tutor_id: created.tutorId, tutee_id: created.tuteeId, subject_id: maths.id,
    date, start: '17:00', end: '18:00', mode: 'in_person', location: 'Study room 1', repeat_weeks: 1,
  }));
  assert.equal(res.status, 303);
  assert.match(res.location, /^\/admin\/sessions\/\d+$/);
  created.sessionId = Number(res.location.split('/').pop());

  const session = q('SELECT * FROM sessions WHERE id = ?', [created.sessionId]);
  assert.equal(session.date, date);
  assert.equal(session.start_min, 17 * 60);
  assert.equal(session.end_min, 18 * 60);
  assert.equal(session.status, 'scheduled');

  const tutorNotifications = await created.tutorClient.get('/tutor/notifications');
  assert.match(tutorNotifications.html, /New session/);
  const tuteeNotifications = await created.tuteeClient.get('/student/notifications');
  assert.match(tuteeNotifications.html, /New session/);

  const tutorWeek = await created.tutorClient.get(`/tutor/timetable?view=week&date=${date}`);
  assert.match(tutorWeek.html, /Invited Tutor/);
  const tuteeWeek = await created.tuteeClient.get(`/student/timetable?view=week&date=${date}`);
  assert.match(tuteeWeek.html, /Validation Tutee/);
});

test('double booking is blocked with a clear conflict warning', async () => {
  const maths = q("SELECT id FROM subjects WHERE name = 'Maths'");
  const csrf = csrfFrom((await admin.get('/admin/sessions/new')).html);
  const res = await admin.post('/admin/sessions', form({
    _csrf: csrf, tutor_id: created.tutorId, tutee_id: created.tuteeId, subject_id: maths.id,
    date: '2026-09-16', start: '17:30', end: '18:30',
  }));
  assert.equal(res.status, 200, 'the form is re-rendered instead of saving');
  assert.match(res.html, /Blocking conflicts/);
  assert.match(res.html, /already booked/);

  const count = q("SELECT COUNT(*) AS c FROM sessions WHERE tutor_id = ? AND date = '2026-09-16'", [created.tutorId]).c;
  assert.equal(count, 1, 'no conflicting session was created');
});

test('end time before start time is rejected by validation', async () => {
  const csrf = csrfFrom((await admin.get('/admin/sessions/new')).html);
  const res = await admin.post('/admin/sessions', form({
    _csrf: csrf, tutor_id: created.tutorId, tutee_id: created.tuteeId,
    subject_id: q("SELECT id FROM subjects WHERE name = 'Maths'").id,
    date: '2026-09-23', start: '18:00', end: '17:00',
  }));
  assert.equal(res.status, 200);
  assert.match(res.html, /end time must be after the start time/i);
});

test('recurring sessions are created and clashing occurrences are skipped', async () => {
  const csrf = csrfFrom((await admin.get('/admin/sessions/new')).html);
  const res = await admin.post('/admin/sessions', form({
    _csrf: csrf, tutor_id: created.tutorId, tutee_id: created.tuteeId,
    subject_id: q("SELECT id FROM subjects WHERE name = 'Maths'").id,
    date: '2026-10-07', start: '17:00', end: '18:00', repeat_weeks: 3,
  }));
  assert.equal(res.status, 303);
  const series = all("SELECT * FROM sessions WHERE date LIKE '2026-10-%' AND tutor_id = ?", [created.tutorId]);
  assert.equal(series.length, 3, 'three weekly occurrences');
  assert.equal(new Set(series.map((s) => s.series_id)).size, 1, 'occurrences share a series id');
});

test('administrators can reschedule while preserving the original record', async () => {
  const csrf = csrfFrom((await admin.get(`/admin/sessions/${created.sessionId}`)).html);
  const res = await admin.post(`/admin/sessions/${created.sessionId}/reschedule`, form({
    _csrf: csrf, date: '2026-09-23', start: '16:00', end: '17:00', reason: 'Room unavailable',
  }));
  assert.equal(res.status, 303);

  const original = q('SELECT * FROM sessions WHERE id = ?', [created.sessionId]);
  assert.equal(original.status, 'rescheduled');
  const replacement = q('SELECT * FROM sessions WHERE rescheduled_from_id = ?', [created.sessionId]);
  assert.ok(replacement, 'a linked replacement session exists');
  assert.equal(replacement.date, '2026-09-23');
  created.replacementId = replacement.id;

  const history = all('SELECT * FROM session_status_history WHERE session_id = ?', [created.sessionId]);
  assert.ok(history.some((h) => h.to_status === 'rescheduled'), 'status history is retained');
});

test('tutors can mark their own sessions complete and add session notes', async () => {
  const detail = await created.tutorClient.get(`/tutor/sessions/${created.replacementId}`);
  assert.equal(detail.status, 200);
  const csrf = csrfFrom(detail.html);
  const status = await created.tutorClient.post(`/tutor/sessions/${created.replacementId}/status`, form({ _csrf: csrf, status: 'completed', reason: 'Session delivered' }));
  assert.equal(status.status, 303);
  assert.equal(q('SELECT status FROM sessions WHERE id = ?', [created.replacementId]).status, 'completed');

  const note = await created.tutorClient.post(`/tutor/sessions/${created.replacementId}/notes`, form({
    _csrf: csrf, category: 'topics', visibility: 'all', body: 'Covered quadratics and factorising.',
  }));
  assert.equal(note.status, 303);
  assert.equal(q('SELECT COUNT(*) AS c FROM session_notes WHERE session_id = ?', [created.replacementId]).c, 1);
});

test('administrator-only notes stay hidden from tutors and tutees', async () => {
  const detail = await admin.get(`/admin/sessions/${created.replacementId}`);
  const csrf = csrfFrom(detail.html);
  const res = await admin.post(`/admin/sessions/${created.replacementId}/notes`, form({
    _csrf: csrf, category: 'follow_up', visibility: 'private', body: 'Safeguarding: internal note only.',
  }));
  assert.equal(res.status, 303);

  const tutorView = await created.tutorClient.get(`/tutor/sessions/${created.replacementId}`);
  assert.doesNotMatch(tutorView.html, /Safeguarding: internal note only/);
  assert.match(tutorView.html, /Covered quadratics/);

  const tuteeView = await created.tuteeClient.get(`/student/sessions/${created.replacementId}`);
  assert.doesNotMatch(tuteeView.html, /Safeguarding: internal note only/);
  assert.match(tuteeView.html, /Covered quadratics/);

  const adminView = await admin.get(`/admin/sessions/${created.replacementId}`);
  assert.match(adminView.html, /Safeguarding: internal note only/);
});

test('status transitions that make no sense are refused', async () => {
  const csrf = csrfFrom((await admin.get(`/admin/sessions/${created.replacementId}`)).html);
  const res = await admin.post(`/admin/sessions/${created.replacementId}/status`, form({ _csrf: csrf, status: 'running' }));
  assert.equal(res.status, 303);
  assert.equal(q('SELECT status FROM sessions WHERE id = ?', [created.replacementId]).status, 'completed', 'completed sessions cannot silently go back to running');
});

/* -------------------------------------------------------------------------- */
/* Weekly tracking, calendar and reports                                      */
/* -------------------------------------------------------------------------- */

test('weekly tracking aggregates the week correctly and moves between weeks', async () => {
  const res = await admin.get('/admin/weekly?week=2026-09-14');
  assert.equal(res.status, 200);
  assert.match(res.html, /Weekly session tracking/);
  assert.match(res.html, /2026-09-14|14 Sep 2026/);
  assert.match(res.html, /By subject/);
  assert.match(res.html, /By tutor/);
  assert.match(res.html, /By tutee/);

  const next = await admin.get('/admin/weekly?week=2026-09-21');
  assert.match(next.html, /Next week|Previous week/);
  const invalid = await admin.get('/admin/weekly?week=not-a-date');
  assert.equal(invalid.status, 200, 'invalid week input falls back to the current week');
});

test('the timetable renders day, week and month views', async () => {
  for (const view of ['day', 'week', 'month']) {
    const res = await admin.get(`/admin/timetable?view=${view}&date=2026-09-16`);
    assert.equal(res.status, 200);
    assert.match(res.html, new RegExp(`data-|cal--${view}|Timetable`, 'i'));
  }
  const sessions = await admin.get('/admin/sessions?status=completed');
  assert.equal(sessions.status, 200);
  assert.match(sessions.html, /Completed/);
});

test('reports run and export to CSV and PDF', async () => {
  const page = await admin.get('/admin/reports?report=sessions_per_tutor&from=2026-09-01&to=2026-09-30');
  assert.equal(page.status, 200);
  assert.match(page.html, /Sessions per tutor/);

  const csv = await admin.get('/admin/reports/export?report=sessions_per_tutor&from=2026-09-01&to=2026-09-30&format=csv');
  assert.equal(csv.status, 200);
  assert.match(csv.contentType, /text\/csv/);
  assert.match(csv.text, /Tutor/);
  assert.match(csv.text, /Invited Tutor/);

  const pdf = await admin.get('/admin/reports/export?report=availability_overview&from=2026-09-01&to=2026-09-30&format=pdf');
  assert.equal(pdf.status, 200);
  assert.match(pdf.contentType, /application\/pdf/);
  assert.ok(pdf.text.includes('%PDF-1.4'));

  for (const report of ['sessions_per_week', 'sessions_per_student', 'sessions_per_subject', 'status_totals', 'tutor_workload', 'student_utilisation']) {
    const res = await admin.get(`/admin/reports/export?report=${report}&format=csv`);
    assert.equal(res.status, 200, `${report} exports`);
  }
});

test('the audit log records administrative actions and exports', async () => {
  const res = await admin.get('/admin/audit');
  assert.equal(res.status, 200);
  assert.match(res.html, /Activity log/);
  const actions = all('SELECT DISTINCT action FROM audit_log').map((r) => r.action);
  for (const expected of ['admin_login', 'subject_created', 'invitation_created', 'invitation_accepted', 'session_created', 'session_rescheduled', 'admin_created', 'login_failed']) {
    assert.ok(actions.includes(expected), `${expected} present in the audit log`);
  }
  const csv = await admin.get('/admin/audit/export');
  assert.match(csv.contentType, /text\/csv/);
});

/* -------------------------------------------------------------------------- */
/* Search, notifications, settings, password reset                            */
/* -------------------------------------------------------------------------- */

test('global search finds tutors, tutees, sessions and subjects', async () => {
  const res = await admin.get('/admin/search?q=Invited');
  assert.equal(res.status, 200);
  assert.match(res.html, /Invited Tutor/);
  assert.match(res.html, /Tutors \(/);

  const sessionSearch = await admin.get('/admin/search?q=Study');
  assert.equal(sessionSearch.status, 200);
  assert.match(sessionSearch.html, /Sessions \(/);
});

test('administrators can read and update settings, with validation', async () => {
  const page = await admin.get('/admin/settings');
  assert.equal(page.status, 200);
  const csrf = csrfFrom(page.html);
  const payload = {
    _csrf: csrf,
    organisation_name: 'Inspire Tutoring Centre',
    organisation_email: 'office@inspire.example',
    timezone_label: 'UK time',
    session_duration_default: '45',
    session_duration_options: '30,45,60,90',
    availability_day_start: '07:30',
    availability_day_end: '21:30',
    availability_slot_minutes: '30',
    availability_min_notice_hours: '2',
    session_reminder_lead_minutes: '90',
    invitation_expiry_hours: '48',
    registration_requires_approval: 'false',
    default_invited_role: 'tutor',
    min_password_length: '10',
    tutor_capacity_default: '10',
    match_min_overlap_minutes: '60',
    allow_tutor_status_updates: 'true',
    allow_tutor_notes: 'true',
    allow_tutee_notes: 'false',
    notifications_in_app: 'true',
    notifications_email: 'false',
    notify_on_registration: 'true',
    notify_on_invitation: 'true',
    invitation_expiry_warning_hours: '24',
  };
  const saved = await admin.post('/admin/settings', form(payload));
  assert.equal(saved.status, 303);
  const after = await admin.get('/admin/settings');
  assert.match(after.html, /Inspire Tutoring Centre/);

  const invalid = await admin.post('/admin/settings', form({ ...payload, _csrf: csrfFrom(after.html), session_duration_default: 'not-a-number', availability_day_end: '06:00' }));
  assert.equal(invalid.status, 303);
  const stillGood = await admin.get('/admin/settings');
  assert.match(stillGood.html, /value="45"/, 'invalid settings were not saved');
});

test('password reset links work once and then stop working', async () => {
  const csrf = csrfFrom((await admin.get(`/admin/tutees/${created.tuteeId}`)).html);
  const res = await admin.post(`/admin/tutees/${created.tuteeId}/reset-password`, form({ _csrf: csrf }));
  assert.equal(res.status, 303);
  const detail = await admin.get(`/admin/tutees/${created.tuteeId}`);
  const link = /(\/reset\/[A-Za-z0-9_-]{20,})/.exec(detail.html);
  assert.ok(link, 'a reset link is displayed to the administrator');

  const c = client(app.base);
  const page = await c.get(link[1]);
  assert.equal(page.status, 200);
  const newPassword = 'Reset-Password-77!';
  const done = await c.post(link[1], form({
    _csrf: csrfFrom(page.html), password: newPassword, password_confirm: newPassword,
  }));
  assert.equal(done.status, 303);
  assert.equal(done.location, '/login');

  const reused = await c.get(link[1]);
  assert.match(reused.html, /already been used/i);

  const signIn = client(app.base);
  const loginPage = await signIn.get('/login');
  const result = await signIn.post('/login', form({ _csrf: csrfFrom(loginPage.html), identifier: 'validation.tutee@example.com', password: newPassword }));
  assert.equal(result.status, 303, 'the new password works');
});

test('disabled accounts cannot sign in and their sessions are revoked', async () => {
  const csrf = csrfFrom((await admin.get(`/admin/tutors/${created.tutorId}`)).html);
  await admin.post(`/admin/tutors/${created.tutorId}/status`, form({ _csrf: csrf, status: 'disabled', reason: 'Test disable' }));
  assert.equal(q('SELECT status FROM users WHERE id = ?', [created.tutorId]).status, 'disabled');
  assert.equal(q("SELECT COUNT(*) AS c FROM auth_sessions WHERE user_id = ? AND revoked_at IS NULL", [created.tutorId]).c, 0, 'sessions revoked');

  const blocked = await created.tutorClient.get('/tutor');
  assert.equal(blocked.status, 303, 'existing cookie no longer authenticates');
  assert.match(blocked.location, /^\/login/);

  const signInAttempt = client(app.base);
  const loginPage = await signInAttempt.get('/login');
  const res = await signInAttempt.post('/login', form({ _csrf: csrfFrom(loginPage.html), identifier: 'invited.tutor@example.com', password: STRONG_PASSWORD }));
  assert.match(res.html, /disabled/i);
});

/* -------------------------------------------------------------------------- */
/* Security headers & CSRF                                                    */
/* -------------------------------------------------------------------------- */

test('security headers are present and CSRF is enforced on mutations', async () => {
  const res = await admin.get('/admin');
  assert.match(res.headers.get('content-security-policy') || '', /default-src 'self'/);
  assert.equal(res.headers.get('x-frame-options'), 'DENY');
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
  assert.match(res.headers.get('referrer-policy') || '', /strict-origin/);

  const noToken = await admin.post('/admin/subjects', form({ name: 'Should Not Exist' }));
  assert.equal(noToken.status, 403, 'CSRF failures never create records');

  const wrongToken = await admin.post('/admin/subjects', form({ _csrf: 'not-the-right-token', name: 'Should Not Exist' }));
  assert.equal(wrongToken.status, 403);
  assert.equal(q('SELECT COUNT(*) AS c FROM subjects WHERE name = ?', ['Should Not Exist']).c, 0);
});

test('a stale or unverifiable CSRF cookie is replaced instead of locking the user out', async () => {
  const c = client(app.base);
  // Simulate a cookie left behind by a deployment whose session secret changed.
  c.cookies.set('il_csrf', 'not-a-validly-signed-token');

  const page = await c.get('/login');
  assert.equal(page.status, 200);
  const token = csrfFrom(page.html);
  assert.ok(token, 'a usable token is rendered');
  assert.notEqual(token, 'not-a-validly-signed-token', 'the stale value is not reused');

  const res = await c.post('/login', form({ _csrf: token, identifier: 'admin', password: 'definitely-wrong' }));
  assert.equal(res.status, 200, 'the form is processed rather than rejected as expired');
  assert.doesNotMatch(res.html, /form expired/i);
  assert.match(res.html, /do not match our records/i);
});

test('no page emits an inline style, so the strict CSP stays honest', async () => {
  const paths = [
    '/admin', '/admin/timetable', '/admin/weekly', '/admin/sessions', '/admin/matches',
    '/admin/tutors', '/admin/tutees', '/admin/assignments', '/admin/availability', '/admin/subjects',
    '/admin/invitations', '/admin/admins', '/admin/reports', '/admin/audit', '/admin/settings',
    `/admin/sessions/${created.replacementId}`, `/admin/tutors/${created.tutorId}`,
    `/admin/tutees/${created.tuteeId}`,
  ];
  for (const path of paths) {
    const res = await admin.get(path);
    assert.equal(res.status, 200, `${path} responds`);
    assert.doesNotMatch(res.html, /\sstyle="/, `${path} must not use inline style attributes`);
    const csp = res.headers.get('content-security-policy') || '';
    assert.match(csp, /style-src 'self'(;|$)/, `${path} keeps the strict style policy`);
    assert.doesNotMatch(csp, /style-src[^;]*unsafe-inline/, `${path} must not relax style-src`);
  }
});

test('SQL injection attempts are safely parameterised', async () => {
  const csrf = csrfFrom((await admin.get('/admin/subjects')).html);
  const res = await admin.post('/admin/subjects', form({ _csrf: csrf, name: "Robotics'); DROP TABLE subjects;--" }));
  assert.equal(res.status, 303);
  assert.ok(q('SELECT COUNT(*) AS c FROM subjects').c >= 3, 'tables are intact');
  assert.equal(q("SELECT COUNT(*) AS c FROM subjects WHERE name LIKE 'Robotics%'").c, 1, 'the value was stored as data');
});

test('logout revokes the session server-side', async () => {
  const c = client(app.base);
  const loginPage = await c.get('/login');
  await c.post('/login', form({ _csrf: csrfFrom(loginPage.html), identifier: 'ops.admin', password: `${STRONG_PASSWORD}-ops` }));
  const dashboard = await c.get('/admin');
  assert.equal(dashboard.status, 200, 'signed in');
  const csrf = csrfFrom(dashboard.html);
  const out = await c.post('/logout', form({ _csrf: csrf }));
  assert.equal(out.status, 303);
  const after = await c.get('/admin');
  assert.equal(after.status, 303);
  assert.match(after.location, /^\/login/);
});
