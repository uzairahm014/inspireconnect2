/**
 * Unit tests for the pure logic: dates and times, validation, CSV/PDF helpers,
 * password hashing, RBAC and the availability/matching maths.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addDaysISO, buildPDF, durationLabel, fmtTime, fmtTimeRange, hhmmToMinutes, initials,
  isValidEmail, minutesToHHMM, overlapMinutes, paginate, passwordIssues, passwordStrength,
  rangesOverlap, slugify, toCSV, todayISO, weekStartISO, isoWeekday, toISODate, weekDays,
  truncate, isISODate,
} from '../src/util.mjs';

test('time helpers round-trip correctly', () => {
  assert.equal(hhmmToMinutes('16:30'), 990);
  assert.equal(hhmmToMinutes('00:00'), 0);
  assert.equal(hhmmToMinutes('23:59'), 1439);
  assert.equal(hhmmToMinutes('24:00'), null);
  assert.equal(hhmmToMinutes('nonsense'), null);
  assert.equal(minutesToHHMM(990), '16:30');
  assert.equal(fmtTime(960), '4:00 PM');
  assert.equal(fmtTime(0), '12:00 AM');
  assert.equal(fmtTime(12 * 60 + 15), '12:15 PM');
  assert.equal(fmtTimeRange(960, 1080), '4:00 PM – 6:00 PM');
  assert.equal(durationLabel(90), '1h 30m');
  assert.equal(durationLabel(60), '1h');
  assert.equal(durationLabel(45), '45m');
});

test('overlap arithmetic detects double bookings', () => {
  assert.equal(overlapMinutes(960, 1020, 990, 1080), 30);
  assert.equal(overlapMinutes(960, 1020, 1020, 1080), 0);
  assert.equal(overlapMinutes(0, 120, 60, 180), 60);
  assert.equal(rangesOverlap(960, 1020, 990, 1080), true);
  assert.equal(rangesOverlap(960, 1020, 1020, 1080), false);
});

test('week maths uses ISO weeks starting Monday', () => {
  assert.equal(isoWeekday('2026-09-14'), 1); // Monday
  assert.equal(isoWeekday('2026-09-20'), 7); // Sunday
  assert.equal(weekStartISO('2026-09-16'), '2026-09-14');
  assert.equal(addDaysISO('2026-09-14', 6), '2026-09-20');
  assert.equal(addDaysISO('2026-09-30', 1), '2026-10-01');
  const days = weekDays('2026-09-14');
  assert.equal(days.length, 7);
  assert.equal(days[0].name, 'Monday');
  assert.equal(days[6].name, 'Sunday');
  assert.equal(days[6].date, '2026-09-20');
  assert.equal(isISODate('2026-09-14'), true);
  assert.equal(isISODate('14/09/2026'), false);
  assert.equal(toISODate(new Date(2026, 0, 5)), '2026-01-05');
});

test('email and password validation rejects weak or malformed input', () => {
  assert.equal(isValidEmail('tutor@example.com'), true);
  assert.equal(isValidEmail('tutor.name+tag@sub.example.co.uk'), true);
  assert.equal(isValidEmail('nope'), false);
  assert.equal(isValidEmail('nope@'), false);
  assert.equal(isValidEmail('a b@example.com'), false);
  assert.equal(isValidEmail(`${'x'.repeat(250)}@example.com`), false);

  assert.ok(passwordIssues('short1').length > 0);
  assert.ok(passwordIssues('alllettersnodigits').some((m) => /number/i.test(m)));
  assert.ok(passwordIssues('1234567890').some((m) => /letter/i.test(m)));
  assert.deepEqual(passwordIssues('CorrectHorse7Battery'), []);
  assert.ok(passwordIssues('password123').some((m) => /guess/i.test(m)));
  assert.equal(passwordStrength('CorrectHorse7Battery!').score, 5);
  assert.equal(passwordStrength('abc').score, 0);
});

test('pagination clamps out-of-range pages', () => {
  const page = paginate(95, 1, 20);
  assert.equal(page.pages, 5);
  assert.equal(page.from, 1);
  assert.equal(page.to, 20);
  assert.equal(page.hasNext, true);
  const last = paginate(95, 99, 20);
  assert.equal(last.page, 5);
  assert.equal(last.from, 81);
  assert.equal(last.to, 95);
  assert.equal(last.hasNext, false);
  assert.equal(paginate(0, 1, 20).pages, 1);
});

test('CSV output escapes quotes, commas and spreadsheet formulas', () => {
  const csv = toCSV(['name', 'note'], [['Smith, John', 'He said "hi"'], ['=cmd()', 'plain']]);
  assert.match(csv, /"Smith, John"/);
  assert.match(csv, /"He said ""hi"""/);
  assert.match(csv, /'=cmd\(\)/);
});

test('PDF export produces a valid single-page document', () => {
  const pdf = buildPDF({
    title: 'Sessions per tutor',
    subtitle: 'Period 2026-09-01 – 2026-09-30',
    meta: ['Rows: 2'],
    columns: [{ label: 'Tutor', width: 2 }, { label: 'Total', width: 1 }],
    rows: [['Amara Okafor', 12], ['Priya Raman (test)', 9]],
  });
  assert.equal(pdf.subarray(0, 8).toString(), '%PDF-1.4');
  const text = pdf.toString('latin1');
  assert.match(text, /\/Type \/Catalog/);
  assert.match(text, /startxref/);
  assert.match(text, /%%EOF/);
  // Parentheses in content must be escaped for the PDF text operator.
  assert.match(text, /Priya Raman \\\(test\\\)/);
});

test('misc string helpers behave', () => {
  assert.equal(slugify('A Level Maths!'), 'a-level-maths');
  assert.equal(initials('Amara Okafor'), 'AO');
  assert.equal(truncate('abcdefghij', 5).length <= 5, true);
  assert.equal(todayISO().length, 10);
});

test('password hashing verifies and rejects', async () => {
  const { hashPassword, verifyPassword, dummyVerify } = await import('../src/auth.mjs');
  const hash = await hashPassword('CorrectHorse7Battery');
  assert.match(hash, /^scrypt\$32768\$8\$1\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
  assert.equal(await verifyPassword('CorrectHorse7Battery', hash), true);
  assert.equal(await verifyPassword('wrong-password', hash), false);
  assert.equal(await verifyPassword('CorrectHorse7Battery', 'garbage'), false);
  assert.equal(await verifyPassword('x', null), false);
  const second = await hashPassword('CorrectHorse7Battery');
  assert.notEqual(second, hash, 'salts must be unique per password');
  assert.equal(await dummyVerify('anything'), false);
});

test('RBAC permissions follow the documented matrix', async () => {
  const { can, permissionsFor } = await import('../src/auth.mjs');
  const { ROLES } = await import('../src/config.mjs');

  const superAdmin = { role: ROLES.SUPER_ADMIN, status: 'active' };
  const admin = { role: ROLES.ADMIN, status: 'active' };
  const scheduler = { role: ROLES.SCHEDULER, status: 'active' };
  const viewer = { role: ROLES.VIEWER, status: 'active' };
  const tutor = { role: ROLES.TUTOR, status: 'active' };
  const tutee = { role: ROLES.TUTEE, status: 'active' };
  const disabledAdmin = { role: ROLES.ADMIN, status: 'disabled' };

  assert.equal(can(superAdmin, 'anything.at.all'), true);
  assert.equal(can(admin, 'tutors.manage'), true);
  assert.equal(can(admin, 'admins.manage'), false, 'only super admins manage administrators');
  assert.equal(can(admin, 'admins.view'), true);
  assert.equal(can(scheduler, 'sessions.manage'), true);
  assert.equal(can(scheduler, 'tutors.manage'), false, 'schedulers cannot edit tutor records');
  assert.equal(can(viewer, 'reports.view'), true);
  assert.equal(can(viewer, 'sessions.manage'), false);
  assert.equal(can(viewer, 'tutors.manage'), false, 'manage implies view, not the reverse');
  assert.equal(can(tutor, 'tutors.manage'), false, 'tutors never get administrator powers');
  assert.equal(can(tutee, 'portal.tutee'), true);
  assert.equal(can(tutee, 'portal.tutor'), false);
  assert.equal(can(disabledAdmin, 'tutors.manage'), false, 'disabled accounts lose access');
  assert.equal(can(null, 'tutors.manage'), false);
  assert.ok(permissionsFor(ROLES.SUPER_ADMIN).has('*'));
});

test('availability intervals merge, subtract and respect effective dates', async () => {
  const { mergeIntervals, subtractIntervals } = await import('../src/people.mjs');
  const merged = mergeIntervals([{ start: 960, end: 1020 }, { start: 1000, end: 1080 }, { start: 1200, end: 1260 }]);
  assert.equal(merged.length, 2);
  assert.deepEqual([merged[0].start, merged[0].end], [960, 1080]);

  const carved = subtractIntervals([{ start: 960, end: 1200 }], [{ start: 1020, end: 1080 }]);
  assert.equal(carved.length, 2);
  assert.deepEqual(carved[0], { start: 960, end: 1020 });
  assert.deepEqual(carved[1], { start: 1080, end: 1200 });

  const trimmed = subtractIntervals([{ start: 960, end: 1020 }], [{ start: 990, end: 1080 }]);
  assert.deepEqual(trimmed, [{ start: 960, end: 990 }]);
});
