/**
 * Test harness: boots the real server against a throwaway database and provides
 * a cookie-aware HTTP client so tests exercise genuine routes, guards, CSRF and
 * database writes.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'inspirelink-test-'));

process.env.DATA_DIR = tmpRoot;
process.env.DATABASE_PATH = path.join(tmpRoot, 'test.db');
process.env.SESSION_SECRET = 'test-secret-key-0123456789abcdefghijklmnop';
process.env.NODE_ENV = 'test';
process.env.ADMIN_USERNAME = 'admin';
process.env.ADMIN_PASSWORD = 'inspire';
process.env.ADMIN_EMAIL = 'admin@example.com';
process.env.EMAIL_TRANSPORT = 'log';

export const ADMIN_PASSWORD = 'inspire';
export const STRONG_PASSWORD = 'Str0ng-Test-Pass!42';

export async function startServer() {
  const { createServer } = await import('../src/server.mjs');
  const server = await createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return {
    server,
    base: `http://127.0.0.1:${port}`,
    async close() {
      // Keep-alive sockets would otherwise hold the server open forever.
      server.closeIdleConnections?.();
      server.closeAllConnections?.();
      await new Promise((resolve) => server.close(resolve));
      const db = (await import('../src/db.mjs')).db;
      try { db.close(); } catch { /* already closed */ }
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    },
  };
}

export function client(base) {
  const jar = new Map();

  const cookieHeader = () => [...jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');

  const storeCookies = (res) => {
    const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    for (const cookie of list) {
      const pair = cookie.split(';')[0];
      const idx = pair.indexOf('=');
      if (idx === -1) continue;
      const name = pair.slice(0, idx).trim();
      const value = pair.slice(idx + 1).trim();
      if (!value) jar.delete(name);
      else jar.set(name, value);
    }
  };

  async function request(urlPath, { method = 'GET', body = null, headers = {}, redirect = 'manual' } = {}) {
    const init = { method, redirect, headers: { ...headers } };
    const cookie = cookieHeader();
    if (cookie) init.headers.cookie = cookie;
    if (body !== null) {
      if (body instanceof URLSearchParams) {
        init.body = body.toString();
        init.headers['content-type'] = 'application/x-www-form-urlencoded';
      } else if (typeof body === 'object') {
        init.body = JSON.stringify(body);
        init.headers['content-type'] = 'application/json';
      } else {
        init.body = body;
      }
    }
    const res = await fetch(`${base}${urlPath}`, init);
    storeCookies(res);
    const text = await res.text();
    return {
      status: res.status,
      location: res.headers.get('location'),
      contentType: res.headers.get('content-type') || '',
      headers: res.headers,
      text,
      html: text,
    };
  }

  return {
    get: (urlPath, options) => request(urlPath, { ...options, method: 'GET' }),
    post: (urlPath, body, options) => request(urlPath, { ...options, method: 'POST', body }),
    request,
    cookies: jar,
  };
}

export function csrfFrom(html) {
  const meta = /<meta name="csrf-token" content="([^"]+)"/.exec(html);
  if (meta) return meta[1];
  const form = /name="_csrf" value="([^"]+)"/.exec(html);
  if (form) return form[1];
  return null;
}

/** Fill a form payload with sensible defaults, overriding with `overrides`. */
export function form(defaults, overrides = {}) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries({ ...defaults, ...overrides })) {
    if (value === undefined || value === null) continue;
    if (Array.isArray(value)) { for (const v of value) params.append(key, String(v)); }
    else params.set(key, String(value));
  }
  return params;
}

export async function loginAsAdmin(c) {
  const page = await c.get('/login');
  const csrf = csrfFrom(page.html);
  const post = await c.post('/login', form({ _csrf: csrf, identifier: 'admin', password: ADMIN_PASSWORD }));
  if (post.status !== 303) throw new Error(`admin sign-in failed with status ${post.status}`);

  // The seeded administrator must change the initial password before the rest
  // of the application becomes reachable, so do that here.
  const change = await c.get('/account/password');
  if (change.status === 200 && /name="current_password"/.test(change.html)) {
    const res = await c.post('/account/password', form({
      _csrf: csrfFrom(change.html),
      current_password: ADMIN_PASSWORD,
      password: STRONG_PASSWORD,
      password_confirm: STRONG_PASSWORD,
    }));
    if (res.status !== 303) {
      throw new Error(`forced password change failed with status ${res.status}`);
    }
  }
  return c;
}

export const status = (res) => res.status;
