/**
 * InspireConnect server.
 *
 * Request pipeline:
 *   1. security headers
 *   2. static assets (/assets/*)
 *   3. session resolution + flash
 *   4. prefix guards (staff / tutor / tutee areas)
 *   5. CSRF verification for mutating requests
 *   6. route dispatch, HTML error pages, light background maintenance
 */
import http from 'node:http';
import { pathToFileURL } from 'node:url';
import { config, DEFAULT_BRAND, ROLES } from './config.mjs';
import { db, ensureInitialAdmin, ensureSettings, ensureSubjects, get, getSettings } from './db.mjs';
import { HttpError, parseCookies, permissionsFor, portalFor, resolveSession } from './auth.mjs';
import {
  ANON_CSRF_COOKIE, Context, FLASH_COOKIE_NAME, issueAnonCsrf, parseBody, securityHeaders,
  serveStatic, unsignValue, verifyAnonCsrf, verifyCsrf,
} from './http.mjs';
import { buildRouter } from './routes/index.mjs';
import { errorDocument } from './views/layout.mjs';
import { listNotifications, unreadCount } from './notify.mjs';
import { dashboardCounts, refreshSessionStates } from './sessions.mjs';

const router = buildRouter();

/* -------------------------------------------------------------------------- */
/* Middleware                                                                 */
/* -------------------------------------------------------------------------- */

function redirectTarget(ctx) {
  return `/${portalFor(ctx.user.role) === 'admin' ? 'admin' : portalFor(ctx.user.role)}`;
}

function applyGuard(ctx, guard) {
  if (!ctx.user) {
    if (ctx.method === 'GET') {
      ctx.redirect(`/login?next=${encodeURIComponent(ctx.path + (ctx.url.search || ''))}`, { flash: 'Please sign in to continue.', type: 'info' });
      return false;
    }
    throw new HttpError(401, 'Please sign in to continue.');
  }
  const isStaff = [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.SCHEDULER, ROLES.VIEWER].includes(ctx.user.role);
  if (guard === 'staff' && !isStaff) throw new HttpError(403, 'This area is for administrators only.');
  if (guard === 'tutor' && ctx.user.role !== ROLES.TUTOR) throw new HttpError(403, 'This area is for tutors only.');
  if (guard === 'tutee' && ctx.user.role !== ROLES.TUTEE) throw new HttpError(403, 'This area is for tutees only.');
  if (ctx.user.must_change_password && ctx.path !== '/account/password' && ctx.path !== '/logout' && ctx.method !== 'POST') {
    ctx.redirect('/account/password', { flash: 'Please change your password before continuing.', type: 'warning' });
    return false;
  }
  return true;
}

/** Enrich the context with the values the layout needs. */
function decorate(ctx) {
  ctx.permissions = ctx.user ? [...permissionsFor(ctx.user.role)] : [];
  if (!ctx.user) return;
  ctx.userName = (() => {
    const profile = ctx.user.role === ROLES.TUTOR
      ? get('SELECT full_name, preferred_name, photo FROM tutor_profiles WHERE user_id = ?', [ctx.user.id])
      : ctx.user.role === ROLES.TUTEE
        ? get('SELECT full_name, preferred_name, photo FROM tutee_profiles WHERE user_id = ?', [ctx.user.id])
        : null;
    ctx.userPhoto = profile?.photo || null;
    return profile?.preferred_name || profile?.full_name || ctx.user.username || ctx.user.email;
  })();
  ctx.navCounts = {
    unreadNotifications: unreadCount(ctx.user.id),
    recentNotifications: listNotifications(ctx.user.id, { limit: 5 }).rows,
  };
  if (['super_admin', 'admin', 'scheduler', 'viewer'].includes(ctx.user.role)) {
    const counts = dashboardCounts();
    ctx.navCounts.invitationsPending = counts.pendingInvitations;
    ctx.navCounts.conflicts = counts.conflictCount;
  }
}

/* -------------------------------------------------------------------------- */
/* Maintenance (throttled)                                                    */
/* -------------------------------------------------------------------------- */

let lastMaintenance = 0;

async function maintenance() {
  const now = Date.now();
  if (now - lastMaintenance < 60000) return;
  lastMaintenance = now;
  try {
    const changes = refreshSessionStates();
    if (changes.running || changes.missed) {
      console.log(`[maintenance] sessions updated — running: ${changes.running}, missed: ${changes.missed}`);
    }
    const { purgeOldLoginAttempts } = await import('./auth.mjs');
    purgeOldLoginAttempts();
    const { sendUpcomingReminders, warnExpiringInvitations } = await import('./notify.mjs');
    sendUpcomingReminders(getSettings());
    warnExpiringInvitations(getSettings());
  } catch (error) {
    console.error('[maintenance] failed', error.message);
  }
}

/* -------------------------------------------------------------------------- */
/* Error handling                                                             */
/* -------------------------------------------------------------------------- */

function sendError(res, ctx, error) {
  const status = error instanceof HttpError ? error.status : 500;
  const expose = error instanceof HttpError ? error.expose : false;
  const messages = {
    400: ['That request could not be processed', 'Check the information you submitted and try again.'],
    401: ['Please sign in', 'Your session may have expired.'],
    403: ['Access denied', 'Your account does not have permission to view this page.'],
    404: ['Page not found', 'The page or record you asked for does not exist.'],
    405: ['Method not allowed', 'That action is not supported on this address.'],
    413: ['That was too large', 'Please reduce the size of what you are sending.'],
    429: ['Too many requests', 'Please slow down and try again shortly.'],
    500: ['Something went wrong', 'The problem has been logged. Please try again.'],
  };
  const [title, message] = messages[status] || messages[500];
  // Early failures happen before a Context exists, so fall back to a minimal
  // anonymous context rather than assuming one is present.
  const renderCtx = ctx || {
    user: null,
    flash: { messages: [] },
    csrfToken: '',
    permissions: [],
    q: () => '',
  };
  let body;
  try {
    body = String(errorDocument({
      ctx: renderCtx,
      status,
      title,
      message,
      detail: expose && error.message && error.message !== title ? error.message : null,
    }));
  } catch (renderError) {
    // Never leave the client hanging: always send something back.
    console.error('[error] failed to render error page', renderError);
    body = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${status}</title></head><body><h1>${status} — ${title}</h1><p>${message}</p></body></html>`;
  }
  try {
    if (res.headersSent) {
      res.end();
    } else {
      res.writeHead(status, {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'Cache-Control': 'no-store',
      });
      res.end(body);
    }
  } catch (writeError) {
    console.error('[error] failed to send error response', writeError);
    try { res.destroy(); } catch { /* ignore */ }
  }
  if (status >= 500) console.error('[error]', error);
}

/* -------------------------------------------------------------------------- */
/* Server                                                                     */
/* -------------------------------------------------------------------------- */

let bootstrapPromise;
async function bootstrap() {
  if (!bootstrapPromise) {
    bootstrapPromise = (async () => {
      await ensureInitialAdmin({});
      ensureSettings();
      ensureSubjects();
    })();
  }
  return bootstrapPromise;
}

export async function handleRequest(req, res) {
  await bootstrap();
    securityHeaders(res);
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const method = String(req.method || 'GET').toUpperCase();
    let activeCtx = null;

    try {
      if (method === 'GET' && (url.pathname.startsWith('/assets/') || url.pathname === '/favicon.ico')) {
        if (serveStatic(req, res, url.pathname === '/favicon.ico' ? '/assets/favicon.svg' : url.pathname)) return;
      }

      const cookies = parseCookies(req.headers.cookie);
      const rawFlash = cookies[FLASH_COOKIE_NAME];
      // Flash is single-use: read then clear.
      let flash = { messages: [] };
      if (rawFlash) {
        res.setHeader('Set-Cookie', `${FLASH_COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax`);
        const decoded = unsignValue(rawFlash);
        if (decoded) {
          try {
            const parsed = JSON.parse(decoded);
            flash = {
              messages: Array.isArray(parsed.messages) ? parsed.messages : [],
              errors: parsed.errors || {},
              values: parsed.values || {},
            };
          } catch { /* ignore malformed flash cookie */ }
        }
      }

      const session = resolveSession(cookies[config.cookieName]);
      const user = session ? get('SELECT * FROM users WHERE id = ?', [session.user_id]) : null;

      // CSRF token for unauthenticated forms.
      let anonCsrf = cookies[ANON_CSRF_COOKIE] || null;
      // Discard an unverifiable token (for example a cookie left over from a
      // previous deployment whose session secret changed). Re-using it would
      // make every form fail with "your form expired" and no reload could
      // recover, so issue a fresh one instead.
      if (anonCsrf && !unsignValue(anonCsrf)) anonCsrf = null;
      if (!anonCsrf) {
        anonCsrf = issueAnonCsrf();
        const cookie = `Path=/; Max-Age=43200; HttpOnly; SameSite=Lax${config.cookieSecure ? '; Secure' : ''}`;
        const existing = res.getHeader('Set-Cookie');
        const value = `${ANON_CSRF_COOKIE}=${encodeURIComponent(anonCsrf)}; ${cookie}`;
        res.setHeader('Set-Cookie', existing ? (Array.isArray(existing) ? [...existing, value] : [existing, value]) : [value]);
      }

      const match = router.match(method, url.pathname);
      const ctx = new Context({
        req, res, url,
        params: match?.params || {},
        session: session ? { ...session, user_id: session.user_id } : null,
        user,
        flash,
        anonCsrf,
        cookies,
      });
      ctx.baseOrigin = config.baseUrl || `${url.protocol}//${url.host}`;
      activeCtx = ctx;

      decorate(ctx);

      if (!match || match.methodNotAllowed) {
        if (!match) throw new HttpError(404, 'Page not found');
        throw new HttpError(405, 'Method not allowed');
      }

      // Guards for role-scoped areas.
      const path = url.pathname;
      if (path.startsWith('/admin') && !applyGuard(ctx, 'staff')) return;
      if (path.startsWith('/tutor') && !applyGuard(ctx, 'tutor')) return;
      if (path.startsWith('/student') && !applyGuard(ctx, 'tutee')) return;

      // The body must be parsed before CSRF verification (the token travels in it).
      ctx.body = await parseBody(req);

      // CSRF for mutations: authenticated forms use the session token, public
      // forms (sign-in, invitation registration, password reset) use the signed
      // double-submit cookie.
      const isPublicForm = path === '/login' || path.startsWith('/register/') || path.startsWith('/reset/');
      if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
        if (isPublicForm) {
          if (!verifyAnonCsrf(cookies, String(ctx.field('_csrf', '')))) {
            throw new HttpError(403, 'Your form expired. Please reload the page and try again.');
          }
        } else if (ctx.user) {
          verifyCsrf(ctx);
        } else {
          throw new HttpError(401, 'Please sign in to continue.');
        }
      }

      await match.route.handler(ctx);
      if (!ctx.responded && !res.writableEnded) {
        throw new HttpError(404, 'Page not found');
      }
      if (config.env !== 'production') {
        console.log(`${method} ${url.pathname} → ${res.statusCode} (${Date.now() - ctx.startedAt}ms)`);
      }
      maintenance();
    } catch (error) {
      if (res.writableEnded) return;
      if (error instanceof HttpError && error.redirectTo) {
        res.writeHead(303, { Location: error.redirectTo }).end();
        return;
      }
      sendError(res, activeCtx, error);
    }
}

export async function createServer() {
  await bootstrap();
  return http.createServer(handleRequest);
}

// Compare through pathToFileURL: hand-building a file:// URL breaks on Windows,
// where the drive letter needs a third slash (file:///C:/...).
const isMain = Boolean(process.argv[1]) && import.meta.url === pathToFileURL(process.argv[1]).href;

if (isMain) {
  const server = await createServer();
  server.listen(config.port, config.host, () => {
    const settings = getSettings();
    const counts = dashboardCounts();
    const { port } = server.address();
    const banner = (settings.organisation_name || DEFAULT_BRAND).toLowerCase() === DEFAULT_BRAND.toLowerCase()
      ? `${DEFAULT_BRAND} v1.0.0`
      : `${settings.organisation_name} — ${DEFAULT_BRAND} v1.0.0`;
    console.log('');
    console.log(`  ${banner}`);
    // Report the port actually bound: PORT=0 means "pick a free one".
    console.log(`  Listening on http://${config.host}:${port}${config.port === 0 ? ' (ephemeral port)' : ''}`);
    console.log(`  Environment: ${config.env} · Database: ${config.databasePath}`);
    console.log(`  Records: ${counts.totalTutors} tutors, ${counts.totalTutees} tutees, ${counts.sessionsThisWeek} sessions this week`);
    console.log(`  Sign in with the administrator account configured in ADMIN_USERNAME / ADMIN_PASSWORD.`);
    console.log('');
  });

  const shutdown = (signal) => {
    console.log(`\n${signal} received — shutting down.`);
    server.close(() => {
      try { db.close(); } catch { /* ignore */ }
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

export { router };
