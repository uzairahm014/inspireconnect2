/**
 * People, subjects and availability domain logic.
 *
 * Availability model
 * ------------------
 * `availability` rows are either:
 *   - weekly : repeating pattern for a weekday (1=Mon … 7=Sun), optionally
 *              bounded by effective_from / effective_to dates (temporary
 *              recurrence), or
 *   - date   : a one-off window for a specific calendar date (date-specific).
 * Each row is `state = available` (adds time) or `state = unavailable`
 * (carves time out). `expandAvailability()` merges them into concrete free
 * intervals for a given date, which is what matching and conflict detection use.
 */
import { ACCOUNT_STATUS, ROLES, AVAILABILITY_KIND, AVAILABILITY_STATE } from './config.mjs';
import { all, get, run, lastId, tx, uniqueSlug, getSettings } from './db.mjs';
import {
  addDaysISO, isoWeekday, nowSQL, normaliseEmail, normalisePhone, rangesOverlap,
  todayISO, weekDays, weekStartISO, toCSV,
} from './util.mjs';

/* -------------------------------------------------------------------------- */
/* Subjects                                                                   */
/* -------------------------------------------------------------------------- */

export const listSubjects = ({ includeInactive = false } = {}) =>
  all(
    `SELECT * FROM subjects ${includeInactive ? '' : 'WHERE active = 1'} ORDER BY sort_order, name COLLATE NOCASE`,
  );

export const subjectById = (id) => get('SELECT * FROM subjects WHERE id = ?', [id]);

export const subjectByName = (name) =>
  get('SELECT * FROM subjects WHERE name = ? COLLATE NOCASE', [String(name || '').trim()]);

export function createSubject({ name, colour, description }, actor) {
  const slug = uniqueSlug('subjects', name);
  const order = Number(get('SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM subjects')?.n || 1);
  const id = lastId(run(
    'INSERT INTO subjects (name, slug, colour, description, active, sort_order, created_at) VALUES (?, ?, ?, ?, 1, ?, ?)',
    [String(name).trim(), slug, colour || '#2563eb', description || null, order, nowSQL()],
  ));
  return subjectById(id);
}

export function updateSubject(id, { name, colour, description, active, sort_order }) {
  const current = subjectById(id);
  if (!current) return null;
  run(
    `UPDATE subjects SET name = ?, colour = ?, description = ?, active = ?, sort_order = ?
      WHERE id = ?`,
    [
      name ?? current.name,
      colour ?? current.colour,
      description ?? current.description,
      active === undefined ? current.active : (active ? 1 : 0),
      sort_order ?? current.sort_order,
      id,
    ],
  );
  return subjectById(id);
}

export function deleteSubject(id) {
  const used = Number(get(
    `SELECT (SELECT COUNT(*) FROM user_subjects WHERE subject_id = ?)
          + (SELECT COUNT(*) FROM sessions WHERE subject_id = ?)
          + (SELECT COUNT(*) FROM assignments WHERE subject_id = ?) AS c`,
    [id, id, id],
  )?.c || 0);
  if (used > 0) {
    throw new Error('This subject is in use by tutors, tutees, assignments or sessions. Disable it instead of deleting.');
  }
  run('DELETE FROM subjects WHERE id = ?', [id]);
}

export function subjectUsage() {
  return all(`
    SELECT s.*,
      (SELECT COUNT(*) FROM user_subjects us WHERE us.subject_id = s.id AND us.kind = 'teach') AS tutor_count,
      (SELECT COUNT(*) FROM user_subjects us WHERE us.subject_id = s.id AND us.kind = 'need')  AS tutee_count,
      (SELECT COUNT(*) FROM sessions se WHERE se.subject_id = s.id)                            AS session_count
    FROM subjects s ORDER BY s.sort_order, s.name COLLATE NOCASE`);
}

export const subjectMap = () => new Map(listSubjects({ includeInactive: true }).map((s) => [Number(s.id), s]));

export function subjectsForUser(userId, kind) {
  return all(
    `SELECT s.*, us.level FROM user_subjects us JOIN subjects s ON s.id = us.subject_id
      WHERE us.user_id = ? AND us.kind = ? ORDER BY s.sort_order, s.name`,
    [userId, kind],
  );
}

export function subjectIdsForUser(userId, kind) {
  return all('SELECT subject_id FROM user_subjects WHERE user_id = ? AND kind = ?', [userId, kind])
    .map((r) => Number(r.subject_id));
}

export function setUserSubjects(userId, kind, subjectIds = [], level = null) {
  const clean = [...new Set((subjectIds || []).map((v) => Number(v)).filter((n) => Number.isFinite(n) && n > 0))];
  tx(() => {
    run('DELETE FROM user_subjects WHERE user_id = ? AND kind = ?', [userId, kind]);
    for (const subjectId of clean) {
      if (!subjectById(subjectId)) continue;
      run(
        'INSERT OR IGNORE INTO user_subjects (user_id, subject_id, kind, level, created_at) VALUES (?, ?, ?, ?, ?)',
        [userId, subjectId, kind, level, nowSQL()],
      );
    }
  });
  return clean;
}

export const subjectNamesForUser = (userId, kind) =>
  subjectsForUser(userId, kind).map((s) => s.name);

/* -------------------------------------------------------------------------- */
/* Tutor / tutee queries                                                      */
/* -------------------------------------------------------------------------- */

const TUTOR_BASE = `
  SELECT u.id, u.email, u.status, u.role, u.username, u.last_login_at, u.created_at, u.must_change_password,
         tp.full_name, tp.preferred_name, tp.phone, tp.photo, tp.qualifications, tp.experience, tp.notes,
         tp.max_students, tp.session_frequency, tp.preferred_session_times,
         (SELECT COUNT(*) FROM assignments a WHERE a.tutor_id = u.id AND a.status = 'active') AS student_count,
         (SELECT COUNT(*) FROM sessions s WHERE s.tutor_id = u.id AND s.status IN ('scheduled','confirmed','running')) AS booked_sessions,
         (SELECT COUNT(*) FROM sessions s WHERE s.tutor_id = u.id) AS total_sessions,
         (SELECT GROUP_CONCAT(sb.name, ', ') FROM user_subjects us JOIN subjects sb ON sb.id = us.subject_id
           WHERE us.user_id = u.id AND us.kind = 'teach') AS subject_names,
         (SELECT COUNT(*) FROM availability av WHERE av.user_id = u.id AND av.state = 'available') AS availability_count
  FROM users u LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
  WHERE u.role = ?`;

const TUTEE_BASE = `
  SELECT u.id, u.email, u.status, u.role, u.last_login_at, u.created_at, u.must_change_password,
         tp.full_name, tp.preferred_name, tp.phone, tp.photo, tp.year_level, tp.guardian_name,
         tp.guardian_contact, tp.notes, tp.sessions_per_week, tp.preferred_session_times,
         (SELECT COUNT(*) FROM assignments a WHERE a.tutee_id = u.id AND a.status = 'active') AS tutor_count,
         (SELECT COUNT(*) FROM sessions s WHERE s.tutee_id = u.id AND s.status IN ('scheduled','confirmed','running')) AS booked_sessions,
         (SELECT COUNT(*) FROM sessions s WHERE s.tutee_id = u.id) AS total_sessions,
         (SELECT GROUP_CONCAT(sb.name, ', ') FROM user_subjects us JOIN subjects sb ON sb.id = us.subject_id
           WHERE us.user_id = u.id AND us.kind = 'need') AS subject_names,
         (SELECT COUNT(*) FROM availability av WHERE av.user_id = u.id AND av.state = 'available') AS availability_count,
         (SELECT GROUP_CONCAT(t.full_name, ', ') FROM assignments a
            JOIN users tu ON tu.id = a.tutor_id LEFT JOIN tutor_profiles t ON t.user_id = tu.id
           WHERE a.tutee_id = u.id AND a.status = 'active') AS tutor_names
  FROM users u LEFT JOIN tutee_profiles tp ON tp.user_id = u.id
  WHERE u.role = ?`;

function buildPeopleQuery(base, role, filters = {}) {
  const where = [];
  const params = [role];
  const { search, subjectId, status, availabilityDay, assigned, hasAvailability, sort, dir, limit = 25, offset = 0 } = filters;

  if (search) {
    const like = `%${String(search).trim()}%`;
    where.push(`(tp.full_name LIKE ? OR tp.preferred_name LIKE ? OR u.email LIKE ? OR tp.phone LIKE ?)`);
    params.push(like, like, like, like);
  }
  if (status && status !== 'all') { where.push('u.status = ?'); params.push(status); }
  if (subjectId && subjectId !== 'all') {
    where.push(`EXISTS (SELECT 1 FROM user_subjects us WHERE us.user_id = u.id AND us.kind = ? AND us.subject_id = ?)`);
    params.push(role === ROLES.TUTOR ? 'teach' : 'need', Number(subjectId));
  }
  if (availabilityDay && availabilityDay !== 'all') {
    where.push(`EXISTS (SELECT 1 FROM availability av WHERE av.user_id = u.id AND av.state = 'available' AND av.weekday = ?)`);
    params.push(Number(availabilityDay));
  }
  if (assigned === 'assigned') where.push(`(SELECT COUNT(*) FROM assignments a WHERE a.${role === ROLES.TUTOR ? 'tutor_id' : 'tutee_id'} = u.id AND a.status = 'active') > 0`);
  if (assigned === 'unassigned') where.push(`(SELECT COUNT(*) FROM assignments a WHERE a.${role === ROLES.TUTOR ? 'tutor_id' : 'tutee_id'} = u.id AND a.status = 'active') = 0`);
  if (hasAvailability === 'yes') where.push(`EXISTS (SELECT 1 FROM availability av WHERE av.user_id = u.id AND av.state = 'available')`);
  if (hasAvailability === 'no') where.push(`NOT EXISTS (SELECT 1 FROM availability av WHERE av.user_id = u.id AND av.state = 'available')`);

  const clause = where.length ? ` AND ${where.join(' AND ')}` : '';
  const sortable = {
    name: 'COALESCE(tp.full_name, u.email)',
    email: 'u.email',
    status: 'u.status',
    created: 'u.created_at',
    students: 'student_count',
    sessions: 'total_sessions',
    last_login: 'u.last_login_at',
  };
  const orderBy = sortable[sort] || 'COALESCE(tp.full_name, u.email)';
  const direction = String(dir).toLowerCase() === 'desc' ? 'DESC' : 'ASC';

  const profileTable = role === ROLES.TUTOR ? 'tutor_profiles tp' : 'tutee_profiles tp';
  const total = Number(get(
    `SELECT COUNT(*) AS c FROM users u LEFT JOIN ${profileTable} ON tp.user_id = u.id WHERE u.role = ?${clause}`,
    params,
  )?.c || 0);
  const rows = all(`${base}${clause} ORDER BY ${orderBy} ${direction} LIMIT ? OFFSET ?`, [...params, Number(limit), Number(offset)]);
  return { total, rows };
}

export function listTutors(filters = {}) {
  return buildPeopleQuery(TUTOR_BASE, ROLES.TUTOR, filters);
}

export function listTutees(filters = {}) {
  return buildPeopleQuery(TUTEE_BASE, ROLES.TUTEE, filters);
}

export const tutorRow = (id) => get(`${TUTOR_BASE} AND u.id = ?`, [ROLES.TUTOR, id]);
export const tuteeRow = (id) => get(`${TUTEE_BASE} AND u.id = ?`, [ROLES.TUTEE, id]);

export function peopleForPicker({ role, search = '', limit = 200 } = {}) {
  const base = role === ROLES.TUTOR ? TUTOR_BASE : TUTEE_BASE;
  const rows = all(`${base} AND u.status = 'active' ORDER BY COALESCE(tp.full_name, u.email) LIMIT ?`, [role, limit]);
  if (!search) return rows;
  const needle = search.toLowerCase();
  return rows.filter((r) => `${r.full_name || ''} ${r.email}`.toLowerCase().includes(needle));
}

export const activeTutors = () => all(`${TUTOR_BASE} AND u.status = 'active' ORDER BY COALESCE(tp.full_name, u.email)`, [ROLES.TUTOR]);
export const activeTutees = () => all(`${TUTEE_BASE} AND u.status = 'active' ORDER BY COALESCE(tp.full_name, u.email)`, [ROLES.TUTEE]);

export function staffUsers() {
  return all(
    `SELECT u.id, u.username, u.email, u.role, u.status, u.last_login_at, u.created_at, u.must_change_password,
            (SELECT COUNT(*) FROM audit_log al WHERE al.actor_id = u.id) AS action_count,
            (SELECT COUNT(*) FROM auth_sessions s WHERE s.user_id = u.id AND s.revoked_at IS NULL AND s.expires_at > datetime('now')) AS active_sessions
       FROM users u WHERE u.role IN ('super_admin','admin','scheduler','viewer')
      ORDER BY CASE u.role WHEN 'super_admin' THEN 0 WHEN 'admin' THEN 1 WHEN 'scheduler' THEN 2 ELSE 3 END, u.username`,
  );
}

/* -------------------------------------------------------------------------- */
/* Profile creation / updates                                                 */
/* -------------------------------------------------------------------------- */

export const emailTaken = (email, exceptUserId = null) => {
  const row = get('SELECT id FROM users WHERE email = ?', [normaliseEmail(email)]);
  return Boolean(row && Number(row.id) !== Number(exceptUserId));
};

export const usernameTaken = (username, exceptUserId = null) => {
  const row = get('SELECT id FROM users WHERE LOWER(username) = ?', [String(username || '').toLowerCase()]);
  return Boolean(row && Number(row.id) !== Number(exceptUserId));
};

export function createTutorRecord(data, { createdBy = null, status = ACCOUNT_STATUS.PENDING } = {}) {
  const settings = getSettings();
  return tx(() => {
    const userId = lastId(run(
      `INSERT INTO users (role, email, status, created_at, updated_at, created_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [ROLES.TUTOR, normaliseEmail(data.email), status, nowSQL(), nowSQL(), createdBy],
    ));
    run(
      `INSERT INTO tutor_profiles (user_id, full_name, preferred_name, phone, qualifications, experience, notes,
        max_students, session_frequency, preferred_session_times, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId, data.full_name, data.preferred_name || null, data.phone || null,
        data.qualifications || null, data.experience || null, data.notes || null,
        Number(data.max_students || settings.tutor_capacity_default || 12),
        data.session_frequency || null, data.preferred_session_times || null, nowSQL(),
      ],
    );
    if (data.subjects?.length) setUserSubjects(userId, 'teach', data.subjects);
    return userId;
  });
}

export function createTuteeRecord(data, { createdBy = null, status = ACCOUNT_STATUS.PENDING } = {}) {
  return tx(() => {
    const userId = lastId(run(
      `INSERT INTO users (role, email, status, created_at, updated_at, created_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [ROLES.TUTEE, normaliseEmail(data.email), status, nowSQL(), nowSQL(), createdBy],
    ));
    run(
      `INSERT INTO tutee_profiles (user_id, full_name, preferred_name, phone, year_level, guardian_name,
        guardian_contact, notes, sessions_per_week, preferred_session_times, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userId, data.full_name, data.preferred_name || null, data.phone || null, data.year_level || null,
        data.guardian_name || null, data.guardian_contact || null, data.notes || null,
        Number(data.sessions_per_week || 1), data.preferred_session_times || null, nowSQL(),
      ],
    );
    if (data.subjects?.length) setUserSubjects(userId, 'need', data.subjects);
    return userId;
  });
}

export function updateTutorProfile(userId, data, { adminFields = true } = {}) {
  const current = get('SELECT * FROM tutor_profiles WHERE user_id = ?', [userId]);
  if (!current) return null;
  const pick = (key, value) => (value === undefined ? current[key] : value);
  run(
    `UPDATE tutor_profiles SET full_name = ?, preferred_name = ?, phone = ?, qualifications = ?, experience = ?,
       notes = ?, max_students = ?, session_frequency = ?, preferred_session_times = ?, photo = ?, updated_at = ?
     WHERE user_id = ?`,
    [
      pick('full_name', data.full_name),
      pick('preferred_name', data.preferred_name) || null,
      normalisePhone(pick('phone', data.phone)) || null,
      pick('qualifications', data.qualifications) || null,
      pick('experience', data.experience) || null,
      pick('notes', data.notes) || null,
      adminFields ? Number(pick('max_students', data.max_students)) || current.max_students : current.max_students,
      pick('session_frequency', data.session_frequency) || null,
      pick('preferred_session_times', data.preferred_session_times) || null,
      pick('photo', data.photo) || null,
      nowSQL(),
      userId,
    ],
  );
  return get('SELECT * FROM tutor_profiles WHERE user_id = ?', [userId]);
}

export function updateTuteeProfile(userId, data, { adminFields = true } = {}) {
  const current = get('SELECT * FROM tutee_profiles WHERE user_id = ?', [userId]);
  if (!current) return null;
  const pick = (key, value) => (value === undefined ? current[key] : value);
  run(
    `UPDATE tutee_profiles SET full_name = ?, preferred_name = ?, phone = ?, year_level = ?, guardian_name = ?,
       guardian_contact = ?, notes = ?, sessions_per_week = ?, preferred_session_times = ?, photo = ?, updated_at = ?
     WHERE user_id = ?`,
    [
      pick('full_name', data.full_name),
      pick('preferred_name', data.preferred_name) || null,
      normalisePhone(pick('phone', data.phone)) || null,
      pick('year_level', data.year_level) || null,
      pick('guardian_name', data.guardian_name) || null,
      normalisePhone(pick('guardian_contact', data.guardian_contact)) || null,
      pick('notes', data.notes) || null,
      adminFields ? Number(pick('sessions_per_week', data.sessions_per_week)) || current.sessions_per_week : current.sessions_per_week,
      pick('preferred_session_times', data.preferred_session_times) || null,
      pick('photo', data.photo) || null,
      nowSQL(),
      userId,
    ],
  );
  return get('SELECT * FROM tutee_profiles WHERE user_id = ?', [userId]);
}

export function setUserStatus(userId, status, reason = null) {
  run(
    `UPDATE users SET status = ?, updated_at = ?,
       disabled_at = CASE WHEN ? = 'disabled' THEN ? ELSE NULL END,
       disabled_reason = CASE WHEN ? = 'disabled' THEN ? ELSE NULL END,
       locked_until = CASE WHEN ? = 'disabled' THEN NULL ELSE locked_until END
     WHERE id = ?`,
    [status, nowSQL(), status, nowSQL(), status, reason, status, userId],
  );
}

export function touchLastLogin(userId) {
  run('UPDATE users SET last_login_at = ?, failed_attempts = 0, updated_at = ? WHERE id = ?', [nowSQL(), nowSQL(), userId]);
}

export function setPassword(userId, hash, { mustChange = false } = {}) {
  run(
    'UPDATE users SET password_hash = ?, must_change_password = ?, password_changed_at = ?, failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?',
    [hash, mustChange ? 1 : 0, nowSQL(), nowSQL(), userId],
  );
}

/* -------------------------------------------------------------------------- */
/* Availability                                                               */
/* -------------------------------------------------------------------------- */

export const listAvailability = (userId) =>
  all('SELECT * FROM availability WHERE user_id = ? ORDER BY weekday, start_min, date', [userId]);

export function availabilityRow(id) {
  return get('SELECT * FROM availability WHERE id = ?', [id]);
}

export function createAvailability({ userId, kind, weekday, date, start_min, end_min, state, effective_from, effective_to, note, createdBy }) {
  if (end_min <= start_min) throw new Error('End time must be after the start time.');
  const id = lastId(run(
    `INSERT INTO availability (user_id, kind, weekday, date, start_min, end_min, state, effective_from, effective_to, note, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      userId, kind, kind === AVAILABILITY_KIND.WEEKLY ? Number(weekday) : null,
      kind === AVAILABILITY_KIND.DATE ? date : null,
      Number(start_min), Number(end_min), state || AVAILABILITY_STATE.AVAILABLE,
      effective_from || null, effective_to || null, note || null, createdBy || null, nowSQL(),
    ],
  ));
  return availabilityRow(id);
}

export function updateAvailability(id, data) {
  const current = availabilityRow(id);
  if (!current) return null;
  const start = data.start_min ?? current.start_min;
  const end = data.end_min ?? current.end_min;
  if (Number(end) <= Number(start)) throw new Error('End time must be after the start time.');
  run(
    `UPDATE availability SET weekday = ?, date = ?, start_min = ?, end_min = ?, state = ?,
       effective_from = ?, effective_to = ?, note = ? WHERE id = ?`,
    [
      data.weekday ?? current.weekday, data.date ?? current.date, Number(start), Number(end),
      data.state ?? current.state, data.effective_from ?? current.effective_from,
      data.effective_to ?? current.effective_to, data.note ?? current.note, id,
    ],
  );
  return availabilityRow(id);
}

export const deleteAvailability = (id) => run('DELETE FROM availability WHERE id = ?', [id]);

export function clearAvailability(userId, kind = null) {
  if (kind) run('DELETE FROM availability WHERE user_id = ? AND kind = ?', [userId, kind]);
  else run('DELETE FROM availability WHERE user_id = ?', [userId]);
}

function withinEffective(row, isoDate) {
  if (row.effective_from && isoDate < row.effective_from) return false;
  if (row.effective_to && isoDate > row.effective_to) return false;
  return true;
}

const toIv = (row) => ({ start: Number(row.start_min), end: Number(row.end_min), id: row.id, note: row.note, state: row.state });

export function mergeIntervals(intervals) {
  const sorted = [...intervals].sort((a, b) => a.start - b.start || a.end - b.end);
  const out = [];
  for (const iv of sorted) {
    const last = out[out.length - 1];
    if (last && iv.start <= last.end) {
      last.end = Math.max(last.end, iv.end);
      last.sources = [...(last.sources || []), iv];
    } else {
      out.push({ start: iv.start, end: iv.end, sources: [iv] });
    }
  }
  return out;
}

export function subtractIntervals(base, cuts) {
  let result = base.map((b) => ({ ...b }));
  for (const cut of cuts) {
    const next = [];
    for (const iv of result) {
      if (cut.end <= iv.start || cut.start >= iv.end) { next.push(iv); continue; }
      if (cut.start > iv.start) next.push({ ...iv, end: cut.start });
      if (cut.end < iv.end) next.push({ ...iv, start: cut.end });
    }
    result = next;
  }
  return result;
}

/** Free intervals for a person on a specific date (merged, sorted). */
export function freeIntervalsForDate(rows, isoDate) {
  const dow = isoWeekday(isoDate);
  const relevant = rows.filter((r) =>
    (r.kind === AVAILABILITY_KIND.WEEKLY && Number(r.weekday) === dow && withinEffective(r, isoDate)) ||
    (r.kind === AVAILABILITY_KIND.DATE && r.date === isoDate));
  const positives = relevant.filter((r) => r.state === AVAILABILITY_STATE.AVAILABLE).map(toIv);
  const negatives = relevant.filter((r) => r.state === AVAILABILITY_STATE.UNAVAILABLE).map(toIv);
  return subtractIntervals(mergeIntervals(positives), negatives);
}

export function expandAvailability(userId, { fromDate = todayISO(), days = 7 } = {}) {
  const rows = listAvailability(userId);
  const result = [];
  for (let i = 0; i < days; i += 1) {
    const date = addDaysISO(fromDate, i);
    const intervals = freeIntervalsForDate(rows, date);
    if (intervals.length) result.push({ date, weekday: isoWeekday(date), intervals });
  }
  return result;
}

/** Group raw availability rows into a 7-day grid for display/editing. */
export function weeklyGrid(userId) {
  const rows = listAvailability(userId);
  const dated = rows.filter((r) => r.kind === AVAILABILITY_KIND.DATE);
  const weekly = rows.filter((r) => r.kind === AVAILABILITY_KIND.WEEKLY);
  const weekStart = weekStartISO();
  const dayRows = weekDays(weekStart).map((d) => ({
    ...d,
    weekly: weekly.filter((r) => Number(r.weekday) === d.n),
    dated: dated.filter((r) => r.date === d.date),
    free: freeIntervalsForDate(rows, d.date),
  }));
  return { rows, weekly, dated, days: dayRows };
}

export function availabilitySummary(userId, { kind = 'weekly' } = {}) {
  const rows = listAvailability(userId).filter((r) => r.state === AVAILABILITY_STATE.AVAILABLE && r.kind === kind);
  if (!rows.length) return 'No availability recorded';
  const byDay = new Map();
  for (const row of rows) {
    const key = row.kind === AVAILABILITY_KIND.WEEKLY ? `${row.weekday}` : row.date;
    if (!byDay.has(key)) byDay.set(key, []);
    byDay.get(key).push(row);
  }
  return [...byDay.entries()].map(([key, list]) => {
    const label = key.length === 1
      ? (weekDays(weekStartISO()).find((d) => String(d.n) === key)?.short || key)
      : key;
    return `${label}: ${list.map((r) => `${String(Math.floor(r.start_min / 60)).padStart(2, '0')}:${String(r.start_min % 60).padStart(2, '0')}`).join(', ')}`;
  }).join(' · ');
}

/** Total available minutes for a person across a date range. */
export function availableMinutes(userId, fromDate, days = 7) {
  const rows = listAvailability(userId);
  let total = 0;
  for (let i = 0; i < days; i += 1) {
    for (const iv of freeIntervalsForDate(rows, addDaysISO(fromDate, i))) {
      total += iv.end - iv.start;
    }
  }
  return total;
}

export function availabilityOverviewRows({ weekday = null } = {}) {
  const tutors = all(
    `SELECT u.id, tp.full_name, 'tutor' AS kind, u.status,
            (SELECT COUNT(*) FROM availability a WHERE a.user_id = u.id AND a.state = 'available' ${weekday ? 'AND a.weekday = ?' : ''}) AS slots
       FROM users u LEFT JOIN tutor_profiles tp ON tp.user_id = u.id WHERE u.role = 'tutor'
      ORDER BY tp.full_name`,
    weekday ? [Number(weekday)] : [],
  );
  const tutees = all(
    `SELECT u.id, tp.full_name, 'tutee' AS kind, u.status,
            (SELECT COUNT(*) FROM availability a WHERE a.user_id = u.id AND a.state = 'available' ${weekday ? 'AND a.weekday = ?' : ''}) AS slots
       FROM users u LEFT JOIN tutee_profiles tp ON tp.user_id = u.id WHERE u.role = 'tutee'
      ORDER BY tp.full_name`,
    weekday ? [Number(weekday)] : [],
  );
  return [...tutors, ...tutees];
}

/* -------------------------------------------------------------------------- */
/* Availability exports                                                       */
/* -------------------------------------------------------------------------- */

export function availabilityCSV(rows) {
  return toCSV(
    ['Person', 'Type', 'Day/Date', 'From', 'To', 'State', 'Effective from', 'Effective to', 'Note'],
    rows.map((r) => [
      r.person_name, r.kind,
      r.kind === AVAILABILITY_KIND.WEEKLY ? ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][r.weekday] : r.date,
      String(Math.floor(r.start_min / 60)).padStart(2, '0') + ':' + String(r.start_min % 60).padStart(2, '0'),
      String(Math.floor(r.end_min / 60)).padStart(2, '0') + ':' + String(r.end_min % 60).padStart(2, '0'),
      r.state, r.effective_from || '', r.effective_to || '', r.note || '',
    ]),
  );
}

/** Detect overlapping availability rows for one person (data hygiene check). */
export function availabilitySelfConflicts(userId) {
  const rows = listAvailability(userId).filter((r) => r.state === AVAILABILITY_STATE.AVAILABLE);
  const conflicts = [];
  for (let i = 0; i < rows.length; i += 1) {
    for (let j = i + 1; j < rows.length; j += 1) {
      const a = rows[i];
      const b = rows[j];
      const sameScope = a.kind === b.kind && (a.kind === AVAILABILITY_KIND.WEEKLY
        ? Number(a.weekday) === Number(b.weekday)
        : a.date === b.date);
      if (!sameScope) continue;
      if (rangesOverlap(a.start_min, a.end_min, b.start_min, b.end_min)) conflicts.push([a, b]);
    }
  }
  return conflicts;
}
