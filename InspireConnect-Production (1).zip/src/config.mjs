/**
 * Central configuration + domain constants.
 *
 * Everything is overridable by environment variables (.env supported) so the
 * platform can be deployed without touching code. Secrets are never sent to the
 * client — see `publicConfig()` for the whitelist of safe values.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const PUBLIC_DIR = path.join(ROOT, 'public');

/** Product name, used as the default before settings are loaded. */
export const DEFAULT_BRAND = 'InspireConnect';

/* -------------------------------------------------------------------------- */
/* .env loading (tiny, dependency free)                                       */
/* -------------------------------------------------------------------------- */

function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  const text = fs.readFileSync(file, 'utf8');
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
}
loadDotEnv();

const bool = (v, def = false) =>
  v === undefined || v === '' ? def : /^(1|true|yes|on)$/i.test(String(v).trim());
const int = (v, def) => {
  const n = Number.parseInt(String(v ?? ''), 10);
  return Number.isFinite(n) ? n : def;
};

/* -------------------------------------------------------------------------- */
/* Secrets                                                                    */
/* -------------------------------------------------------------------------- */

const runningOnVercel = Boolean(process.env.VERCEL || process.env.VERCEL_ENV);
const configuredDataDir = String(process.env.DATA_DIR || '').trim();
const effectiveDataDir = runningOnVercel && (!configuredDataDir || /^(\.?[\\/])?data([\\/]|$)/i.test(configuredDataDir))
  ? '/tmp/inspireconnect-data'
  : (configuredDataDir || 'data');
const DATA_DIR = path.resolve(ROOT, effectiveDataDir);
const configuredDatabasePath = String(process.env.DATABASE_PATH || '').trim();
const DEFAULT_DATABASE_PATH = runningOnVercel && (!configuredDatabasePath || /^(\.?[\\/])?data([\\/]|$)/i.test(configuredDatabasePath))
  ? '/tmp/inspireconnect-data/inspireconnect.db'
  : (configuredDatabasePath || 'data/inspireconnect.db');

function persistentSecret() {
  const fromEnv = (process.env.SESSION_SECRET || '').trim();
  if (fromEnv.length >= 16) return fromEnv;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const file = path.join(DATA_DIR, '.session-secret');
  if (fs.existsSync(file)) {
    const existing = fs.readFileSync(file, 'utf8').trim();
    if (existing.length >= 16) return existing;
  }
  const generated = crypto.randomBytes(48).toString('base64url');
  fs.writeFileSync(file, generated, { mode: 0o600 });
  return generated;
}

export const config = {
  env: process.env.NODE_ENV || 'development',
  isProduction: (process.env.NODE_ENV || 'development') === 'production',
  host: process.env.HOST || '127.0.0.1',
  port: int(process.env.PORT, 4600),
  trustProxy: bool(process.env.TRUST_PROXY, false),
  dataDir: DATA_DIR,
  databasePath: path.resolve(ROOT, DEFAULT_DATABASE_PATH),
  uploadsDir: path.join(DATA_DIR, 'uploads'),
  baseUrl: (process.env.APP_BASE_URL || '').replace(/\/+$/, ''),
  sessionSecret: persistentSecret(),
  sessionTtlHours: int(process.env.SESSION_TTL_HOURS, 12),
  cookieSecure: bool(process.env.COOKIE_SECURE, false),
  cookieName: 'il_session',
  maxLoginAttempts: int(process.env.MAX_LOGIN_ATTEMPTS, 8),
  lockoutMinutes: int(process.env.LOCKOUT_MINUTES, 15),
  loginRateWindowMinutes: int(process.env.LOGIN_RATE_WINDOW_MINUTES, 10),
  invitationExpiryHours: int(process.env.INVITATION_EXPIRY_HOURS, 72),
  minPasswordLength: int(process.env.MIN_PASSWORD_LENGTH, 10),
  initialAdmin: {
    username: (process.env.ADMIN_USERNAME || 'admin').trim().toLowerCase(),
    password: process.env.ADMIN_PASSWORD || 'inspire',
    email: (process.env.ADMIN_EMAIL || 'admin@example.com').trim().toLowerCase(),
  },
  email: {
    transport: (process.env.EMAIL_TRANSPORT || 'log').toLowerCase(),
    host: process.env.SMTP_HOST || '',
    port: int(process.env.SMTP_PORT, 587),
    user: process.env.SMTP_USER || '',
    password: process.env.SMTP_PASSWORD || '',
    from: process.env.SMTP_FROM || 'InspireConnect <no-reply@example.com>',
    secure: bool(process.env.SMTP_SECURE, false),
  },
  maxUploadBytes: 1024 * 1024 * 2,
  // Content Security Policy — no inline event handlers, no third-party origins.
  csp: [
    "default-src 'self'",
    "img-src 'self' data:",
    "style-src 'self'",
    "script-src 'self'",
    "form-action 'self'",
    "base-uri 'self'",
    "frame-ancestors 'none'",
    "object-src 'none'",
  ].join('; '),
};

export function publicConfig() {
  // Whitelist only — never expose secrets, hashes or tokens to the browser.
  return {
    env: config.env,
    baseUrl: config.baseUrl,
    minPasswordLength: config.minPasswordLength,
    maxUploadBytes: config.maxUploadBytes,
  };
}

/* -------------------------------------------------------------------------- */
/* Domain constants                                                           */
/* -------------------------------------------------------------------------- */

export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  SCHEDULER: 'scheduler',
  VIEWER: 'viewer',
  TUTOR: 'tutor',
  TUTEE: 'tutee',
};

export const STAFF_ROLES = [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.SCHEDULER, ROLES.VIEWER];
export const INVITABLE_ROLES = [ROLES.TUTOR, ROLES.TUTEE];

export const ROLE_LABELS = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  scheduler: 'Scheduler',
  viewer: 'Viewer',
  tutor: 'Tutor',
  tutee: 'Tutee',
};

export const ROLE_DESCRIPTIONS = {
  super_admin: 'Full system access, including administrator management and settings.',
  admin: 'Manages tutors, tutees, subjects, availability, matching, sessions and invitations.',
  scheduler: 'Builds timetables and schedules sessions; cannot edit tutor or tutee profiles.',
  viewer: 'Read-only access to dashboards, timetables, reports and records.',
  tutor: 'Own profile, availability, assigned tutees, own sessions and notes.',
  tutee: 'Own profile, availability, assigned tutor, own sessions and notes.',
};

/** Permission catalogue — enforced on the server for every request. */
export const PERMISSIONS = [
  'tutors.view', 'tutors.manage',
  'tutees.view', 'tutees.manage',
  'subjects.view', 'subjects.manage',
  'availability.view', 'availability.manage',
  'matches.view',
  'assignments.manage',
  'sessions.view', 'sessions.manage',
  'timetable.view',
  'invitations.view', 'invitations.manage',
  'admins.view', 'admins.manage',
  'reports.view',
  'audit.view',
  'settings.view', 'settings.manage',
  'notifications.view',
];

const VIEW_ONLY = PERMISSIONS.filter((p) => p.endsWith('.view'));
const VIEWER_PERMS = VIEW_ONLY.filter((p) => !['settings.view', 'admins.view', 'audit.view'].includes(p));

export const ROLE_PERMISSIONS = {
  [ROLES.SUPER_ADMIN]: ['*'],
  [ROLES.ADMIN]: [
    ...PERMISSIONS.filter((p) => p !== 'admins.manage'),
  ],
  [ROLES.SCHEDULER]: [
    'tutors.view', 'tutees.view', 'subjects.view',
    'availability.view', 'availability.manage',
    'matches.view', 'assignments.manage',
    'sessions.view', 'sessions.manage', 'timetable.view',
    'invitations.view', 'invitations.manage',
    'reports.view', 'notifications.view',
  ],
  [ROLES.VIEWER]: VIEWER_PERMS,
  [ROLES.TUTOR]: ['portal.tutor'],
  [ROLES.TUTEE]: ['portal.tutee'],
};

export const ACCOUNT_STATUS = {
  ACTIVE: 'active',
  PENDING: 'pending',
  DISABLED: 'disabled',
  LOCKED: 'locked',
};

export const ACCOUNT_STATUS_LABELS = {
  active: 'Active',
  pending: 'Pending activation',
  disabled: 'Disabled',
  locked: 'Locked',
};

export const SESSION_STATUS = {
  SCHEDULED: 'scheduled',
  CONFIRMED: 'confirmed',
  RUNNING: 'running',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
  MISSED: 'missed',
  RESCHEDULED: 'rescheduled',
};

export const SESSION_STATUSES = Object.values(SESSION_STATUS);

export const SESSION_STATUS_LABELS = {
  scheduled: 'Scheduled',
  confirmed: 'Confirmed',
  running: 'Running',
  completed: 'Completed',
  cancelled: 'Cancelled',
  missed: 'Missed',
  rescheduled: 'Rescheduled',
};

/** Statuses that occupy a tutor/tutee time slot for conflict detection. */
export const BLOCKING_STATUSES = [
  SESSION_STATUS.SCHEDULED,
  SESSION_STATUS.CONFIRMED,
  SESSION_STATUS.RUNNING,
];

export const SESSION_MODE = { ONLINE: 'online', IN_PERSON: 'in_person' };
export const SESSION_MODE_LABELS = { online: 'Online', in_person: 'In person' };

export const SESSION_NOTE_CATEGORIES = {
  topics: 'Topics covered',
  homework: 'Homework',
  progress: 'Progress',
  follow_up: 'Follow-up required',
  general: 'General note',
};

export const NOTE_VISIBILITY = {
  ALL: 'all',            // tutor + tutee + admins
  STAFF_TUTOR: 'staff_tutor', // admins + tutor only
  PRIVATE: 'private',    // admins only
};

export const NOTE_VISIBILITY_LABELS = {
  all: 'Everyone involved',
  staff_tutor: 'Tutor & administrators',
  private: 'Administrators only',
};

export const INVITATION_STATUS = {
  PENDING: 'pending',
  USED: 'used',
  EXPIRED: 'expired',
  REVOKED: 'revoked',
};

/** ISO weekday numbers (1 = Monday … 7 = Sunday). */
export const WEEKDAYS = [
  { n: 1, short: 'Mon', name: 'Monday' },
  { n: 2, short: 'Tue', name: 'Tuesday' },
  { n: 3, short: 'Wed', name: 'Wednesday' },
  { n: 4, short: 'Thu', name: 'Thursday' },
  { n: 5, short: 'Fri', name: 'Friday' },
  { n: 6, short: 'Sat', name: 'Saturday' },
  { n: 7, short: 'Sun', name: 'Sunday' },
];

export const WEEKDAY_NAMES = WEEKDAYS.map((d) => d.name);
export const WEEKDAY_BY_N = Object.fromEntries(WEEKDAYS.map((d) => [d.n, d]));

export const AVAILABILITY_KIND = { WEEKLY: 'weekly', DATE: 'date' };
export const AVAILABILITY_STATE = { AVAILABLE: 'available', UNAVAILABLE: 'unavailable' };

export const MATCH_STATUS = {
  AVAILABLE: 'available',
  PARTIAL: 'partial',
  BUSY: 'busy',
  NO_OVERLAP: 'no_overlap',
  NO_SUBJECT: 'no_subject',
  ASSIGNED: 'assigned',
  INACTIVE: 'inactive',
};

export const MATCH_STATUS_LABELS = {
  available: 'Available',
  partial: 'Partially available',
  busy: 'Busy',
  no_overlap: 'No matching availability',
  no_subject: 'Subject not taught',
  assigned: 'Already assigned',
  inactive: 'Not active',
};

/** Default settings — overridable at runtime by the Super Admin / Admin. */
export const DEFAULT_SETTINGS = {
  organisation_name: DEFAULT_BRAND,
  organisation_email: 'office@example.com',
  timezone_label: 'Local time',
  session_duration_default: '60',
  session_duration_options: '30,45,60,90,120',
  availability_day_start: '08:00',
  availability_day_end: '21:00',
  availability_slot_minutes: '30',
  availability_min_notice_hours: '2',
  session_reminder_lead_minutes: '60',
  invitation_expiry_hours: String(config.invitationExpiryHours),
  registration_requires_approval: 'false',
  default_invited_role: 'tutor',
  min_password_length: String(config.minPasswordLength),
  tutor_capacity_default: '12',
  match_min_overlap_minutes: '60',
  allow_tutor_status_updates: 'true',
  allow_tutor_notes: 'true',
  allow_tutee_notes: 'false',
  notifications_in_app: 'true',
  notifications_email: 'false',
  notify_on_registration: 'true',
  notify_on_invitation: 'true',
  invitation_expiry_warning_hours: '24',
};

export const SETTINGS_GROUPS = [
  { key: 'organisation', title: 'Organisation', hint: 'Names shown on dashboards, reports and emails.' , fields: ['organisation_name', 'organisation_email', 'timezone_label'] },
  { key: 'sessions', title: 'Sessions & timetable', hint: 'Defaults applied when scheduling new sessions.', fields: ['session_duration_default', 'session_duration_options', 'session_reminder_lead_minutes', 'allow_tutor_status_updates', 'allow_tutor_notes', 'allow_tutee_notes'] },
  { key: 'availability', title: 'Availability', hint: 'Controls the weekly availability grid.', fields: ['availability_day_start', 'availability_day_end', 'availability_slot_minutes', 'availability_min_notice_hours'] },
  { key: 'registration', title: 'Registration & invitations', hint: 'Secure invitation based onboarding.', fields: ['invitation_expiry_hours', 'registration_requires_approval', 'default_invited_role', 'min_password_length', 'invitation_expiry_warning_hours'] },
  { key: 'matching', title: 'Matching', hint: 'How tutor/tutee suggestions are scored.', fields: ['match_min_overlap_minutes', 'tutor_capacity_default'] },
  { key: 'notifications', title: 'Notifications', hint: 'In-app notifications and email delivery.', fields: ['notifications_in_app', 'notifications_email', 'notify_on_registration', 'notify_on_invitation'] },
];
