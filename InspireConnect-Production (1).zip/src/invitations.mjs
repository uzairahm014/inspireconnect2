/**
 * Secure registration invitations.
 *
 * Only the SHA-256 hash of a token is stored, so the raw link exists solely in
 * the message sent to the invitee (and can be re-issued, which rotates it).
 * Invitations are single-use, expiring and revocable, which is what stops open
 * self-registration.
 */
import { INVITATION_STATUS, INVITABLE_ROLES, ROLE_LABELS, ROLES } from './config.mjs';
import { all, get, run, lastId, getSettings, settingInt } from './db.mjs';
import { nowSQL, randomToken, sha256, normaliseEmail, fmtDate, isISODate, addHours } from './util.mjs';
import { config } from './config.mjs';
import { emailTaken } from './people.mjs';

export const INVITATION_STATUS_LABELS = {
  pending: 'Pending',
  used: 'Used',
  expired: 'Expired',
  revoked: 'Revoked',
};

export function invitationStatus(invitation, now = new Date()) {
  if (!invitation) return null;
  if (invitation.revoked_at) return INVITATION_STATUS.REVOKED;
  if (invitation.used_at) return INVITATION_STATUS.USED;
  const expires = new Date(String(invitation.expires_at).replace(' ', 'T'));
  if (expires <= now) return INVITATION_STATUS.EXPIRED;
  return INVITATION_STATUS.PENDING;
}

export function invitationStatusMessage(status) {
  switch (status) {
    case INVITATION_STATUS.USED:
      return 'This registration link has already been used. Each invitation works once — ask an administrator for a new link.';
    case INVITATION_STATUS.EXPIRED:
      return 'This registration link has expired. Ask your administrator to resend a fresh invitation.';
    case INVITATION_STATUS.REVOKED:
      return 'This registration link was revoked by an administrator and can no longer be used.';
    default:
      return 'This registration link is not valid. Please check you copied the whole link or ask for a new invitation.';
  }
}

export function createInvitation({ role, email, fullName = null, subjectIds = [], note = null, expiresHours = null }, actor) {
  const cleanRole = String(role || '').trim();
  if (!INVITABLE_ROLES.includes(cleanRole)) throw new Error('Choose whether this invitation is for a tutor or a tutee.');
  const cleanEmail = normaliseEmail(email);
  if (!cleanEmail) throw new Error('An email address is required for the invitation.');
  if (emailTaken(cleanEmail)) throw new Error('An account already exists with this email address.');
  const existingPending = get(
    `SELECT id FROM invitations WHERE email = ? AND role = ? AND used_at IS NULL AND revoked_at IS NULL AND expires_at > datetime('now')`,
    [cleanEmail, cleanRole],
  );
  if (existingPending) throw new Error('There is already an active invitation for this email address. Resend or revoke it first.');

  const hours = Number(expiresHours || settingInt('invitation_expiry_hours', config.invitationExpiryHours)) || 72;
  const token = randomToken(32);
  const expiresAt = addHours(new Date(), Math.max(1, Math.min(24 * 90, hours)));
  const id = lastId(run(
    `INSERT INTO invitations (token_hash, role, email, full_name, subject_ids, note, expires_at, created_by, created_at, send_count, last_sent_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
    [
      sha256(token), cleanRole, cleanEmail, fullName || null,
      subjectIds?.length ? JSON.stringify(subjectIds.map(Number)) : null,
      note || null, nowSQL(expiresAt), actor?.id ?? null, nowSQL(), nowSQL(),
    ],
  ));
  return { invitation: invitationById(id), token, expiresAt };
}

export const invitationById = (id) => get(
  `SELECT i.*, (SELECT COALESCE(tp.full_name, u.username, u.email) FROM users u
                  LEFT JOIN tutor_profiles tp ON tp.user_id = u.id WHERE u.id = i.created_by) AS created_by_label,
          (SELECT COALESCE(tp.full_name, ep.full_name, u.email) FROM users u
             LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
             LEFT JOIN tutee_profiles ep ON ep.user_id = u.id WHERE u.id = i.used_by) AS used_by_label
     FROM invitations i WHERE i.id = ?`,
  [id],
);

export function invitationByToken(token) {
  if (!token || typeof token !== 'string' || token.length < 20) return null;
  const row = get(
    `SELECT i.*, (SELECT COALESCE(tp.full_name, ep.full_name, u.email) FROM users u
                    LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
                    LEFT JOIN tutee_profiles ep ON ep.user_id = u.id WHERE u.id = i.used_by) AS used_by_label
       FROM invitations i WHERE i.token_hash = ?`,
    [sha256(token)],
  );
  if (!row) return null;
  return { ...row, status: invitationStatus(row) };
}

export function listInvitations({ status = 'all', role = 'all', search = '', limit = 25, offset = 0 } = {}) {
  const where = [];
  const params = [];
  if (role && role !== 'all') { where.push('i.role = ?'); params.push(role); }
  if (search) {
    const like = `%${String(search).trim()}%`;
    where.push('(i.email LIKE ? OR i.full_name LIKE ? OR i.note LIKE ?)');
    params.push(like, like, like);
  }
  if (status === INVITATION_STATUS.PENDING) {
    where.push("i.used_at IS NULL AND i.revoked_at IS NULL AND i.expires_at > datetime('now')");
  } else if (status === INVITATION_STATUS.USED) {
    where.push('i.used_at IS NOT NULL');
  } else if (status === INVITATION_STATUS.EXPIRED) {
    where.push("i.used_at IS NULL AND i.revoked_at IS NULL AND i.expires_at <= datetime('now')");
  } else if (status === INVITATION_STATUS.REVOKED) {
    where.push('i.revoked_at IS NOT NULL');
  }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const base = `FROM invitations i
      LEFT JOIN users cu ON cu.id = i.created_by
      LEFT JOIN tutor_profiles ctp ON ctp.user_id = i.created_by`;
  const total = Number(get(`SELECT COUNT(*) AS c ${base} ${clause}`, params)?.c || 0);
  const rows = all(
    `SELECT i.*, COALESCE(ctp.full_name, cu.username, cu.email) AS created_by_label,
            (SELECT COALESCE(tp.full_name, ep.full_name, u.email) FROM users u
               LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
               LEFT JOIN tutee_profiles ep ON ep.user_id = u.id WHERE u.id = i.used_by) AS used_by_label
       ${base} ${clause} ORDER BY i.created_at DESC LIMIT ? OFFSET ?`,
    [...params, Number(limit) || 25, Number(offset) || 0],
  );
  return { total, rows: rows.map((r) => ({ ...r, status: invitationStatus(r) })) };
}

export function invitationCounts() {
  const base = (extra) => Number(get(`SELECT COUNT(*) AS c FROM invitations WHERE ${extra}`)?.c || 0);
  return {
    pending: base("used_at IS NULL AND revoked_at IS NULL AND expires_at > datetime('now')"),
    used: base('used_at IS NOT NULL'),
    expired: base("used_at IS NULL AND revoked_at IS NULL AND expires_at <= datetime('now')"),
    revoked: base('revoked_at IS NOT NULL'),
    expiringSoon: base(
      `used_at IS NULL AND revoked_at IS NULL AND expires_at > datetime('now') AND expires_at <= datetime('now', ?)`,
      [`+${settingInt('invitation_expiry_warning_hours', 24)} hours`],
    ),
  };
}

export function revokeInvitation(id, actor, reason = null) {
  const invitation = invitationById(id);
  if (!invitation) throw new Error('Invitation not found.');
  if (invitation.used_at) throw new Error('This invitation has already been used and cannot be revoked.');
  if (invitation.revoked_at) return invitation;
  run('UPDATE invitations SET revoked_at = ?, revoked_by = ?, revoke_reason = ? WHERE id = ?', [nowSQL(), actor?.id ?? null, reason || null, id]);
  return invitationById(id);
}

/** Rotate the token (invalidating the previous link) and extend the expiry. */
export function resendInvitation(id, actor, { expiresHours = null } = {}) {
  const invitation = invitationById(id);
  if (!invitation) throw new Error('Invitation not found.');
  if (invitation.used_at) throw new Error('This invitation has already been used. Create a new invitation instead.');
  const hours = Number(expiresHours || settingInt('invitation_expiry_hours', 72)) || 72;
  const token = randomToken(32);
  run(
    `UPDATE invitations SET token_hash = ?, expires_at = ?, revoked_at = NULL, revoked_by = NULL,
       send_count = send_count + 1, last_sent_at = ? WHERE id = ?`,
    [sha256(token), nowSQL(addHours(new Date(), hours)), nowSQL(), id],
  );
  return { invitation: invitationById(id), token };
}

export function consumeInvitation(id, userId) {
  run('UPDATE invitations SET used_at = ?, used_by = ? WHERE id = ?', [nowSQL(), userId, id]);
}

export function invitationUrl(token, baseUrl = null) {
  const base = (baseUrl || config.baseUrl || '').replace(/\/+$/, '');
  return `${base}/register/${token}`;
}

export function invitationSubjects(invitation) {
  if (!invitation?.subject_ids) return [];
  try {
    const parsed = JSON.parse(invitation.subject_ids);
    return Array.isArray(parsed) ? parsed.map(Number).filter(Number.isFinite) : [];
  } catch {
    return [];
  }
}

export function pendingInvitationsForEmail(email) {
  return all(
    `SELECT * FROM invitations WHERE email = ? AND used_at IS NULL AND revoked_at IS NULL AND expires_at > datetime('now')`,
    [normaliseEmail(email)],
  );
}

export { INVITATION_STATUS, ROLE_LABELS, ROLES, fmtDate, isISODate };
