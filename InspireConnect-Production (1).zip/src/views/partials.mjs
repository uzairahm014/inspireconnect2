/**
 * Reusable view partials shared by the admin, tutor and tutee experiences.
 */
import { AVAILABILITY_KIND, AVAILABILITY_STATE, MATCH_STATUS, NOTE_VISIBILITY, SESSION_MODE_LABELS, SESSION_STATUS, SESSION_STATUS_LABELS, WEEKDAYS, ROLE_LABELS, ROLES, ACCOUNT_STATUS } from '../config.mjs';
import { getSettings } from '../db.mjs';
import {
  avatar, badge, button, card, confirmButton, dataTable, emptyState, field, html, icon,
  join, matchBadge, noteCategoryBadge, raw, sessionStatusBadge, subjectChip, subjectChips,
} from '../html.mjs';
import {
  addDaysISO, durationLabel, fmtDate, fmtTime, fmtTimeRange, hhmmToMinutes, isoWeekday,
  minutesToHHMM, monthLabel, todayISO, weekDays, weekStartISO, weekdayShort,
} from '../util.mjs';

/* -------------------------------------------------------------------------- */
/* Flash helpers (validation errors / re-filled values)                       */
/* -------------------------------------------------------------------------- */

export const flashErrors = (ctx) => ctx.flash?.errors || {};
export const flashValues = (ctx) => ctx.flash?.values || {};
export const errorFor = (ctx, name) => flashErrors(ctx)[name] || null;
export const valueFor = (ctx, name, fallback = '') => {
  const fromFlash = flashValues(ctx)[name];
  if (fromFlash !== undefined && fromFlash !== '') return fromFlash;
  return fallback;
};

/* -------------------------------------------------------------------------- */
/* Quick actions                                                              */
/* -------------------------------------------------------------------------- */

const QUICK_ACTIONS_ADMIN = [
  { label: 'Schedule session', href: '/admin/sessions/new', icon: 'calendar', permission: 'sessions.manage', variant: 'primary' },
  { label: 'Find tutor match', href: '/admin/matches', icon: 'match', permission: 'matches.view' },
  { label: 'Create invitation', href: '/admin/invitations/new', icon: 'mail', permission: 'invitations.manage' },
  { label: 'Add tutor', href: '/admin/tutors/new', icon: 'plus', permission: 'tutors.manage' },
  { label: 'Add tutee', href: '/admin/tutees/new', icon: 'plus', permission: 'tutees.manage' },
  { label: 'Add subject', href: '/admin/subjects', icon: 'book', permission: 'subjects.manage' },
  { label: 'View this week', href: '/admin/weekly', icon: 'activity', permission: 'sessions.view' },
  { label: 'View availability', href: '/admin/availability', icon: 'grid', permission: 'availability.view' },
  { label: 'Add administrator', href: '/admin/admins/new', icon: 'shield', permission: 'admins.manage' },
];

export function quickActions(ctx, permissions = []) {
  const has = (permission) => permissions.includes('*') || permissions.includes(permission);
  const items = QUICK_ACTIONS_ADMIN.filter((item) => has(item.permission));
  if (!items.length) return null;
  return html`
    <div class="quick-actions" aria-label="Quick actions">
      ${items.map((item) => html`<a class="quick-action" href="${item.href}">
        <span class="quick-action__icon">${icon(item.icon, { size: 16 })}</span>
        <span class="quick-action__label">${item.label}</span>
      </a>`)}
    </div>`;
}

/* -------------------------------------------------------------------------- */
/* Week navigation                                                            */
/* -------------------------------------------------------------------------- */

export function weekNavigator({ weekStart, basePath, params = {}, title = null }) {
  const prev = addDaysISO(weekStart, -7);
  const next = addDaysISO(weekStart, 7);
  const current = weekStartISO();
  const qs = (date) => {
    const search = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) search.set(k, String(v));
    search.set('week', date);
    return `${basePath}?${search.toString()}`;
  };
  return html`
    <div class="weeknav">
      <div class="weeknav__buttons">
        <a class="btn btn--secondary btn--sm" href="${qs(prev)}" rel="prev">${icon('left', { size: 14 })}<span>Previous week</span></a>
        <a class="btn btn--ghost btn--sm" href="${qs(current)}">Today</a>
        <a class="btn btn--secondary btn--sm" href="${qs(next)}" rel="next"><span>Next week</span>${icon('right', { size: 14 })}</a>
      </div>
      <p class="weeknav__label">
        ${title || `Week of ${fmtDate(weekStart, 'long')}`}
        ${weekStart !== current ? html`<span class="muted small">(not the current week)</span>` : badge('Current week', 'primary')}
      </p>
      <form class="weeknav__picker" method="get" action="${basePath}">
        ${Object.entries(params).map(([k, v]) => html`<input type="hidden" name="${k}" value="${v ?? ''}" />`)}
        <label class="sr-only" for="week-picker">Jump to week</label>
        <input class="input input--sm" type="date" id="week-picker" name="week" value="${weekStart}" />
        <button class="btn btn--secondary btn--sm" type="submit">Go</button>
      </form>
    </div>`;
}

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

export function sessionMeta(session, { showTutor = true, showTutee = true } = {}) {
  return html`
    <div class="session-meta">
      ${session.subject_name
        ? html`<span class="session-meta__subject" data-chip-colour="${session.subject_colour || '#475569'}">${session.subject_name}</span>`
        : null}
      ${showTutor && (session.tutor_name || session.tutor_email)
        ? html`<span class="session-meta__person">${icon('user', { size: 13 })}${session.tutor_name || session.tutor_email}</span>`
        : null}
      ${showTutee && (session.tutee_name || session.tutee_email)
        ? html`<span class="session-meta__person">${icon('user', { size: 13 })}${session.tutee_name || session.tutee_email}</span>`
        : null}
      <span class="session-meta__time">${icon('clock', { size: 13 })}${fmtTimeRange(session.start_min, session.end_min)}</span>
      <span class="session-meta__mode">${session.mode === 'online' ? icon('video', { size: 13 }) : icon('pin', { size: 13 })}${SESSION_MODE_LABELS[session.mode] || session.mode}</span>
    </div>`;
}

export function sessionCard(session, { href = `/admin/sessions/${session.id}`, showDate = true } = {}) {
  return html`
    <a class="session-card session-card--${raw(session.status)}" href="${href}">
      <div class="session-card__top">
        <span class="session-card__title">${session.subject_name || 'Session'}</span>
        ${sessionStatusBadge(session.status)}
      </div>
      <p class="session-card__line">${session.tutor_name || session.tutor_email} <span class="muted">with</span> ${session.tutee_name || session.tutee_email}</p>
      <p class="session-card__line session-card__line--time">
        ${showDate ? `${fmtDate(session.date, 'day')} · ` : ''}${fmtTimeRange(session.start_min, session.end_min)} · ${durationLabel(session.end_min - session.start_min)}
      </p>
      ${session.location ? html`<p class="session-card__line muted">${session.location}</p>` : null}
    </a>`;
}

export function sessionsTable(sessions, {
  basePath = '/admin/sessions', showTutor = true, showTutee = true, showDate = true,
  notes = [], actionsFor = null,
} = {}) {
  return dataTable({
    caption: 'Sessions',
    columns: [
      ...(showDate ? [{ label: 'Date' }] : []),
      { label: 'Time' },
      { label: 'Subject' },
      ...(showTutor ? [{ label: 'Tutor' }] : []),
      ...(showTutee ? [{ label: 'Tutee' }] : []),
      { label: 'Mode / location' },
      { label: 'Status' },
      { label: 'Actions', align: 'right' },
    ],
    rows: sessions.map((s) => ({
      cells: [
        ...(showDate ? [html`<a href="${basePath}/${s.id}">${fmtDate(s.date, 'day')}</a>`] : []),
        html`<span class="nowrap">${fmtTimeRange(s.start_min, s.end_min)}</span>`,
        subjectChip({ name: s.subject_name, colour: s.subject_colour }),
        showTutor ? html`<a href="/admin/tutors/${s.tutor_id}">${s.tutor_name || s.tutor_email}</a>` : null,
        showTutee ? html`<a href="/admin/tutees/${s.tutee_id}">${s.tutee_name || s.tutee_email}</a>` : null,
        html`<span class="muted">${SESSION_MODE_LABELS[s.mode] || s.mode}${s.location ? ` · ${s.location}` : ''}</span>`,
        sessionStatusBadge(s.status),
        html`<span class="row-actions">
          <a class="btn btn--ghost btn--sm" href="${basePath}/${s.id}">${icon('eye', { size: 14 })}<span>View</span></a>
          ${actionsFor ? actionsFor(s) : null}
        </span>`,
      ],
    })),
    empty: emptyState({
      title: 'No sessions found',
      message: 'Adjust the filters, or schedule a new session to get started.',
      iconName: 'calendar',
    }),
  });
}

/* -------------------------------------------------------------------------- */
/* Calendars                                                                  */
/* -------------------------------------------------------------------------- */

const calendarHref = (basePath, params, date, mode) => {
  const search = new URLSearchParams();
  for (const [k, v] of Object.entries(params || {})) if (v) search.set(k, String(v));
  search.set('date', date);
  if (mode) search.set('view', mode);
  return `${basePath}?${search.toString()}`;
};

export function calendarToolbar({ view, date, basePath, params = {} }) {
  const views = [
    { key: 'day', label: 'Day' },
    { key: 'week', label: 'Week' },
    { key: 'month', label: 'Month' },
  ];
  const step = view === 'day' ? 1 : view === 'week' ? 7 : 30;
  return html`
    <div class="cal-toolbar">
      <div class="cal-toolbar__group">
        <a class="btn btn--secondary btn--sm" href="${calendarHref(basePath, params, addDaysISO(date, -step), view)}" aria-label="Previous">${icon('left', { size: 14 })}</a>
        <a class="btn btn--ghost btn--sm" href="${calendarHref(basePath, params, todayISO(), view)}">Today</a>
        <a class="btn btn--secondary btn--sm" href="${calendarHref(basePath, params, addDaysISO(date, step), view)}" aria-label="Next">${icon('right', { size: 14 })}</a>
      </div>
      <p class="cal-toolbar__title">${view === 'month' ? monthLabel(date) : view === 'week' ? `Week of ${fmtDate(weekStartISO(date), 'long')}` : fmtDate(date, 'long')}</p>
      <div class="cal-toolbar__group" role="group" aria-label="Calendar view">
        ${views.map((v) => html`<a class="seg ${v.key === view ? 'is-active' : ''}" href="${calendarHref(basePath, params, date, v.key)}" ${v.key === view ? raw('aria-current="true"') : ''}>${v.label}</a>`)}
      </div>
    </div>`;
}

export function calendarMonth({ date, sessions, basePath, params = {}, legend = true }) {
  const first = `${date.slice(0, 7)}-01`;
  const gridStart = weekStartISO(first);
  const cells = [];
  for (let i = 0; i < 42; i += 1) {
    const day = addDaysISO(gridStart, i);
    cells.push({
      date: day,
      inMonth: day.slice(0, 7) === date.slice(0, 7),
      isToday: day === todayISO(),
      sessions: sessions.filter((s) => s.date === day),
    });
  }
  return html`
    <div class="cal cal--month" role="grid" aria-label="Month calendar">
      <div class="cal__head" role="row">
        ${WEEKDAYS.map((d) => html`<span class="cal__head-cell" role="columnheader">${d.short}</span>`)}
      </div>
      <div class="cal__grid cal__grid--month">
        ${cells.map((cell) => html`
          <div class="cal__cell ${cell.inMonth ? '' : 'is-outside'} ${cell.isToday ? 'is-today' : ''}" role="gridcell">
            <a class="cal__date" href="${calendarHref(basePath, params, cell.date, 'day')}">${Number(cell.date.slice(8, 10))}</a>
            ${cell.sessions.slice(0, 3).map((s) => html`
              <a class="cal__chip cal__chip--${raw(s.status)}" href="${basePath.startsWith('/admin') ? `/admin/sessions/${s.id}` : '#'}" title="${s.subject_name} · ${fmtTimeRange(s.start_min, s.end_min)}">
                <span class="cal__chip-time">${fmtTime(s.start_min)}</span>
                <span class="cal__chip-text">${s.subject_name}</span>
              </a>`)}
            ${cell.sessions.length > 3 ? html`<a class="cal__more" href="${calendarHref(basePath, params, cell.date, 'day')}">+${cell.sessions.length - 3} more</a>` : null}
          </div>`)}
      </div>
    </div>
    ${legend ? calendarLegend() : null}`;
}

export function calendarWeek({ weekStart, sessions, basePath, params = {}, sessionHref = (s) => `/admin/sessions/${s.id}`, legend = true }) {
  const days = weekDays(weekStart);
  const settings = getSettings();
  return html`
    <div class="cal cal--week">
      <div class="cal__grid cal__grid--week">
        ${days.map((day) => {
          const daySessions = sessions.filter((s) => s.date === day.date).sort((a, b) => a.start_min - b.start_min);
          return html`
            <section class="cal__day ${day.date === todayISO() ? 'is-today' : ''}" aria-label="${day.name}">
              <header class="cal__day-head">
                <span class="cal__day-name">${day.name}</span>
                <a class="cal__day-date" href="${calendarHref(basePath, params, day.date, 'day')}">${fmtDate(day.date, 'short')}</a>
                ${daySessions.length ? html`<span class="cal__day-count">${daySessions.length}</span>` : null}
              </header>
              <div class="cal__day-body">
                ${daySessions.length
                  ? daySessions.map((s) => html`
                    <a class="cal__event cal__event--${raw(s.status)}" href="${sessionHref(s)}">
                      <span class="cal__event-time">${fmtTime(s.start_min)}–${fmtTime(s.end_min)}</span>
                      <span class="cal__event-subject">${s.subject_name}</span>
                      <span class="cal__event-people">${s.tutor_name || ''}${s.tutor_name && s.tutee_name ? ' · ' : ''}${s.tutee_name || ''}</span>
                    </a>`)
                  : html`<p class="cal__empty muted small">No sessions</p>`}
              </div>
            </section>`;
        })}
      </div>
      <p class="muted small">Day window shown: ${settings.availability_day_start}–${settings.availability_day_end}</p>
    </div>
    ${legend ? calendarLegend() : null}`;
}

export function calendarDay({ date, sessions, sessionHref = (s) => `/admin/sessions/${s.id}`, legend = true }) {
  const list = [...sessions].sort((a, b) => a.start_min - b.start_min);
  return html`
    <div class="cal cal--day">
      <h3 class="cal__day-title">${fmtDate(date, 'long')}</h3>
      ${list.length
        ? html`<ol class="timeline">
            ${list.map((s) => html`
              <li class="timeline__item timeline__item--${raw(s.status)}">
                <span class="timeline__time">${fmtTime(s.start_min)}<small>${durationLabel(s.end_min - s.start_min)}</small></span>
                <a class="timeline__body" href="${sessionHref(s)}">
                  <span class="timeline__subject">${s.subject_name}</span>
                  <span class="timeline__people">${s.tutor_name || s.tutor_email} <span class="muted">with</span> ${s.tutee_name || s.tutee_email}</span>
                  <span class="timeline__meta">${SESSION_MODE_LABELS[s.mode] || s.mode}${s.location ? ` · ${s.location}` : ''}</span>
                </a>
                <span class="timeline__status">${sessionStatusBadge(s.status)}</span>
              </li>`)}
          </ol>`
        : emptyState({ title: 'No sessions on this day', message: 'Pick another date or schedule a session.', iconName: 'calendar' })}
    </div>
    ${legend ? calendarLegend() : null}`;
}

export function calendarLegend() {
  return html`
    <ul class="legend" aria-label="Session status legend">
      ${Object.entries(SESSION_STATUS_LABELS).map(([key, label]) => html`
        <li class="legend__item"><span class="legend__swatch legend__swatch--${raw(key)}" aria-hidden="true"></span>${label}</li>`)}
    </ul>`;
}

/* -------------------------------------------------------------------------- */
/* Availability                                                               */
/* -------------------------------------------------------------------------- */

export function timeOptions(selected, { step = 30, startMin = 8 * 60, endMin = 21 * 60 } = {}) {
  const options = [];
  for (let m = startMin; m <= endMin; m += step) {
    options.push({ value: minutesToHHMM(m), label: fmtTime(m) });
  }
  return options.map((o) => ({ ...o, selected: o.value === selected }));
}

export function availabilityGrid({ days, editable = false, csrf = null, deleteBase = null, showDates = true }) {
  return html`
    <div class="avail-grid">
      ${days.map((day) => html`
        <section class="avail-day ${day.free?.length ? 'is-available' : ''}">
          <header class="avail-day__head">
            <span class="avail-day__name">${day.name || weekdayShort(day.n || isoWeekday(day.date))}</span>
            ${showDates && day.date ? html`<span class="avail-day__date">${fmtDate(day.date, 'short')}</span>` : null}
          </header>
          <div class="avail-day__body">
            ${day.free?.length
              ? html`<ul class="avail-slots">
                  ${day.free.map((iv) => html`<li class="avail-slot">${fmtTimeRange(iv.start, iv.end)}<small>${durationLabel(iv.end - iv.start)}</small></li>`)}
                </ul>`
              : html`<p class="avail-day__none muted small">Unavailable</p>`}
            ${day.slots?.length
              ? html`<ul class="avail-rows">
                  ${day.slots.map((row) => html`
                    <li class="avail-row ${row.state === AVAILABILITY_STATE.UNAVAILABLE ? 'is-unavailable' : ''}">
                      <span class="avail-row__time">${fmtTimeRange(row.start_min, row.end_min)}</span>
                      ${row.state === AVAILABILITY_STATE.UNAVAILABLE ? badge('Unavailable', 'danger') : badge('Available', 'success')}
                      ${row.effective_from || row.effective_to ? badge(`Temp ${row.effective_from || ''}${row.effective_to ? `→${row.effective_to}` : ''}`, 'warning') : null}
                      ${row.note ? html`<span class="muted small">${row.note}</span>` : null}
                      ${editable && deleteBase
                        ? confirmButton({
                            action: `${deleteBase}/${row.id}/delete`,
                            label: 'Remove',
                            variant: 'ghost',
                            confirm: `Remove ${fmtTimeRange(row.start_min, row.end_min)}?`,
                            hidden: { _csrf: csrf },
                            iconName: 'trash',
                          })
                        : null}
                    </li>`)}
                </ul>`
              : null}
          </div>
        </section>`)}
    </div>`;
}

export function availabilityLegend() {
  return html`
    <ul class="legend" aria-label="Availability legend">
      <li class="legend__item"><span class="legend__swatch legend__swatch--available" aria-hidden="true"></span>Available</li>
      <li class="legend__item"><span class="legend__swatch legend__swatch--unavailable" aria-hidden="true"></span>Marked unavailable</li>
      <li class="legend__item"><span class="legend__swatch legend__swatch--busy" aria-hidden="true"></span>Already booked</li>
    </ul>`;
}

/**
 * Full availability editor: weekly recurring slots, temporary windows and
 * date-specific overrides, plus a visual week grid.
 */
export function availabilityEditor({ ctx, actionBase, weeklyDays, extraDateRows = [], timeOptionsRange, compact = false }) {
  const settings = getSettings();
  const step = Number(settings.availability_slot_minutes || 30);
  const startMin = hhmmToMinutes(settings.availability_day_start) ?? 8 * 60;
  const endMin = hhmmToMinutes(settings.availability_day_end) ?? 21 * 60;
  const opts = timeOptionsRange || { step, startMin, endMin };
  const dayOptions = WEEKDAYS.map((d) => ({ value: d.n, label: d.name }));

  return html`
    <div class="stack">
      ${card({
        title: 'Add recurring availability',
        subtitle: 'These slots repeat every week. Add as many periods per day as you need.',
        body: html`
          <form method="post" action="${actionBase}/weekly" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--4">
              ${field({ label: 'Day', name: 'weekday', type: 'select', options: dayOptions, required: true })}
              ${field({ label: 'From', name: 'start', type: 'select', options: timeOptions(null, opts), required: true })}
              ${field({ label: 'To', name: 'end', type: 'select', options: timeOptions(null, opts), required: true })}
              ${field({
                label: 'Type', name: 'state', type: 'select', required: true, options: [
                  { value: AVAILABILITY_STATE.AVAILABLE, label: 'Available' },
                  { value: AVAILABILITY_STATE.UNAVAILABLE, label: 'Unavailable (block)' },
                ],
              })}
            </div>
            <div class="form-grid form-grid--3">
              ${field({ label: 'Effective from (optional)', name: 'effective_from', type: 'date', hint: 'Leave blank for a permanent weekly slot.' })}
              ${field({ label: 'Effective to (optional)', name: 'effective_to', type: 'date', hint: 'Temporary availability has an end date.' })}
              ${field({ label: 'Note (optional)', name: 'note', placeholder: 'e.g. term time only' })}
            </div>
            <div class="form-actions">${button({ label: 'Add availability', iconName: 'plus' })}</div>
          </form>`,
      })}

      ${card({
        title: 'Add date-specific availability',
        subtitle: 'One-off windows that apply to a single date only (they override the weekly pattern).',
        body: html`
          <form method="post" action="${actionBase}/date" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--4">
              ${field({ label: 'Date', name: 'date', type: 'date', required: true, min: todayISO() })}
              ${field({ label: 'From', name: 'start', type: 'select', options: timeOptions(null, opts), required: true })}
              ${field({ label: 'To', name: 'end', type: 'select', options: timeOptions(null, opts), required: true })}
              ${field({
                label: 'Type', name: 'state', type: 'select', required: true, options: [
                  { value: AVAILABILITY_STATE.AVAILABLE, label: 'Available' },
                  { value: AVAILABILITY_STATE.UNAVAILABLE, label: 'Unavailable (block)' },
                ],
              })}
            </div>
            <div class="form-actions">${button({ label: 'Add date-specific slot', iconName: 'plus' })}</div>
          </form>`,
      })}

      ${card({
        title: 'Recorded availability',
        subtitle: 'Remove a period with the delete button. Recurring slots are grouped by day.',
        body: html`
          ${availabilityGrid({
            days: weeklyDays,
            editable: true,
            csrf: ctx.csrfToken,
            deleteBase: actionBase,
          })}
          ${extraDateRows.length
            ? html`<h3 class="subhead">Upcoming date-specific entries</h3>
                <ul class="avail-rows">
                  ${extraDateRows.map((row) => html`
                    <li class="avail-row ${row.state === AVAILABILITY_STATE.UNAVAILABLE ? 'is-unavailable' : ''}">
                      <span class="avail-row__time">${fmtDate(row.date, 'day')} · ${fmtTimeRange(row.start_min, row.end_min)}</span>
                      ${row.state === AVAILABILITY_STATE.UNAVAILABLE ? badge('Unavailable', 'danger') : badge('Available', 'success')}
                      ${row.note ? html`<span class="muted small">${row.note}</span>` : null}
                      ${confirmButton({
                        action: `${actionBase}/${row.id}/delete`,
                        label: 'Remove',
                        variant: 'ghost',
                        confirm: `Remove ${fmtDate(row.date, 'day')} ${fmtTimeRange(row.start_min, row.end_min)}?`,
                        hidden: { _csrf: ctx.csrfToken },
                        iconName: 'trash',
                      })}
                    </li>`)}
                </ul>`
            : null}`,
      })}
    </div>`;
}

/* -------------------------------------------------------------------------- */
/* Matching                                                                   */
/* -------------------------------------------------------------------------- */

export const MATCH_STATUS_ICON = {
  available: 'check',
  partial: 'warning',
  busy: 'warning',
  no_overlap: 'x',
  no_subject: 'x',
  assigned: 'link',
  inactive: 'lock',
};

export function matchWindows(windows, { limit = 4 } = {}) {
  if (!windows?.length) return html`<span class="muted">No overlapping free time</span>`;
  const shown = windows.slice(0, limit);
  return html`
    <ul class="window-list">
      ${shown.map((w) => html`<li class="window-list__item">
        <strong>${w.weekday}</strong> ${fmtTimeRange(w.start, w.end)}
        <span class="muted small">${durationLabel(w.minutes)}</span>
      </li>`)}
      ${windows.length > limit ? html`<li class="muted small">+${windows.length - limit} more window${windows.length - limit === 1 ? '' : 's'}</li>` : null}
    </ul>`;
}

export function matchTable(rows, {
  mode = 'tutor', ctx, actionBase = '/admin/matches', tuteeId = null, tutorId = null,
  assignable = true, sessionDate = null,
} = {}) {
  const columns = [
    { label: mode === 'tutor' ? 'Tutor' : 'Tutee' },
    { label: 'Subjects matched' },
    { label: 'Matching availability' },
    { label: 'Totals' },
    { label: mode === 'tutor' ? 'Workload' : 'Needs' },
    { label: 'Status' },
    { label: 'Actions', align: 'right' },
  ];
  return dataTable({
    caption: 'Matching suggestions',
    columns,
    rows: rows.map((row) => {
      const personId = mode === 'tutor' ? row.tutorId : row.tuteeId;
      const personName = mode === 'tutor' ? row.tutorName : row.tuteeName;
      const personHref = mode === 'tutor' ? `/admin/tutors/${personId}` : `/admin/tutees/${personId}`;
      const assignSubject = row.matchedSubjects?.[0];
      return {
        cells: [
          html`<div class="person-cell">
            ${avatar({ name: personName, photo: row.tutorPhoto })}
            <div><a href="${personHref}">${personName}</a><br /><span class="muted small">${row.tutorEmail || row.tuteeEmail}</span></div>
          </div>`,
          subjectChips(row.matchedSubjects || [], { empty: 'No shared subject' }),
          matchWindows(row.windows),
          html`<span class="muted small">${durationLabel(row.overlapMinutes || 0)} of overlap over ${(row.windows?.length || 0)} window${(row.windows?.length || 0) === 1 ? '' : 's'}</span>`,
          mode === 'tutor'
            ? html`<span>${row.studentCount} / ${row.maxStudents} tutees<br /><span class="muted small">${row.sessionsPlanned} session${row.sessionsPlanned === 1 ? '' : 's'} planned</span></span>`
            : html`<span class="muted small">${row.assigned ? 'Already assigned' : 'Awaiting tutor'}</span>`,
          matchBadge(row.status),
          html`<span class="row-actions">
            ${mode === 'tutor'
              ? html`
                ${assignable && assignSubject && ctx && (ctx.permissions.includes('*') || ctx.permissions.includes('assignments.manage'))
                  ? html`<form class="inline-form" method="post" action="/admin/assignments">
                      <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                      <input type="hidden" name="tutor_id" value="${personId}" />
                      <input type="hidden" name="tutee_id" value="${tuteeId}" />
                      <input type="hidden" name="subject_id" value="${assignSubject.id}" />
                      <input type="hidden" name="redirect_to" value="${actionBase}?tutee=${tuteeId}" />
                      ${button({ label: 'Assign', variant: 'secondary', size: 'sm', iconName: 'check' })}
                    </form>`
                  : null}
                ${ctx && (ctx.permissions.includes('*') || ctx.permissions.includes('sessions.manage'))
                  ? html`<a class="btn btn--ghost btn--sm" href="/admin/sessions/new?tutor=${personId}&tutee=${tuteeId}${assignSubject ? `&subject=${assignSubject.id}` : ''}${row.windows?.[0] ? `&date=${row.windows[0].date}&start=${minutesToHHMM(row.windows[0].start)}&end=${minutesToHHMM(row.windows[0].end)}` : ''}">${icon('calendar', { size: 14 })}<span>Schedule</span></a>`
                  : null}`
              : html`<a class="btn btn--ghost btn--sm" href="/admin/tutees/${personId}">${icon('eye', { size: 14 })}<span>View</span></a>`}
          </span>`,
        ],
      };
    }),
    empty: emptyState({
      title: 'No matching candidates',
      message: 'Availability or subject information may be missing for this person. Check their profile and availability.',
      iconName: 'match',
    }),
  });
}

/* -------------------------------------------------------------------------- */
/* Person cells & status forms                                                */
/* -------------------------------------------------------------------------- */

export function personCell({ name, email, href, photo = null, meta = null }) {
  return html`<div class="person-cell">
    ${avatar({ name, photo })}
    <div>
      <a href="${href}">${name || email || 'Unknown'}</a>
      <br /><span class="muted small">${meta || email}</span>
    </div>
  </div>`;
}

export function statusOptions(current, { allow = [] } = {}) {
  const all = Object.values(ACCOUNT_STATUS).filter((s) => s !== 'locked');
  return all.filter((s) => s === current || !allow.length || allow.includes(s)).map((s) => ({
    value: s,
    label: s === 'active' ? 'Active' : s === 'pending' ? 'Pending activation' : 'Disabled',
  }));
}

/**
 * Session status update form. Tutors get a reduced set of transitions.
 */
export function sessionStatusForm(session, ctx, { action, role = 'admin' } = {}) {
  const settings = getSettings();
  const allowTutor = settings.allow_tutor_status_updates !== 'false';
  const transitions = {
    scheduled: role === 'admin' ? ['confirmed', 'running', 'completed', 'cancelled', 'missed'] : (allowTutor ? ['completed', 'running', 'cancelled'] : []),
    confirmed: role === 'admin' ? ['running', 'completed', 'cancelled', 'missed'] : (allowTutor ? ['completed', 'running', 'cancelled'] : []),
    running: role === 'admin' ? ['completed', 'cancelled', 'missed'] : (allowTutor ? ['completed'] : []),
    completed: role === 'admin' ? ['confirmed'] : [],
    cancelled: role === 'admin' ? ['scheduled'] : [],
    missed: role === 'admin' ? ['scheduled', 'completed'] : [],
    rescheduled: [],
  }[session.status] || [];
  if (!transitions.length) {
    return html`<p class="muted small">This session is ${SESSION_STATUS_LABELS[session.status]?.toLowerCase() || session.status} — no further status changes are available.</p>`;
  }
  // Only a Super Admin may knowingly force a status change that the normal
  // workflow would refuse; the server re-checks the permission.
  const mayOverride = role === 'admin' && ctx.user?.role === ROLES.SUPER_ADMIN;
  return html`
    <form method="post" action="${action}" class="form form--inline">
      <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
      <div class="form-grid form-grid--3">
        ${field({
          label: 'New status', name: 'status', type: 'select', required: true,
          options: transitions.map((s) => ({ value: s, label: SESSION_STATUS_LABELS[s] })),
        })}
        ${field({ label: 'Reason / note (optional)', name: 'reason', placeholder: 'Visible in the session history' })}
        ${mayOverride
          ? field({
            label: 'Allow an out-of-order change', name: 'override', type: 'checkbox',
            hint: 'Super Admin only. Use when a status was recorded in error; the change is written to the activity log.',
          })
          : null}
        <div class="field field--action">${button({ label: 'Update status', iconName: 'refresh' })}</div>
      </div>
    </form>`;
}

export function notesList(notes, { empty = 'No notes recorded for this session yet.' } = {}) {
  if (!notes?.length) return emptyState({ title: 'No session notes', message: empty, iconName: 'edit' });
  return html`
    <ul class="notes">
      ${notes.map((note) => html`
        <li class="note">
          <header class="note__head">
            ${noteCategoryBadge(note.category)}
            ${note.visibility !== NOTE_VISIBILITY.ALL ? badge(noteVisibilityText(note.visibility), 'neutral') : null}
            <span class="note__author">${note.author_name || 'System'} ${note.author_role ? html`<span class="muted small">(${ROLE_LABELS[note.author_role] || note.author_role})</span>` : null}</span>
            <time class="muted small" datetime="${note.created_at}">${fmtDate(String(note.created_at).slice(0, 10), 'short')}</time>
          </header>
          <p class="note__body">${note.body}</p>
        </li>`)}
    </ul>`;
}

const noteVisibilityText = (visibility) => (visibility === NOTE_VISIBILITY.PRIVATE ? 'Admins only' : 'Tutor & admins');

export function subjectOptions(subjects, selected = []) {
  return subjects.map((s) => ({ value: s.id, label: s.name, checked: selected.includes(Number(s.id)) }));
}

export function peopleSelectOptions(people, { valueKey = 'id', labelKey = 'full_name' } = {}) {
  return people.map((p) => ({ value: p[valueKey], label: p[labelKey] || p.email }));
}

export { join, MATCH_STATUS, ROLE_LABELS };
