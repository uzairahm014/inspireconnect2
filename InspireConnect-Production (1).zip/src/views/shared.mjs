/**
 * Views shared by all three portals: session detail, notifications and the
 * administrator global search results.
 */
import { NOTE_VISIBILITY, SESSION_MODE_LABELS, SESSION_NOTE_CATEGORIES, SESSION_STATUS, SESSION_STATUS_LABELS, INVITATION_STATUS, ROLE_LABELS, MATCH_STATUS } from '../config.mjs';
import { getSettings } from '../db.mjs';
import {
  alert, avatar, badge, button, card, confirmButton, dataTable, definitionList, emptyState,
  field, html, icon, join, raw, sessionStatusBadge, subjectChip, subjectChips, tabs,
} from '../html.mjs';
import { addDaysISO, durationLabel, fmtDate, fmtDateTime, fmtTime, fmtTimeRange, minutesToHHMM, paginationQuery, todayISO, weekStartISO, relativeTime } from '../util.mjs';
import { notesList, sessionStatusForm } from './partials.mjs';
import { pagination } from '../html.mjs';

/* -------------------------------------------------------------------------- */
/* Session detail                                                             */
/* -------------------------------------------------------------------------- */

export function sessionDetailPage({
  ctx, detail, portal = 'admin', actionBase = '/admin/sessions', backHref = '/admin/sessions',
  canManage = false, canStatus = false, canNote = false, warnings = [], peopleCards = true,
}) {
  const { session, notes, history, rescheduledFrom, rescheduledTo } = detail;
  const settings = getSettings();
  const sessionHref = (id) => `${actionBase}/${id}`;

  return html`
    <div class="page-head">
      <div>
        <nav class="crumbs" aria-label="Breadcrumb">
          <a href="${backHref}">Sessions</a> <span aria-hidden="true">/</span> <span>Session #${session.id}</span>
        </nav>
        <h1 class="page-title">${session.subject_name} session</h1>
        <p class="page-subtitle">
          ${fmtDate(session.date, 'long')} · ${fmtTimeRange(session.start_min, session.end_min)}
          · ${durationLabel(session.end_min - session.start_min)}
        </p>
      </div>
      <div class="page-actions">
        ${sessionStatusBadge(session.status)}
        ${canManage ? html`<a class="btn btn--secondary btn--sm" href="${actionBase}/${session.id}/edit">${icon('edit', { size: 14 })}<span>Edit</span></a>` : null}
      </div>
    </div>

    ${warnings?.length ? alert('Scheduling checks reported the following:', 'warning', { title: 'Conflicts & availability', list: warnings }) : null}

    <div class="grid grid--2">
      ${card({
        title: 'Session details',
        body: definitionList([
          ['Tutor', session.tutor_id ? html`<a href="${portal === 'admin' ? `/admin/tutors/${session.tutor_id}` : '#'}">${session.tutor_name || session.tutor_email}</a>` : null],
          ['Tutee', session.tutee_id ? html`<a href="${portal === 'admin' ? `/admin/tutees/${session.tutee_id}` : '#'}">${session.tutee_name || session.tutee_email}</a>` : null],
          ['Subject', subjectChip({ name: session.subject_name, colour: session.subject_colour })],
          ['Date', fmtDate(session.date, 'long')],
          ['Time', `${fmtTimeRange(session.start_min, session.end_min)} (${durationLabel(session.end_min - session.start_min)})`],
          ['Mode', SESSION_MODE_LABELS[session.mode] || session.mode],
          ['Location', session.location || (session.mode === 'online' ? 'Online' : null)],
          ['Meeting link', session.meeting_link ? html`<a href="${session.meeting_link}" rel="noreferrer nofollow noopener" target="_blank">${session.meeting_link}</a>` : null],
          ['Created', `${fmtDateTime(session.created_at)}`],
          ['Last updated', session.updated_at ? fmtDateTime(session.updated_at) : null],
          ['Completed', session.completed_at ? fmtDateTime(session.completed_at) : null],
          ['Cancellation reason', session.cancel_reason || null],
          ['Series', session.series_id ? html`<span class="muted">Recurring series ${session.series_id.slice(0, 6)}</span>` : null],
          ['Notes', session.notes || null],
        ]),
      })}

      ${card({
        title: 'Scheduling checks',
        subtitle: 'Live availability and double-booking status for this session.',
        body: html`
          <ul class="checklist checklist--status">
            ${checkItem('Tutor double-booking', !warnings.some((w) => /already booked/i.test(w) && /tutor/i.test(w)))}
            ${checkItem('Tutee double-booking', !warnings.some((w) => /already booked/i.test(w) && /tutee/i.test(w)))}
            ${checkItem('Inside stated availability', !warnings.some((w) => /availability/i.test(w)))}
            ${checkItem('Assignment exists for this pairing', !warnings.some((w) => /assignment/i.test(w)))}
            ${checkItem('Valid session window', session.end_min > session.start_min)}
          </ul>
          ${session.rescheduled_from_id
            ? html`<p class="muted small">Rescheduled from <a href="${sessionHref(session.rescheduled_from_id)}">session #${session.rescheduled_from_id}</a>.</p>`
            : null}
          ${rescheduledTo ? html`<p class="muted small">This session was rescheduled to <a href="${sessionHref(rescheduledTo.id)}">session #${rescheduledTo.id}</a> (${fmtDate(rescheduledTo.date, 'day')}).</p>` : null}
        `,
      })}
    </div>

    ${peopleCards ? html`<div class="grid grid--2">
      ${card({
        title: 'Tutor',
        actions: portal === 'admin' ? html`<a class="btn btn--ghost btn--sm" href="/admin/tutors/${session.tutor_id}">Open profile</a>` : null,
        body: html`<div class="person-summary">
          ${avatar({ name: session.tutor_name || session.tutor_email, photo: session.tutor_photo, size: 'lg' })}
          <div>
            <p class="person-summary__name">${session.tutor_name || session.tutor_email}</p>
            <p class="muted small">${session.tutor_email}</p>
          </div>
        </div>`,
      })}
      ${card({
        title: 'Tutee',
        actions: portal === 'admin' ? html`<a class="btn btn--ghost btn--sm" href="/admin/tutees/${session.tutee_id}">Open profile</a>` : null,
        body: html`<div class="person-summary">
          ${avatar({ name: session.tutee_name || session.tutee_email, photo: session.tutee_photo, size: 'lg' })}
          <div>
            <p class="person-summary__name">${session.tutee_name || session.tutee_email}</p>
            <p class="muted small">${session.tutee_email}</p>
          </div>
        </div>`,
      })}
    </div>` : null}

    <div class="grid grid--2">
      ${canStatus || canManage
        ? card({
            title: 'Update status',
            subtitle: 'Status changes are recorded in the session history.',
            body: html`
              ${sessionStatusForm(session, ctx, { action: `${actionBase}/${session.id}/status`, role: canManage ? 'admin' : 'tutor' })}
              ${canManage && ![SESSION_STATUS.CANCELLED, SESSION_STATUS.RESCHEDULED, SESSION_STATUS.COMPLETED].includes(session.status)
                ? html`<hr class="divider" />
                  <form method="post" action="${actionBase}/${session.id}/cancel" class="form">
                    <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                    <div class="form-grid form-grid--2">
                      ${field({ label: 'Cancel reason', name: 'reason', placeholder: 'e.g. tutor illness — notified by phone' })}
                      <div class="field field--action">${button({ label: 'Cancel session', variant: 'danger', iconName: 'x', confirm: 'Cancel this session for both the tutor and the tutee?' })}</div>
                    </div>
                  </form>`
                : null}`,
          })
        : null}

      ${canManage
        ? card({
            title: 'Reschedule',
            subtitle: 'The original session is kept as history and a linked replacement is created.',
            body: html`
              <form method="post" action="${actionBase}/${session.id}/reschedule" class="form">
                <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                <div class="form-grid form-grid--3">
                  ${field({ label: 'New date', name: 'date', type: 'date', required: true, value: addDaysISO(session.date, 7) })}
                  ${field({ label: 'Start', name: 'start', type: 'time', required: true, value: minutesToHHMM(session.start_min) })}
                  ${field({ label: 'End', name: 'end', type: 'time', required: true, value: minutesToHHMM(session.end_min) })}
                </div>
                ${field({ label: 'Reason (optional)', name: 'reason', placeholder: 'Recorded on both sessions' })}
                <div class="form-actions">${button({ label: 'Reschedule session', iconName: 'refresh', confirm: 'Move this session and keep the original as history?' })}</div>
              </form>`,
          })
        : null}
    </div>

    ${card({
      title: 'Session notes',
      subtitle: 'Topics covered, homework, progress and follow-up items.',
      actions: canNote
        ? html`<a class="btn btn--secondary btn--sm" href="#add-note">${icon('plus', { size: 14 })}<span>Add note</span></a>`
        : null,
      body: html`
        ${notesList(notes)}
        ${canNote
          ? html`<div id="add-note" class="note-form">
              <h3 class="subhead">Add a note</h3>
              <form method="post" action="${actionBase}/${session.id}/notes" class="form">
                <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                <div class="form-grid form-grid--2">
                  ${field({
                    label: 'Category', name: 'category', type: 'select', required: true,
                    options: Object.entries(SESSION_NOTE_CATEGORIES).map(([value, label]) => ({ value, label })),
                  })}
                  ${field({
                    label: 'Visible to', name: 'visibility', type: 'select', required: true,
                    options: portal === 'admin'
                      ? [
                          { value: NOTE_VISIBILITY.ALL, label: 'Tutor, tutee & administrators' },
                          { value: NOTE_VISIBILITY.STAFF_TUTOR, label: 'Tutor & administrators' },
                          { value: NOTE_VISIBILITY.PRIVATE, label: 'Administrators only' },
                        ]
                      : [
                          { value: NOTE_VISIBILITY.ALL, label: 'Everyone involved' },
                          { value: NOTE_VISIBILITY.STAFF_TUTOR, label: 'Tutor & administrators' },
                        ],
                    hint: portal === 'admin' ? 'Private notes are hidden from tutors and tutees.' : null,
                  })}
                </div>
                ${field({ label: 'Note', name: 'body', type: 'textarea', rows: 4, required: true, placeholder: 'What was covered? What should happen next?' })}
                <div class="form-actions">${button({ label: 'Save note', iconName: 'check' })}</div>
              </form>
            </div>`
          : null}`,
    })}

    ${card({
      title: 'Status history',
      subtitle: 'Every change is retained for record keeping.',
      body: history?.length
        ? html`<ol class="history">
            ${history.map((h) => html`<li class="history__item">
              <span class="history__when">${fmtDateTime(h.created_at)}</span>
              <span class="history__what">
                ${h.from_status ? html`${SESSION_STATUS_LABELS[h.from_status] || h.from_status} → ` : ''}
                <strong>${SESSION_STATUS_LABELS[h.to_status] || h.to_status}</strong>
                ${h.note ? html`<span class="muted"> · ${h.note}</span>` : null}
              </span>
              <span class="history__who muted small">${h.actor_label || 'system'}</span>
            </li>`)}
          </ol>`
        : emptyState({ title: 'No history yet', message: 'Status changes will appear here.' }),
    })}

    ${rescheduledFrom ? html`<p class="muted small">Previous session: <a href="${sessionHref(rescheduledFrom.id)}">#${rescheduledFrom.id}</a> on ${fmtDate(rescheduledFrom.date, 'day')}</p>` : null}`;
}

function checkItem(label, ok) {
  return html`<li class="${ok ? 'is-ok' : 'is-warn'}">
    ${icon(ok ? 'check' : 'warning', { size: 15 })}
    <span>${label}${ok ? '' : html` <span class="muted small">— review before confirming</span>`}</span>
  </li>`;
}

/* -------------------------------------------------------------------------- */
/* Notifications                                                              */
/* -------------------------------------------------------------------------- */

const NOTIFICATION_TONES = {
  registration: 'info', registration_approved: 'success', invitation_used: 'success',
  invitation_expiring: 'warning', tutor_assigned: 'primary', session_scheduled: 'success',
  session_changed: 'warning', session_cancelled: 'danger', session_reminder: 'info',
  availability_conflict: 'warning', match_found: 'primary', system: 'neutral',
};

export function notificationsPage({ ctx, list, basePath = '/admin/notifications', filter = 'all', pageInfo = null, params = {} }) {
  return html`
    <div class="page-head">
      <div>
        <h1 class="page-title">Notifications</h1>
        <p class="page-subtitle">${list.unread} unread of ${list.total} notifications.</p>
      </div>
      <div class="page-actions">
        <form method="post" action="${basePath}/read-all" class="inline-form">
          <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
          ${button({ label: 'Mark all as read', variant: 'secondary', size: 'sm', iconName: 'check', disabled: !list.unread })}
        </form>
      </div>
    </div>

    ${tabs([
      { key: 'all', label: 'All', href: basePath, count: list.total },
      { key: 'unread', label: 'Unread', href: `${basePath}?filter=unread`, count: list.unread },
    ], filter)}

    ${list.rows.length
      ? html`<ul class="notification-list">
          ${list.rows.map((n) => html`
            <li class="notification ${n.read_at ? '' : 'is-unread'}">
              <span class="notification__dot notification__dot--${raw(NOTIFICATION_TONES[n.type] || 'neutral')}" aria-hidden="true"></span>
              <div class="notification__body">
                <p class="notification__title">${n.title}</p>
                ${n.body ? html`<p class="notification__text">${n.body}</p>` : null}
                <p class="muted small">
                  ${relativeTime(n.created_at)} · ${fmtDateTime(n.created_at)}
                  ${n.link ? html` · <a href="${n.link}">Open</a>` : null}
                </p>
              </div>
              <div class="notification__actions">
                ${!n.read_at
                  ? html`<form method="post" action="${basePath}/${n.id}/read" class="inline-form">
                      <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                      ${button({ label: 'Mark read', variant: 'ghost', size: 'sm' })}
                    </form>`
                  : null}
              </div>
            </li>`)}
        </ul>`
      : emptyState({ title: 'No notifications', message: filter === 'unread' ? 'You are all caught up.' : 'Notifications about registrations, sessions and invitations will appear here.', iconName: 'bell' })}

    ${pageInfo ? pagination(pageInfo, basePath, params) : null}`;
}

/* -------------------------------------------------------------------------- */
/* Global search                                                              */
/* -------------------------------------------------------------------------- */

export function searchPage({ ctx, query, results, counts }) {
  const hasResults = Object.values(counts).some((c) => c > 0);
  return html`
    <div class="page-head">
      <div>
        <h1 class="page-title">Search results</h1>
        <p class="page-subtitle">${query ? `Showing matches for “${query}”` : 'Enter a name, email, subject or date to search.'}</p>
      </div>
      <div class="page-actions">
        <form class="filterbar" method="get" action="/admin/search" role="search">
          <label class="sr-only" for="q">Search</label>
          <input class="input" id="q" type="search" name="q" value="${query}" placeholder="Name, email, subject, date…" />
          <button class="btn btn--primary btn--sm" type="submit">${icon('search', { size: 14 })}<span>Search</span></button>
        </form>
      </div>
    </div>

    ${!query
      ? emptyState({ title: 'Search everything', message: 'Find tutors, tutees, sessions, subjects, invitations and administrators.', iconName: 'search' })
      : !hasResults
        ? emptyState({ title: 'No matches found', message: 'Try a different spelling, an email address or a date (YYYY-MM-DD).', iconName: 'search' })
        : html`
          ${results.tutors.length
            ? card({
                title: `Tutors (${counts.tutors})`,
                padded: false,
                body: dataTable({
                  columns: [{ label: 'Name' }, { label: 'Email' }, { label: 'Subjects' }, { label: 'Status' }],
                  rows: results.tutors.map((t) => ({
                    cells: [
                      html`<a href="/admin/tutors/${t.id}">${t.full_name || t.email}</a>`,
                      t.email,
                      subjectChips((t.subject_names || '').split(', ').filter(Boolean).map((name) => ({ name }))),
                      badge(t.status, t.status === 'active' ? 'success' : 'warning'),
                    ],
                  })),
                }),
              })
            : null}
          ${results.tutees.length
            ? card({
                title: `Tutees (${counts.tutees})`,
                padded: false,
                body: dataTable({
                  columns: [{ label: 'Name' }, { label: 'Email' }, { label: 'Subjects needed' }, { label: 'Status' }],
                  rows: results.tutees.map((t) => ({
                    cells: [
                      html`<a href="/admin/tutees/${t.id}">${t.full_name || t.email}</a>`,
                      t.email,
                      subjectChips((t.subject_names || '').split(', ').filter(Boolean).map((name) => ({ name }))),
                      badge(t.status, t.status === 'active' ? 'success' : 'warning'),
                    ],
                  })),
                }),
              })
            : null}
          ${results.sessions.length
            ? card({
                title: `Sessions (${counts.sessions})`,
                padded: false,
                body: dataTable({
                  columns: [{ label: 'Date' }, { label: 'Time' }, { label: 'Subject' }, { label: 'Tutor' }, { label: 'Tutee' }, { label: 'Status' }],
                  rows: results.sessions.map((s) => ({
                    cells: [
                      html`<a href="/admin/sessions/${s.id}">${fmtDate(s.date, 'day')}</a>`,
                      fmtTimeRange(s.start_min, s.end_min),
                      s.subject_name,
                      s.tutor_name || s.tutor_email,
                      s.tutee_name || s.tutee_email,
                      sessionStatusBadge(s.status),
                    ],
                  })),
                }),
              })
            : null}
          ${results.subjects.length
            ? card({
                title: `Subjects (${counts.subjects})`,
                body: html`<div class="chip-row">${results.subjects.map((s) => subjectChip(s))}</div>`,
              })
            : null}
          ${results.invitations.length
            ? card({
                title: `Invitations (${counts.invitations})`,
                padded: false,
                body: dataTable({
                  columns: [{ label: 'Email' }, { label: 'Role' }, { label: 'Expires' }, { label: 'Status' }],
                  rows: results.invitations.map((i) => ({
                    cells: [
                      i.email,
                      ROLE_LABELS[i.role] || i.role,
                      fmtDate(String(i.expires_at).slice(0, 10), 'short'),
                      badge(i.status, i.status === 'pending' ? 'info' : i.status === 'used' ? 'success' : 'neutral'),
                    ],
                  })),
                }),
              })
            : null}`}`;
}

export { join, MATCH_STATUS, INVITATION_STATUS, weekStartISO, todayISO };
