/**
 * Application shell: <head>, sidebar navigation (per portal, permission aware),
 * topbar with global search / notification bell / account menu, flash messages.
 */
import { config, ROLE_LABELS, ACCOUNT_STATUS, DEFAULT_BRAND } from '../config.mjs';
import { can } from '../auth.mjs';
import { avatar, badge, icon, raw, html } from '../html.mjs';
import { getSettings } from '../db.mjs';

const VERSION = '1.0.0';

const ADMIN_NAV = [
  { key: 'dashboard', label: 'Dashboard', href: '/admin', icon: 'dashboard' },
  { key: 'timetable', label: 'Timetable', href: '/admin/timetable', icon: 'calendar', permission: 'timetable.view' },
  { key: 'weekly', label: 'Weekly tracking', href: '/admin/weekly', icon: 'activity', permission: 'sessions.view' },
  { key: 'sessions', label: 'Sessions', href: '/admin/sessions', icon: 'clock', permission: 'sessions.view' },
  { key: 'matches', label: 'Matching', href: '/admin/matches', icon: 'match', permission: 'matches.view' },
  { key: 'tutors', label: 'Tutors', href: '/admin/tutors', icon: 'users', permission: 'tutors.view' },
  { key: 'tutees', label: 'Tutees', href: '/admin/tutees', icon: 'user', permission: 'tutees.view' },
  { key: 'assignments', label: 'Assignments', href: '/admin/assignments', icon: 'link', permission: 'assignments.manage' },
  { key: 'availability', label: 'Availability', href: '/admin/availability', icon: 'grid', permission: 'availability.view' },
  { key: 'subjects', label: 'Subjects', href: '/admin/subjects', icon: 'book', permission: 'subjects.view' },
  { group: 'Administration' },
  { key: 'invitations', label: 'Invitations', href: '/admin/invitations', icon: 'mail', permission: 'invitations.view' },
  { key: 'admins', label: 'Administrators', href: '/admin/admins', icon: 'shield', permission: 'admins.view' },
  { key: 'reports', label: 'Reports', href: '/admin/reports', icon: 'report', permission: 'reports.view' },
  { key: 'audit', label: 'Activity log', href: '/admin/audit', icon: 'activity', permission: 'audit.view' },
  { key: 'settings', label: 'Settings', href: '/admin/settings', icon: 'settings', permission: 'settings.view' },
];

const TUTOR_NAV = [
  { key: 'dashboard', label: 'Dashboard', href: '/tutor', icon: 'dashboard' },
  { key: 'timetable', label: 'My timetable', href: '/tutor/timetable', icon: 'calendar' },
  { key: 'sessions', label: 'My sessions', href: '/tutor/sessions', icon: 'clock' },
  { key: 'students', label: 'My students', href: '/tutor/students', icon: 'users' },
  { key: 'availability', label: 'My availability', href: '/tutor/availability', icon: 'grid' },
  { key: 'profile', label: 'My profile', href: '/tutor/profile', icon: 'user' },
];

const TUTEE_NAV = [
  { key: 'dashboard', label: 'Dashboard', href: '/student', icon: 'dashboard' },
  { key: 'timetable', label: 'My timetable', href: '/student/timetable', icon: 'calendar' },
  { key: 'sessions', label: 'My sessions', href: '/student/sessions', icon: 'clock' },
  { key: 'tutor', label: 'My tutor', href: '/student/tutor', icon: 'users' },
  { key: 'availability', label: 'My availability', href: '/student/availability', icon: 'grid' },
  { key: 'profile', label: 'My profile', href: '/student/profile', icon: 'user' },
];

export function navFor(portal, user) {
  const items = portal === 'tutor' ? TUTOR_NAV : portal === 'tutee' ? TUTEE_NAV : ADMIN_NAV;
  return items.filter((item) => !item.permission || can(user, item.permission));
}

function sidebarNav(ctx, portal, active) {
  const items = navFor(portal, ctx.user);
  return html`
    <nav class="nav" aria-label="Main navigation">
      ${items.map((item) => (item.group
        ? html`<p class="nav__group">${item.group}</p>`
        : html`<a class="nav__link ${item.key === active ? 'is-active' : ''}" href="${item.href}"
                 ${item.key === active ? raw('aria-current="page"') : ''}>
            ${icon(item.icon, { size: 18 })}<span>${item.label}</span>
            ${item.key === 'dashboard' && ctx.navCounts?.invitationsPending ? html`<span class="nav__pill">${ctx.navCounts.invitationsPending}</span>` : null}
            ${item.key === 'dashboard' && ctx.navCounts?.conflicts ? html`<span class="nav__pill nav__pill--warn">${ctx.navCounts.conflicts}</span>` : null}
          </a>`))}
    </nav>`;
}

function notificationBell(ctx, portal) {
  const unread = ctx.navCounts?.unreadNotifications || 0;
  const items = ctx.navCounts?.recentNotifications || [];
  const base = portal === 'tutor' ? '/tutor' : portal === 'tutee' ? '/student' : '/admin';
  return html`
    <details class="menu menu--notifications">
      <summary class="topbar__icon-btn" aria-label="Notifications${unread ? `, ${unread} unread` : ''}">
        ${icon('bell', { size: 18 })}
        ${unread ? html`<span class="dot-badge">${unread > 9 ? '9+' : unread}</span>` : null}
      </summary>
      <div class="menu__panel" role="dialog" aria-label="Notifications">
        <div class="menu__head">
          <strong>Notifications</strong>
          <a href="${base}/notifications">View all</a>
        </div>
        ${items.length
          ? html`<ul class="menu__list">
              ${items.map((n) => html`<li class="menu__item ${n.read_at ? '' : 'is-unread'}">
                <a href="${n.link || `${base}/notifications`}">
                  <span class="menu__item-title">${n.title}</span>
                  ${n.body ? html`<span class="menu__item-body">${n.body}</span>` : null}
                </a>
              </li>`)}
            </ul>`
          : html`<p class="menu__empty">You have no notifications yet.</p>`}
      </div>
    </details>`;
}

function accountMenu(ctx, portal) {
  const user = ctx.user;
  const name = ctx.userName || user.email;
  const profileHref = portal === 'tutor' ? '/tutor/profile' : portal === 'tutee' ? '/student/profile' : '/admin/settings';
  return html`
    <details class="menu menu--account">
      <summary class="account-chip">
        ${avatar({ name, photo: ctx.userPhoto })}
        <span class="account-chip__text">
          <span class="account-chip__name">${name}</span>
          <span class="account-chip__role">${ROLE_LABELS[user.role] || user.role}</span>
        </span>
      </summary>
      <div class="menu__panel menu__panel--right" role="dialog" aria-label="Account menu">
        <div class="menu__head"><strong>${name}</strong><span class="muted">${user.email}</span></div>
        <ul class="menu__list menu__list--plain">
          ${user.role === 'tutor' || user.role === 'tutee' ? html`<li><a href="${profileHref}">${icon('user', { size: 16 })}<span>My profile</span></a></li>` : null}
          <li><a href="${portal === 'admin' ? '/admin/notifications' : `/${portal === 'tutor' ? 'tutor' : 'student'}/notifications`}">${icon('bell', { size: 16 })}<span>Notifications</span></a></li>
          <li><a href="/account/password">${icon('lock', { size: 16 })}<span>Change password</span></a></li>
          <li class="menu__sep"></li>
          <li>
            <form method="post" action="/logout" class="menu__form">
              <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
              <button type="submit" class="menu__button">${icon('logout', { size: 16 })}<span>Sign out</span></button>
            </form>
          </li>
        </ul>
      </div>
    </details>`;
}

function flashRegion(ctx) {
  const messages = ctx.flash?.messages || [];
  if (!messages.length) return raw('<div class="toasts" aria-live="polite"></div>');
  return html`
    <div class="toasts" role="status" aria-live="polite">
      ${messages.map((m) => html`
        <div class="toast toast--${m.type || 'info'}" data-toast>
          <span class="toast__icon">${icon(m.type === 'danger' || m.type === 'error' ? 'warning' : m.type === 'success' ? 'check' : 'info', { size: 16 })}</span>
          <p class="toast__text">${m.message}</p>
          <button type="button" class="toast__close" data-dismiss aria-label="Dismiss">${icon('x', { size: 13 })}</button>
        </div>`)}
    </div>`;
}

export function banners(ctx) {
  const out = [];
  if (ctx.user?.must_change_password) {
    out.push(html`<div class="banner banner--warning" role="status">
      ${icon('lock', { size: 18 })}
      <p>For security, please <a href="/account/password">change your password</a> — you are still using the initial password.</p>
    </div>`);
  }
  if (ctx.user?.status === ACCOUNT_STATUS.PENDING) {
    out.push(html`<div class="banner banner--info" role="status">
      ${icon('info', { size: 18 })}
      <p>Your account is awaiting administrator approval. You can complete your profile and availability in the meantime.</p>
    </div>`);
  }
  return out.length ? html`${out}` : null;
}

/**
 * Render a full HTML document.
 * @param {{ctx: object, title: string, body: any, portal: 'admin'|'tutor'|'tutee'|null, active: string}} options
 */
export function renderDocument({ ctx, title, body, portal = null, active = null, plain = false, indexable = false }) {
  const settings = getSettings();
  const orgName = settings.organisation_name || DEFAULT_BRAND;
  // Avoid duplicate product names when the organisation is
  // still using the default product name.
  const brandTitle = orgName.toLowerCase() === DEFAULT_BRAND.toLowerCase()
    ? DEFAULT_BRAND
    : `${orgName} · ${DEFAULT_BRAND}`;
  // The full shell depends on a signed-in account; fall back to the bare shell
  // rather than rendering navigation we cannot build.
  const bare = plain || !ctx.user;
  if (bare) {
    return html`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta name="color-scheme" content="light dark" />
  <meta name="robots" content="${indexable ? 'index, follow' : 'noindex, nofollow'}" />
  <meta name="description" content="InspireConnect keeps tutors, students, availability, matching and sessions organised in one secure workspace." />
  <title>${title} · ${brandTitle}</title>
  <link rel="stylesheet" href="/assets/app.css" />
  <link rel="icon" href="/assets/favicon.svg" type="image/svg+xml" />
</head>
<body class="app app--plain">
  <a class="skip-link" href="#main">Skip to main content</a>
  <main id="main" class="auth-shell">
    ${banners(ctx)}
    ${body}
  </main>
  ${flashRegion(ctx)}
  <script src="/assets/app.js" defer></script>
</body>
</html>`;
  }

  return html`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta name="color-scheme" content="light dark" />
  <meta name="robots" content="noindex, nofollow" />
  <meta name="csrf-token" content="${ctx.csrfToken}" />
  <title>${title} · ${brandTitle}</title>
  <link rel="stylesheet" href="/assets/app.css" />
  <link rel="icon" href="/assets/favicon.svg" type="image/svg+xml" />
</head>
<body class="app">
  <a class="skip-link" href="#main">Skip to main content</a>
  <div class="shell" data-shell>
    <aside class="sidebar" id="sidebar" data-sidebar>
      <div class="sidebar__brand">
        <a href="${portal === 'tutor' ? '/tutor' : portal === 'tutee' ? '/student' : '/admin'}" class="brand">
          <span class="brand__mark" aria-hidden="true">${icon('match', { size: 20 })}</span>
          <span class="brand__text">
            <strong>InspireConnect</strong>
            <small>${orgName === DEFAULT_BRAND ? 'Tutor & tutee management' : `${orgName} · tutor & tutee management`}</small>
          </span>
        </a>
        <button type="button" class="sidebar__close" data-sidebar-close aria-label="Close navigation">${icon('x', { size: 18 })}</button>
      </div>
      ${sidebarNav(ctx, portal, active)}
      <div class="sidebar__foot">
        <p class="muted small">${brandTitle}</p>
        <p class="muted small">Signed in as ${ROLE_LABELS[ctx.user.role] || ctx.user.role} · v${VERSION}${config.env !== 'production' ? ' · dev' : ''}</p>
      </div>
    </aside>

    <div class="shell__main">
      <header class="topbar">
        <button type="button" class="topbar__icon-btn topbar__icon-btn--menu" data-sidebar-open aria-label="Open navigation">${icon('menu', { size: 20 })}</button>
        ${portal === 'admin'
          ? html`<form class="topbar__search" method="get" action="/admin/search" role="search">
              ${icon('search', { size: 16 })}
              <label class="sr-only" for="global-search">Search tutors, tutees, sessions and subjects</label>
              <input id="global-search" type="search" name="q" value="${ctx.q('q', '')}" placeholder="Search tutors, tutees, sessions…" autocomplete="off" />
            </form>`
          : html`<span class="topbar__spacer"></span>`}
        <div class="topbar__actions">
          ${notificationBell(ctx, portal)}
          ${accountMenu(ctx, portal)}
        </div>
      </header>

      <main id="main" class="content" tabindex="-1">
        ${banners(ctx)}
        ${body}
      </main>
    </div>
  </div>
  <div class="sidebar-scrim" data-sidebar-close hidden></div>
  ${flashRegion(ctx)}
  <script src="/assets/app.js" defer></script>
</body>
</html>`;
}

export function errorDocument({ ctx, status, title, message, detail = null }) {
  // Anonymous errors render the bare shell: the full shell needs an account
  // (navigation, notification bell, account menu) and must never be rendered
  // without one.
  const portal = ctx.user ? (ctx.user.role === 'tutor' ? 'tutor' : ctx.user.role === 'tutee' ? 'tutee' : 'admin') : null;
  return renderDocument({
    ctx,
    title,
    portal,
    plain: !ctx.user,
    active: null,
    body: html`
      <div class="error-page">
        <p class="error-page__code">${status}</p>
        <h1 class="error-page__title">${title}</h1>
        <p class="error-page__text">${message}</p>
        ${detail ? html`<p class="error-page__detail">${detail}</p>` : null}
        <div class="error-page__actions">
          <a class="btn btn--primary" href="${ctx.user ? (ctx.user.role === 'tutor' ? '/tutor' : ctx.user.role === 'tutee' ? '/student' : '/admin') : '/login'}">Back to dashboard</a>
        </div>
      </div>`,
  });
}

export { badge };
