/**
 * Tutor and tutee portal views. Both roles share these components; the content
 * adapts to the role and to the permissions the account actually has.
 */
import {
  ACCOUNT_STATUS, AVAILABILITY_STATE, ROLE_LABELS, ROLES, SESSION_MODE, SESSION_MODE_LABELS,
  SESSION_STATUS, SESSION_STATUS_LABELS, WEEKDAYS,
} from '../config.mjs';
import { getSettings } from '../db.mjs';
import {
  alert, avatar, badge, button, card, dataTable, definitionList, emptyState, field, filterBar,
  html, icon, join, pageHeader, pagination, raw, roleBadge, sessionStatusBadge, statTile,
  subjectChip, subjectChips, tabs,
} from '../html.mjs';
import {
  durationLabel, fmtDate, fmtDateTime, fmtTime, fmtTimeRange, minutesToHHMM, todayISO, relativeTime, weekStartISO, addDaysISO,
} from '../util.mjs';
import {
  availabilityEditor, availabilityGrid, availabilityLegend, calendarDay, calendarMonth,
  calendarToolbar, calendarWeek, errorFor, personCell, sessionsTable, weekNavigator, valueFor,
} from './partials.mjs';

const base = (role) => (role === ROLES.TUTOR ? '/tutor' : '/student');
const sessionHref = (role) => (session) => `${base(role)}/sessions/${session.id}`;

/* -------------------------------------------------------------------------- */
/* Dashboard                                                                  */
/* -------------------------------------------------------------------------- */

export function portalDashboard({ ctx, role, person, subjects, stats, upcoming, todayAgenda, assignments, availabilityDays, notifications }) {
  const isTutor = role === ROLES.TUTOR;
  const name = person.preferred_name || person.full_name || person.email;
  return html`
    ${pageHeader({
      title: `Welcome back, ${name}`,
      subtitle: isTutor
        ? `${subjects.length ? subjects.map((s) => s.name).join(', ') : 'No subjects selected yet'} · ${stats.upcoming} upcoming session${stats.upcoming === 1 ? '' : 's'}`
        : `${subjects.length ? subjects.map((s) => s.name).join(', ') : 'No subjects selected yet'} · ${assignments.length} assigned tutor${assignments.length === 1 ? '' : 's'}`,
      actions: html`
        <a class="btn btn--secondary btn--sm" href="${base(role)}/availability">${icon('grid', { size: 14 })}<span>My availability</span></a>
        <a class="btn btn--primary btn--sm" href="${base(role)}/timetable">${icon('calendar', { size: 14 })}<span>My timetable</span></a>`,
    })}

    ${person.status === ACCOUNT_STATUS.DISABLED
      ? alert('Your account is currently disabled. Contact an administrator if this is unexpected.', 'danger')
      : null}

    <section class="stat-grid" aria-label="Your statistics">
      ${statTile({ label: 'Today', value: stats.today, hint: 'sessions today', tone: 'primary', iconName: 'calendar', href: `${base(role)}/timetable?view=day&date=${todayISO()}` })}
      ${statTile({ label: 'This week', value: stats.thisWeek, hint: `${durationLabel(stats.weekMinutes)} of tutoring`, tone: 'info', iconName: 'activity', href: `${base(role)}/timetable?view=week&date=${todayISO()}` })}
      ${statTile({ label: 'Upcoming', value: stats.upcoming, hint: 'scheduled or confirmed', tone: 'info', iconName: 'clock', href: `${base(role)}/sessions?scope=upcoming` })}
      ${statTile({ label: 'Completed', value: stats.completed, hint: 'all time', tone: 'success', iconName: 'check', href: `${base(role)}/sessions?status=completed` })}
      ${statTile({ label: isTutor ? 'My tutees' : 'My tutors', value: assignments.length, hint: isTutor ? `capacity ${person.max_students}` : 'active assignments', tone: 'primary', iconName: 'users', href: `${base(role)}/${isTutor ? 'students' : 'tutor'}` })}
      ${statTile({ label: 'Availability', value: stats.availabilitySlots, hint: stats.availabilitySlots ? 'recorded slots' : 'add your availability', tone: stats.availabilitySlots ? 'success' : 'warning', iconName: 'grid', href: `${base(role)}/availability` })}
    </section>

    ${!stats.availabilitySlots
      ? alert(html`You have not recorded any availability yet. Adding it lets administrators match you and schedule sessions.
          <a class="btn btn--secondary btn--sm" href="${base(role)}/availability">Add availability</a>`, 'warning', { title: 'Add your availability' })
      : null}
    ${!subjects.length
      ? alert(html`You have not selected any subjects yet.
          <a class="btn btn--secondary btn--sm" href="${base(role)}/profile">${isTutor ? 'Choose subjects you teach' : 'Choose subjects you need'}</a>`, 'warning', { title: 'Select your subjects' })
      : null}

    <div class="grid grid--2">
      ${card({
        title: "Today's schedule",
        subtitle: todayAgenda.length ? `${todayAgenda.length} session${todayAgenda.length === 1 ? '' : 's'}` : 'Nothing scheduled today',
        actions: html`<a class="btn btn--ghost btn--sm" href="${base(role)}/timetable?view=day&date=${todayISO()}">Day view</a>`,
        padded: false,
        body: todayAgenda.length
          ? html`<ul class="timeline timeline--compact">
              ${todayAgenda.map((s) => html`
                <li class="timeline__item timeline__item--${raw(s.status)}">
                  <span class="timeline__time">${fmtTime(s.start_min)}<small>${durationLabel(s.end_min - s.start_min)}</small></span>
                  <a class="timeline__body" href="${sessionHref(role)(s)}">
                    <span class="timeline__subject">${s.subject_name}</span>
                    <span class="timeline__people">${isTutor ? s.tutee_name : s.tutor_name}</span>
                    <span class="timeline__meta">${SESSION_MODE_LABELS[s.mode]}${s.location ? ` · ${s.location}` : ''}</span>
                  </a>
                  <span class="timeline__status">${sessionStatusBadge(s.status)}</span>
                </li>`)}
            </ul>`
          : emptyState({ title: 'No sessions today', message: 'Enjoy the break — your next session is listed below.', iconName: 'calendar' }),
      })}

      ${card({
        title: 'Upcoming sessions',
        actions: html`<a class="btn btn--ghost btn--sm" href="${base(role)}/sessions?scope=upcoming">All upcoming</a>`,
        padded: false,
        body: upcoming.length
          ? html`<ul class="list">
              ${upcoming.map((s) => html`
                <li class="list__item">
                  <div>
                    <a href="${sessionHref(role)(s)}">${s.subject_name}</a>
                    <br /><span class="muted small">${fmtDate(s.date, 'day')} · ${fmtTimeRange(s.start_min, s.end_min)} · ${isTutor ? s.tutee_name : s.tutor_name}</span>
                  </div>
                  ${sessionStatusBadge(s.status)}
                </li>`)}
            </ul>`
          : emptyState({ title: 'No upcoming sessions', message: 'New sessions will appear here as soon as they are scheduled.', iconName: 'clock' }),
      })}
    </div>

    <div class="grid grid--2">
      ${card({
        title: isTutor ? 'My tutees' : 'My tutors',
        actions: html`<a class="btn btn--ghost btn--sm" href="${base(role)}/${isTutor ? 'students' : 'tutor'}">View all</a>`,
        padded: false,
        body: assignments.length
          ? html`<ul class="list">
              ${assignments.slice(0, 6).map((a) => html`
                <li class="list__item">
                  <div class="person-cell">
                    ${avatar({ name: isTutor ? a.tutee_name : a.tutor_name })}
                    <div>
                      <strong>${isTutor ? a.tutee_name : a.tutor_name}</strong>
                      <br /><span class="muted small">${a.subject_name} · ${a.completed_sessions ?? 0} session${(a.completed_sessions ?? 0) === 1 ? '' : 's'} completed</span>
                    </div>
                  </div>
                </li>`)}
            </ul>`
          : emptyState({
              title: isTutor ? 'No tutees assigned yet' : 'No tutor assigned yet',
              message: 'Administrators assign these after reviewing subject and availability matches.',
              iconName: 'users',
            }),
      })}

      ${card({
        title: 'My availability this week',
        actions: html`<a class="btn btn--secondary btn--sm" href="${base(role)}/availability">Manage</a>`,
        body: html`${availabilityGrid({ days: availabilityDays })}${availabilityLegend()}`,
      })}
    </div>

    ${card({
      title: 'Notifications',
      subtitle: notifications.unread ? `${notifications.unread} unread` : 'Nothing unread',
      actions: html`<a class="btn btn--ghost btn--sm" href="${base(role)}/notifications">View all</a>`,
      padded: false,
      body: notifications.rows.length
        ? html`<ul class="notification-list notification-list--compact">
            ${notifications.rows.map((n) => html`
              <li class="notification ${n.read_at ? '' : 'is-unread'}">
                <span class="notification__dot" aria-hidden="true"></span>
                <div class="notification__body">
                  <p class="notification__title">${n.title}</p>
                  ${n.body ? html`<p class="notification__text">${n.body}</p>` : null}
                  <p class="muted small">${relativeTime(n.created_at)}${n.link ? html` · <a href="${n.link}">Open</a>` : null}</p>
                </div>
              </li>`)}
          </ul>`
        : emptyState({ title: 'No notifications', message: 'Session changes and assignments will show up here.', iconName: 'bell' }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Profile                                                                    */
/* -------------------------------------------------------------------------- */

export function profilePage({ ctx, role, person, subjects, allSubjects, upcoming, history, assignments, stats }) {
  const isTutor = role === ROLES.TUTOR;
  const selected = subjects.map((s) => String(s.id));
  const action = `${base(role)}/profile`;
  return html`
    ${pageHeader({
      title: 'My profile',
      subtitle: 'Keep your details up to date so matching and scheduling stay accurate.',
      actions: html`<a class="btn btn--secondary btn--sm" href="/account/password">${icon('lock', { size: 14 })}<span>Change password</span></a>`,
    })}

    <div class="grid grid--2">
      ${card({
        title: 'Editable details',
        subtitle: 'Administrators can see these fields.',
        body: html`
          <form method="post" action="${action}" class="form" enctype="multipart/form-data">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--2">
              ${field({ label: 'Full name', name: 'full_name', required: true, value: valueFor(ctx, 'full_name', person.full_name), error: errorFor(ctx, 'full_name') })}
              ${field({ label: 'Preferred name', name: 'preferred_name', value: valueFor(ctx, 'preferred_name', person.preferred_name), error: errorFor(ctx, 'preferred_name'), hint: 'Used across the dashboard.' })}
              ${field({ label: 'Phone number', name: 'phone', type: 'tel', value: valueFor(ctx, 'phone', person.phone), error: errorFor(ctx, 'phone') })}
              ${isTutor
                ? field({ label: 'Session frequency preference', name: 'session_frequency', value: valueFor(ctx, 'session_frequency', person.session_frequency), placeholder: 'e.g. twice weekly' })
                : field({ label: 'Year / group', name: 'year_level', value: valueFor(ctx, 'year_level', person.year_level), error: errorFor(ctx, 'year_level') })}
              ${isTutor
                ? field({ label: 'Qualifications', name: 'qualifications', type: 'textarea', rows: 2, value: valueFor(ctx, 'qualifications', person.qualifications) })
                : field({ label: 'Guardian name', name: 'guardian_name', value: valueFor(ctx, 'guardian_name', person.guardian_name) })}
              ${isTutor
                ? field({ label: 'Experience', name: 'experience', type: 'textarea', rows: 3, value: valueFor(ctx, 'experience', person.experience) })
                : field({ label: 'Guardian contact', name: 'guardian_contact', value: valueFor(ctx, 'guardian_contact', person.guardian_contact) })}
              ${field({ label: 'Preferred session times', name: 'preferred_session_times', value: valueFor(ctx, 'preferred_session_times', person.preferred_session_times), placeholder: 'e.g. weekday evenings after 5pm' })}
              ${field({ label: 'Profile photo', name: 'photo', type: 'file', attributes: 'accept="image/png,image/jpeg,image/webp"', hint: 'PNG, JPEG or WebP up to 1 MB. Stored with your record.' })}
            </div>
            ${field({ label: 'About me / notes', name: 'notes', type: 'textarea', rows: 3, value: valueFor(ctx, 'notes', person.notes), hint: 'Shared with administrators; tutors may share learning notes with tutees.' })}
            <div class="form-actions">
              ${button({ label: 'Save profile', iconName: 'check' })}
              <span class="muted small">Email address, account status and registration date can only be changed by an administrator.</span>
            </div>
          </form>`,
      })}

      ${card({
        title: 'Account information',
        actions: html`${badge(person.status === ACCOUNT_STATUS.ACTIVE ? 'Active' : person.status === 'pending' ? 'Pending activation' : 'Disabled', person.status === 'active' ? 'success' : person.status === 'pending' ? 'warning' : 'danger', { dot: true })}`,
        body: definitionList([
          ['Email', person.email],
          ['Role', roleBadge(role)],
          ['Status', person.status === ACCOUNT_STATUS.ACTIVE ? 'Active' : person.status],
          ['Registered', fmtDateTime(person.created_at)],
          ['Last login', person.last_login_at ? fmtDateTime(person.last_login_at) : 'This is your first session'],
          ['Availability rows', String(stats.availabilitySlots)],
          ['Sessions completed', String(stats.completed)],
        ]),
      })}
    </div>

    ${card({
      title: isTutor ? 'Subjects I teach' : 'Subjects I need help with',
      subtitle: 'Used by the matching engine with your availability.',
      body: html`
        <form method="post" action="${action}/subjects" class="form">
          <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
          ${field({
            label: isTutor ? 'Select the subjects you can teach' : 'Select the subjects you need help with',
            name: 'subjects', type: 'checkbox-group', options: allSubjects.map((s) => ({ value: s.id, label: s.name, hint: s.description })),
            value: selected,
          })}
          <div class="form-actions">${button({ label: 'Save subjects', variant: 'secondary', iconName: 'check' })}</div>
        </form>`,
    })}

    <div class="grid grid--2">
      ${card({
        title: 'Upcoming sessions',
        padded: false,
        body: sessionsTable(upcoming, {
          basePath: `${base(role)}/sessions`, showTutor: !isTutor, showTutee: isTutor, showDate: true,
        }),
      })}
      ${card({
        title: isTutor ? 'My tutees' : 'My tutors',
        padded: false,
        body: assignments.length
          ? html`<ul class="list">
              ${assignments.map((a) => html`
                <li class="list__item">
                  <div>
                    <strong>${isTutor ? a.tutee_name : a.tutor_name}</strong>
                    <br /><span class="muted small">${a.subject_name} · since ${fmtDate(String(a.started_at).slice(0, 10), 'short')}</span>
                  </div>
                  <span class="muted small">${a.completed_sessions ?? 0} completed</span>
                </li>`)}
            </ul>`
          : emptyState({ title: 'Nothing assigned yet', iconName: 'users' }),
      })}
    </div>

    ${card({
      title: 'Session history',
      padded: false,
      body: sessionsTable(history, { basePath: `${base(role)}/sessions`, showTutor: !isTutor, showTutee: isTutor }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Availability                                                               */
/* -------------------------------------------------------------------------- */

export function portalAvailabilityPage({ ctx, role, canEdit, days, extraDateRows, weeksAhead }) {
  return html`
    ${pageHeader({
      title: 'My availability',
      subtitle: 'Tell us when you can hold sessions. Administrators use this to match tutors with tutees and to avoid conflicts.',
      actions: html`<a class="btn btn--secondary btn--sm" href="${base(role)}/timetable">${icon('calendar', { size: 14 })}<span>My timetable</span></a>`,
    })}

    ${canEdit
      ? availabilityEditor({ ctx, actionBase: `${base(role)}/availability`, weeklyDays: days, extraDateRows })
      : alert('Availability editing is currently disabled for your account. Please contact an administrator.', 'info')}

    ${card({
      title: 'Next four weeks',
      subtitle: 'How your availability currently expands over the coming weeks (booked sessions are not shown here).',
      body: html`
        <details class="fold" open>
          <summary>Show expanded availability</summary>
          <div class="stack">
            ${weeksAhead.map((week) => html`
              <div>
                <h3 class="subhead">Week of ${fmtDate(week.weekStart, 'short')}</h3>
                ${week.days.some((d) => d.free.length)
                  ? html`<ul class="window-list window-list--grid">
                      ${week.days.filter((d) => d.free.length).map((d) => html`<li class="window-list__item">
                        <strong>${WEEKDAYS.find((w) => w.n === d.weekday)?.short} ${fmtDate(d.date, 'short')}</strong>
                        ${d.free.map((iv) => html`<span class="window-list__slot">${fmtTimeRange(iv.start, iv.end)}</span>`)}
                      </li>`)}
                    </ul>`
                  : html`<p class="muted small">No availability recorded for this week.</p>`}
              </div>`)}
          </div>
        </details>`,
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Students / tutors                                                          */
/* -------------------------------------------------------------------------- */

export function studentsPage({ ctx, role, assignments, sessionsByTutee }) {
  const isTutor = role === ROLES.TUTOR;
  return html`
    ${pageHeader({
      title: isTutor ? 'My students' : 'My tutor',
      subtitle: isTutor
        ? `${assignments.length} active assignment${assignments.length === 1 ? '' : 's'}`
        : 'The tutors assigned to you, with the subject they support.',
    })}

    ${assignments.length
      ? html`<div class="grid grid--2">
          ${assignments.map((a) => {
            const personName = isTutor ? a.tutee_name : a.tutor_name;
            const key = isTutor ? a.tutee_id : a.tutor_id;
            const sessions = (sessionsByTutee?.[key] || sessionsByTutee?.[a.tutee_id] || []).slice(0, 5);
            return card({
              title: personName || 'Assigned',
              actions: subjectChip({ name: a.subject_name, colour: a.subject_colour }),
              body: html`
                <div class="person-summary">
                  ${avatar({ name: personName, size: 'lg' })}
                  <div>
                    <p class="person-summary__name">${personName}</p>
                    <p class="muted small">${isTutor ? a.tutee_email : a.tutor_email}${(isTutor ? a.tutee_phone : a.tutor_phone) ? ` · ${isTutor ? a.tutee_phone : a.tutor_phone}` : ''}</p>
                    ${isTutor && a.year_level ? html`<p class="muted small">Year / group: ${a.year_level}</p>` : null}
                  </div>
                </div>
                ${definitionList([
                  ['Subject', a.subject_name],
                  ['Assigned since', fmtDate(String(a.started_at).slice(0, 10), 'short')],
                  ['Sessions completed', String(a.completed_sessions ?? 0)],
                  ['Sessions scheduled', String(a.total_sessions ?? 0)],
                  ['Assignment notes', a.notes],
                ])}
                <div class="row-actions">
                  <a class="btn btn--secondary btn--sm" href="${base(role)}/sessions?${isTutor ? 'tutee' : 'tutor'}=${key}">${icon('clock', { size: 14 })}<span>Session history</span></a>
                  <a class="btn btn--ghost btn--sm" href="${base(role)}/timetable">${icon('calendar', { size: 14 })}<span>Timetable</span></a>
                </div>
                ${sessions.length
                  ? html`<h3 class="subhead">Recent sessions</h3>
                      <ul class="list list--tight">
                        ${sessions.map((s) => html`<li class="list__item">
                          <div>
                            <a href="${base(role)}/sessions/${s.id}">${fmtDate(s.date, 'day')} · ${fmtTimeRange(s.start_min, s.end_min)}</a>
                            <br /><span class="muted small">${s.subject_name}</span>
                          </div>
                          ${sessionStatusBadge(s.status)}
                        </li>`)}
                      </ul>`
                  : null}`,
            });
          })}
        </div>`
      : emptyState({
          title: isTutor ? 'No students assigned yet' : 'No tutor assigned yet',
          message: 'An administrator will assign these after reviewing subject and availability matches.',
          iconName: 'users',
        })}`;
}

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

export function portalSessionsPage({ ctx, role, rows, pageInfo, filters, subjects, tuteesList, tutorsList }) {
  const isTutor = role === ROLES.TUTOR;
  return html`
    ${pageHeader({
      title: isTutor ? 'My sessions' : 'My sessions',
      subtitle: `${pageInfo.total} session${pageInfo.total === 1 ? '' : 's'} · completed sessions are kept in your history.`,
      actions: html`<a class="btn btn--secondary btn--sm" href="${base(role)}/timetable">${icon('calendar', { size: 14 })}<span>Timetable</span></a>`,
    })}

    ${tabs([
      { key: 'all', label: 'All', href: `${base(role)}/sessions` },
      { key: 'upcoming', label: 'Upcoming', href: `${base(role)}/sessions?scope=upcoming` },
      { key: 'completed', label: 'Completed', href: `${base(role)}/sessions?status=completed` },
      { key: 'cancelled', label: 'Cancelled', href: `${base(role)}/sessions?status=cancelled` },
      { key: 'missed', label: 'Missed', href: `${base(role)}/sessions?status=missed` },
    ], filters.scope === 'upcoming' ? 'upcoming' : (filters.status !== 'all' ? filters.status : 'all'))}

    ${filterBar({
      action: `${base(role)}/sessions`,
      children: html`
        ${field({ label: 'From', name: 'from', type: 'date', value: filters.from || '' })}
        ${field({ label: 'To', name: 'to', type: 'date', value: filters.to || '' })}
        ${field({ label: 'Subject', name: 'subject', type: 'select', value: filters.subject, options: [{ value: 'all', label: 'All subjects' }, ...subjects.map((s) => ({ value: s.id, label: s.name }))] })}
        ${field({ label: 'Status', name: 'status', type: 'select', value: filters.status, options: [{ value: 'all', label: 'Any status' }, ...Object.values(SESSION_STATUS).map((s) => ({ value: s, label: SESSION_STATUS_LABELS[s] }))] })}
        ${isTutor && tuteesList?.length
          ? field({ label: 'Tutee', name: 'tutee', type: 'select', value: filters.tutee, options: [{ value: 'all', label: 'All tutees' }, ...tuteesList.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })
          : null}
        ${!isTutor && tutorsList?.length
          ? field({ label: 'Tutor', name: 'tutor', type: 'select', value: filters.tutor, options: [{ value: 'all', label: 'All tutors' }, ...tutorsList.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })
          : null}`,
      resetHref: `${base(role)}/sessions`,
    })}

    ${card({
      padded: false,
      body: sessionsTable(rows, { basePath: `${base(role)}/sessions`, showTutor: !isTutor, showTutee: isTutor }),
      footer: pagination(pageInfo, `${base(role)}/sessions`, filters),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Timetable                                                                  */
/* -------------------------------------------------------------------------- */

export function portalTimetablePage({ ctx, role, view, date, sessions, filters, subjects }) {
  const isTutor = role === ROLES.TUTOR;
  const path = `${base(role)}/timetable`;
  return html`
    ${pageHeader({
      title: 'My timetable',
      subtitle: `${sessions.length} session${sessions.length === 1 ? '' : 's'} in view · times shown in ${getSettings().timezone_label || 'local time'}`,
      actions: html`<a class="btn btn--secondary btn--sm" href="${base(role)}/availability">${icon('grid', { size: 14 })}<span>My availability</span></a>`,
    })}

    ${filterBar({
      action: path,
      extraHidden: `<input type="hidden" name="view" value="${view}" /><input type="hidden" name="date" value="${date}" />`,
      children: html`
        ${field({ label: 'Subject', name: 'subject', type: 'select', value: filters.subject, options: [{ value: 'all', label: 'All subjects' }, ...subjects.map((s) => ({ value: s.id, label: s.name }))] })}
        ${field({ label: 'Status', name: 'status', type: 'select', value: filters.status, options: [{ value: 'all', label: 'Any status' }, ...Object.values(SESSION_STATUS).map((s) => ({ value: s, label: SESSION_STATUS_LABELS[s] }))] })}`,
      resetHref: `${path}?view=${view}&date=${date}`,
    })}

    ${calendarToolbar({ view, date, basePath: path, params: { subject: filters.subject, status: filters.status } })}

    ${card({
      padded: false,
      body: view === 'month'
        ? calendarMonth({ date, sessions, basePath: path, params: { subject: filters.subject, status: filters.status } })
        : view === 'week'
          ? calendarWeek({ weekStart: weekStartISO(date), sessions, basePath: path, params: { subject: filters.subject, status: filters.status }, sessionHref: sessionHref(role) })
          : calendarDay({ date, sessions, sessionHref: sessionHref(role) }),
    })}

    ${card({
      title: 'Sessions in this view',
      padded: false,
      body: sessionsTable(sessions, { basePath: `${base(role)}/sessions`, showTutor: !isTutor, showTutee: isTutor, showDate: view !== 'day' }),
    })}`;
}

export { fmtTime, addDaysISO };
