import { DEFAULT_BRAND } from '../config.mjs';
import { html, icon, raw } from '../html.mjs';

export function landingPage() {
  return html`
    <div class="landing">
      <header class="landing__nav">
        <a class="landing__brand" href="/" aria-label="${DEFAULT_BRAND} home">
          <span class="brand__mark brand__mark--landing" aria-hidden="true">${icon('match', { size: 21 })}</span>
          <span><strong>${DEFAULT_BRAND}</strong><small>tutoring, connected</small></span>
        </a>
        <nav class="landing__links" aria-label="Public navigation">
          <a href="#product">Platform</a>
          <a href="#how-it-works">How it works</a>
          <a href="#security">Security</a>
          <a class="btn btn--secondary btn--sm" href="/login">Sign in ${icon('right', { size: 14 })}</a>
        </nav>
      </header>

      <main>
        <section class="landing__hero">
          <div class="landing__hero-copy">
            <p class="eyebrow"><span class="eyebrow__dot"></span> One calm place for better learning</p>
            <h1>Make every tutoring connection <span class="text-gradient">count.</span></h1>
            <p class="landing__lead">${DEFAULT_BRAND} brings tutors, students, availability, matching and sessions into one beautifully organised workspace.</p>
            <div class="landing__actions">
              <a class="btn btn--primary btn--lg" href="/login">Open your workspace ${icon('right', { size: 17 })}</a>
              <a class="landing__text-link" href="#product">See how it works ${icon('down', { size: 15 })}</a>
            </div>
            <div class="landing__trust"><span class="trust__avatars"><i>AM</i><i>JS</i><i>SK</i></span><span>Designed for coordinators, tutors and students</span></div>
          </div>
          <div class="landing__visual" aria-label="Preview of the InspireConnect dashboard">
            <div class="glow glow--one"></div><div class="glow glow--two"></div>
            <div class="preview-window">
              <div class="preview-window__bar"><span></span><span></span><span></span><b>InspireConnect <em>workspace</em></b><i>${icon('more', { size: 15 })}</i></div>
              <div class="preview-window__body">
                <aside class="preview-side"><strong><span class="preview-logo">↗</span> InspireConnect</strong><small>OVERVIEW</small><a class="is-active">${icon('dashboard', { size: 14 })} Overview</a><a>${icon('users', { size: 14 })} People</a><a>${icon('calendar', { size: 14 })} Timetable</a><a>${icon('match', { size: 14 })} Matches</a><small>MANAGE</small><a>${icon('grid', { size: 14 })} Availability</a><a>${icon('report', { size: 14 })} Reports</a></aside>
                <div class="preview-main"><div class="preview-greeting"><div><small>Tuesday, 17 September</small><h3>Good morning, Alex <span>✦</span></h3></div><span class="preview-user">AJ</span></div>
                  <div class="preview-stats"><div><small>Active tutors</small><strong>24</strong><em class="up">↗ 12%</em></div><div><small>Students supported</small><strong>86</strong><em class="up">↗ 8%</em></div><div><small>Sessions this week</small><strong>142</strong><em>On track</em></div></div>
                  <div class="preview-grid"><div class="preview-card preview-card--wide"><div class="preview-card__head"><strong>Today’s sessions</strong><span>View timetable →</span></div><div class="mini-session"><b class="mini-session__time">09:00</b><span class="mini-session__line line--blue"></span><div><strong>English · Mia Thompson</strong><small>Amara Okafor · Online</small></div><span class="mini-status">Confirmed</span></div><div class="mini-session"><b class="mini-session__time">11:30</b><span class="mini-session__line line--green"></span><div><strong>Maths · Noah Williams</strong><small>Sarah Khan · Room 2</small></div><span class="mini-status mini-status--soft">Scheduled</span></div></div><div class="preview-card"><div class="preview-card__head"><strong>At a glance</strong></div><div class="donut-wrap"><div class="donut"><span>86<small>students</small></span></div><ul><li><i class="dot dot--blue"></i>On track <b>68%</b></li><li><i class="dot dot--green"></i>Needs match <b>21%</b></li><li><i class="dot dot--purple"></i>Review <b>11%</b></li></ul></div></div></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="landing__proof" id="product"><p>Everything your tutoring programme needs to run with confidence</p><div><span>${icon('shield', { size: 16 })} Secure by design</span><span>${icon('match', { size: 16 })} Smarter matching</span><span>${icon('calendar', { size: 16 })} Clearer schedules</span><span>${icon('activity', { size: 16 })} Better outcomes</span></div></section>

        <section class="landing__section landing__section--center"><p class="eyebrow">A better operating rhythm</p><h2>From first invitation to <span class="text-gradient">finished session.</span></h2><p class="section-lead">Replace scattered spreadsheets and messages with a secure system that keeps everyone aligned.</p><div class="feature-grid"><article><span class="feature-icon feature-icon--blue">${icon('match', { size: 21 })}</span><h3>Match with confidence</h3><p>Compare subjects, overlapping availability, capacity and existing bookings in one clear view.</p><a href="/login">Explore matching ${icon('right', { size: 14 })}</a></article><article><span class="feature-icon feature-icon--green">${icon('calendar', { size: 21 })}</span><h3>Make time work</h3><p>Manage weekly availability, date overrides, timetables, rescheduling and conflict checks effortlessly.</p><a href="/login">View the timetable ${icon('right', { size: 14 })}</a></article><article><span class="feature-icon feature-icon--purple">${icon('shield', { size: 21 })}</span><h3>Keep trust central</h3><p>Invitation-only access, strong passwords, role-based permissions and an audit trail protect every record.</p><a href="/login">See security ${icon('right', { size: 14 })}</a></article></div></section>

        <section class="landing__section landing__workflow" id="how-it-works"><div><p class="eyebrow">Simple for everyone</p><h2>Less admin. More <span class="text-gradient">progress.</span></h2><p class="section-lead">Give each person the right view without making the system feel complicated.</p><div class="workflow-list"><div><b>01</b><span><strong>Invite safely</strong><small>Send a secure, single-use link to a tutor or student.</small></span></div><div><b>02</b><span><strong>Find the fit</strong><small>Let availability and subject choices surface the best options.</small></span></div><div><b>03</b><span><strong>Keep momentum</strong><small>Schedule, track, note and improve every session over time.</small></span></div></div></div><div class="workflow-card"><div class="workflow-card__top"><span class="status-live"><i></i> Live matching</span><span>${icon('more', { size: 16 })}</span></div><p>Best matches for <strong>John Smith</strong></p><div class="match-row"><span class="match-avatar match-avatar--a">SO</span><div><strong>Sarah Okafor</strong><small>Maths · 3 overlapping slots</small></div><span class="match-score">96%</span></div><div class="match-row"><span class="match-avatar match-avatar--b">DK</span><div><strong>David Khan</strong><small>Maths · 2 overlapping slots</small></div><span class="match-score match-score--muted">82%</span></div><button class="fake-button">Review all matches ${icon('right', { size: 14 })}</button></div></section>

        <section class="landing__security" id="security"><div class="security-icon">${icon('lock', { size: 23 })}</div><div><p class="eyebrow">Built for trust</p><h2>Your records deserve a secure home.</h2><p>InspireConnect keeps sensitive student and session information behind server-enforced roles, secure sessions, CSRF protection, invitation tokens and a complete activity history.</p></div><a class="btn btn--secondary" href="/login">Sign in securely ${icon('right', { size: 15 })}</a></section>
      </main>
      <footer class="landing__footer"><span><strong>↗ ${DEFAULT_BRAND}</strong> · tutoring, connected</span><span>Private by invitation · Built for better learning</span></footer>
    </div>`;
}
