/**
 * Administrator views.
 */
import {
  ACCOUNT_STATUS, AVAILABILITY_KIND, AVAILABILITY_STATE, BLOCKING_STATUSES, INVITATION_STATUS,
  MATCH_STATUS, NOTE_VISIBILITY, PERMISSIONS, ROLE_DESCRIPTIONS, ROLE_LABELS, ROLES,
  SESSION_MODE, SESSION_MODE_LABELS, SESSION_NOTE_CATEGORIES, SESSION_STATUS, SESSION_STATUS_LABELS,
  SETTINGS_GROUPS, STAFF_ROLES, WEEKDAYS,
} from '../config.mjs';
import { getSettings, settingInt } from '../db.mjs';
import {
  alert, avatar, badge, button, card, confirmButton, dataTable, definitionList, emptyState,
  field, filterBar, html, icon, join, matchBadge, pageHeader, pagination, raw, roleBadge,
  sessionStatusBadge, statTile, subjectChip, subjectChips, tabs,
} from '../html.mjs';
import {
  addDaysISO, durationLabel, fmtDate, fmtDateTime, fmtTime, fmtTimeRange, minutesToHHMM,
  monthLabel, paginationQuery, relativeTime, todayISO, weekDays, weekStartISO,
} from '../util.mjs';
import {
  availabilityEditor, availabilityGrid, availabilityLegend, calendarDay, calendarMonth,
  calendarToolbar, calendarWeek, errorFor, matchTable, matchWindows, personCell,
  quickActions, sessionStatusForm, sessionsTable, timeOptions, valueFor, weekNavigator,
} from './partials.mjs';

/* -------------------------------------------------------------------------- */
/* Small helpers                                                              */
/* -------------------------------------------------------------------------- */

function sortHeader(label, key, { sort, dir, basePath, params = {} }) {
  const nextDir = sort === key && dir !== 'desc' ? 'desc' : 'asc';
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v) qs.set(k, String(v));
  qs.set('sort', key);
  qs.set('dir', nextDir);
  const active = sort === key;
  return html`<a class="th-sort ${active ? 'is-active' : ''}" href="${basePath}?${raw(qs.toString())}">
    ${label}${active ? html`<span aria-hidden="true">${dir === 'desc' ? '▾' : '▴'}</span>` : null}
  </a>`;
}

/**
 * Quantise a session count into a bar-width step (0–100 in 10% increments).
 * The stylesheet defines `.week-bar__fill--<step>`, so the weekly chart needs no
 * inline styles, which the Content-Security-Policy forbids.
 */
const barStep = (total) => Math.min(100, Math.max(0, Math.round((Number(total || 0) * 14) / 10) * 10));

const subjectFilterOptions = (subjects) => [
  { value: 'all', label: 'All subjects' },
  ...subjects.map((s) => ({ value: s.id, label: s.name })),
];

const statusFilterOptions = [
  { value: 'all', label: 'Any status' },
  { value: ACCOUNT_STATUS.ACTIVE, label: 'Active' },
  { value: ACCOUNT_STATUS.PENDING, label: 'Pending activation' },
  { value: ACCOUNT_STATUS.DISABLED, label: 'Disabled' },
];

const dayFilterOptions = [
  { value: 'all', label: 'Any day' },
  ...WEEKDAYS.map((d) => ({ value: d.n, label: d.name })),
];

/* -------------------------------------------------------------------------- */
/* Dashboard                                                                  */
/* -------------------------------------------------------------------------- */

export function adminDashboard({ ctx, counts, pendingMatches, todayAgenda, activity, recentSessions, permissions }) {
  const week = counts.week;
  return html`
    ${pageHeader({
      title: 'Dashboard',
      subtitle: `Live overview for ${fmtDate(todayISO(), 'long')} · week of ${fmtDate(week.weekStart, 'short')}`,
      actions: html`<a class="btn btn--secondary btn--sm" href="/admin/weekly">${icon('activity', { size: 14 })}<span>Weekly tracking</span></a>
        <a class="btn btn--primary btn--sm" href="/admin/sessions/new">${icon('plus', { size: 14 })}<span>Schedule session</span></a>`,
    })}

    ${quickActions(ctx, permissions)}

    <section class="stat-grid" aria-label="Key numbers">
      ${statTile({ label: 'Tutors', value: counts.totalTutors, hint: `${counts.activeTutors} active · ${counts.pendingTutors} pending`, href: '/admin/tutors', tone: 'primary', iconName: 'users' })}
      ${statTile({ label: 'Tutees', value: counts.totalTutees, hint: `${counts.activeTutees} active · ${counts.pendingTutees} pending`, href: '/admin/tutees', tone: 'info', iconName: 'user' })}
      ${statTile({ label: 'Sessions this week', value: counts.sessionsThisWeek, hint: `${counts.sessionsToday} today · ${durationLabel(week.totalMinutes)} total`, href: '/admin/weekly', tone: 'primary', iconName: 'calendar' })}
      ${statTile({ label: 'Upcoming sessions', value: counts.upcomingSessions, hint: `${counts.runningSessions} running now`, href: '/admin/timetable', tone: 'info', iconName: 'clock' })}
      ${statTile({ label: 'Completed this week', value: counts.completedThisWeek, hint: `${counts.cancelledThisWeek} cancelled · ${counts.missedThisWeek} missed`, href: '/admin/sessions?status=completed', tone: 'success', iconName: 'check' })}
      ${statTile({ label: 'Available now', value: `${counts.availableTutors}/${counts.totalTutors}`, hint: `${counts.availableTutees} tutees with availability`, href: '/admin/availability', tone: 'success', iconName: 'grid' })}
      ${statTile({ label: 'Need a tutor', value: counts.unassignedTutees, hint: `${counts.unassignedTutors} tutors without tutees`, href: '/admin/matches', tone: 'warning', iconName: 'match' })}
      ${statTile({ label: 'Pending invitations', value: counts.pendingInvitations, hint: `${counts.expiringInvitations} expiring soon · ${counts.usedInvitations} used`, href: '/admin/invitations?status=pending', tone: counts.expiringInvitations ? 'warning' : 'neutral', iconName: 'mail' })}
    </section>

    ${counts.conflictCount
      ? alert(
        `${counts.conflictCount} overlapping session${counts.conflictCount === 1 ? '' : 's'} detected this week for the same tutor or tutee. Review the timetable and resolve them.`,
        'danger',
        { title: 'Scheduling conflicts need attention' },
      )
      : null}

    <div class="grid grid--2">
      ${card({
        title: "Today's sessions",
        subtitle: `${todayAgenda.length} session${todayAgenda.length === 1 ? '' : 's'} scheduled`,
        actions: html`<a class="btn btn--ghost btn--sm" href="/admin/timetable?view=day&date=${todayISO()}">Open day view</a>`,
        padded: false,
        body: sessionsTable(todayAgenda, { basePath: '/admin/sessions' }),
      })}

      ${card({
        title: 'Tutees waiting for a tutor',
        subtitle: 'Best matching tutors by subject and availability.',
        actions: html`<a class="btn btn--ghost btn--sm" href="/admin/matches">Matching screen</a>`,
        body: pendingMatches.length
          ? html`<ul class="suggestion-list">
              ${pendingMatches.map((item) => html`
                <li class="suggestion">
                  <div class="suggestion__head">
                    <a href="/admin/tutees/${item.tutee.id}">${item.tutee.name}</a>
                    ${subjectChips(item.subjects)}
                  </div>
                  ${item.best.length
                    ? html`<ul class="suggestion__matches">
                        ${item.best.map((b) => html`<li>
                          <a href="/admin/matches?tutee=${item.tutee.id}&subject=${b.matchedSubjects[0]?.id || ''}">${b.tutorName}</a>
                          <span class="muted small">${durationLabel(b.overlapMinutes)} overlap · ${b.windows[0]?.label || ''}</span>
                        </li>`)}
                      </ul>`
                    : html`<p class="muted small">No available tutor found yet — check availability records (${item.totalCandidates} tutor${item.totalCandidates === 1 ? '' : 's'} reviewed).</p>`}
                </li>`)}
            </ul>`
          : emptyState({ title: 'Every tutee has a tutor', message: 'New tutees awaiting matching will appear here.', iconName: 'check' }),
      })}
    </div>

    <div class="grid grid--2">
      ${card({
        title: 'This week at a glance',
        subtitle: `Week of ${fmtDate(week.weekStart, 'short')}`,
        actions: html`<a class="btn btn--ghost btn--sm" href="/admin/weekly">Weekly tracking</a>`,
        body: html`
          <ul class="week-bars">
            ${week.byDay.map((d) => html`<li class="week-bar">
              <span class="week-bar__day">${d.short}</span>
              <span class="week-bar__track"><span class="week-bar__fill week-bar__fill--${barStep(d.total)}"></span></span>
              <span class="week-bar__value">${d.total}${d.completed ? html` <span class="muted small">(${d.completed} done)</span>` : null}</span>
            </li>`)}
          </ul>
        `,
      })}

      ${card({
        title: 'Recent activity',
        subtitle: 'Administrative audit trail',
        actions: html`<a class="btn btn--ghost btn--sm" href="/admin/audit">Full log</a>`,
        padded: false,
        body: activity.length
          ? html`<ul class="activity">
              ${activity.map((a) => html`<li class="activity__item">
                <span class="activity__action">${a.summary || a.action}</span>
                <span class="muted small">${a.actor_label || 'system'} · ${relativeTime(a.created_at)}</span>
              </li>`)}
            </ul>`
          : emptyState({ title: 'No activity recorded yet', iconName: 'activity' }),
      })}
    </div>

    ${card({
      title: 'Latest scheduled sessions',
      padded: false,
      actions: html`<a class="btn btn--ghost btn--sm" href="/admin/sessions">All sessions</a>`,
      body: sessionsTable(recentSessions, { basePath: '/admin/sessions' }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Tutors & tutees                                                            */
/* -------------------------------------------------------------------------- */

export function peopleListPage({
  ctx, kind, rows, pageInfo, filters, subjects,
}) {
  const isTutor = kind === 'tutor';
  const basePath = isTutor ? '/admin/tutors' : '/admin/tutees';
  const params = { ...filters, sort: filters.sort, dir: filters.dir };
  return html`
    ${pageHeader({
      title: isTutor ? 'Tutors' : 'Tutees',
      subtitle: isTutor
        ? 'Every tutor record, their subjects, availability and workload.'
        : 'Every tutee record, the subjects they need and their assigned tutor.',
      actions: html`
        <a class="btn btn--secondary btn--sm" href="/admin/invitations/new?role=${kind}">${icon('mail', { size: 14 })}<span>Invite ${isTutor ? 'tutor' : 'tutee'}</span></a>
        <a class="btn btn--primary btn--sm" href="${basePath}/new">${icon('plus', { size: 14 })}<span>Add ${isTutor ? 'tutor' : 'tutee'}</span></a>`,
    })}

    ${filterBar({
      action: basePath,
      children: html`
        ${field({ label: 'Search', name: 'search', value: filters.search || '', placeholder: 'Name, email or phone', id: 'search' })}
        ${field({ label: 'Subject', name: 'subject', type: 'select', options: subjectFilterOptions(subjects), value: filters.subject })}
        ${field({ label: 'Status', name: 'status', type: 'select', options: statusFilterOptions, value: filters.status })}
        ${field({ label: 'Available on', name: 'day', type: 'select', options: dayFilterOptions, value: filters.day })}
        ${field({
          label: 'Assignment', name: 'assigned', type: 'select', value: filters.assigned, options: [
            { value: 'all', label: 'All' },
            { value: 'assigned', label: isTutor ? 'Has tutees' : 'Has a tutor' },
            { value: 'unassigned', label: isTutor ? 'No tutees' : 'No tutor yet' },
          ],
        })}
        ${field({
          label: 'Availability recorded', name: 'hasAvailability', type: 'select', value: filters.hasAvailability, options: [
            { value: 'all', label: 'Any' }, { value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' },
          ],
        })}
        <input type="hidden" name="sort" value="${filters.sort || ''}" />
        <input type="hidden" name="dir" value="${filters.dir || ''}" />`,
      resetHref: basePath,
    })}

    ${card({
      padded: false,
      body: dataTable({
        caption: `${isTutor ? 'Tutors' : 'Tutees'} list`,
        columns: [
          { label: sortHeader('Name', 'name', { ...filters, basePath, params }) },
          { label: sortHeader('Subjects', 'name', { ...filters, basePath, params: { ...params, sort: undefined } }) },
          { label: isTutor ? 'Tutees' : 'Tutor(s)' },
          { label: 'Availability' },
          { label: sortHeader('Status', 'status', { ...filters, basePath, params }) },
          { label: sortHeader('Last login', 'last_login', { ...filters, basePath, params }) },
          { label: 'Actions', align: 'right' },
        ],
        rows: rows.map((person) => ({
          cells: [
            personCell({
              name: person.full_name || person.email,
              email: person.email,
              photo: person.photo,
              href: `${basePath}/${person.id}`,
              meta: isTutor ? person.email : `${person.email}${person.year_level ? ` · ${person.year_level}` : ''}`,
            }),
            subjectChips((person.subject_names || '').split(', ').filter(Boolean).map((name) => ({ name })), {
              empty: isTutor ? 'No subjects selected' : 'No subjects selected',
            }),
            isTutor
              ? html`<span>${person.student_count} tutee${person.student_count === 1 ? '' : 's'}<br /><span class="muted small">cap. ${person.max_students}</span></span>`
              : html`<span class="muted small">${person.tutor_names || 'Unassigned'}</span>`,
            html`<span class="muted small">${person.availability_count ? `${person.availability_count} slot${person.availability_count === 1 ? '' : 's'}` : 'None recorded'}</span>`,
            accountStatusCell(person),
            html`<span class="muted small">${person.last_login_at ? relativeTime(person.last_login_at) : 'Never'}</span>`,
            html`<span class="row-actions">
              <a class="btn btn--ghost btn--sm" href="${basePath}/${person.id}">${icon('eye', { size: 14 })}<span>View</span></a>
              <a class="btn btn--ghost btn--sm" href="/admin/availability/${person.id}">${icon('grid', { size: 14 })}<span>Availability</span></a>
              ${!isTutor && person.status === 'active'
                ? html`<a class="btn btn--ghost btn--sm" href="/admin/matches?tutee=${person.id}">${icon('match', { size: 14 })}<span>Match</span></a>`
                : null}
            </span>`,
          ],
        })),
        empty: emptyState({
          title: isTutor ? 'No tutors found' : 'No tutees found',
          message: 'Adjust the filters or create a secure invitation to onboard someone new.',
          action: html`<a class="btn btn--primary btn--sm" href="/admin/invitations/new?role=${kind}">Create invitation</a>`,
        }),
      }),
      footer: pagination(pageInfo, basePath, params),
    })}`;
}

const accountStatusCell = (person) => accountBadgeTone(person.status);

function accountBadgeTone(status) {
  const tones = { active: 'success', pending: 'warning', disabled: 'danger', locked: 'danger' };
  const labels = { active: 'Active', pending: 'Pending activation', disabled: 'Disabled', locked: 'Locked' };
  return html`<span class="badge badge--${raw(tones[status] || 'neutral')}"><span class="badge__dot" aria-hidden="true"></span>${labels[status] || status}</span>`;
}

export function personFormPage({ ctx, kind, mode, person = null, subjects = [], invitationLink = null, conflictNote = null }) {
  const isTutor = kind === 'tutor';
  const basePath = isTutor ? '/admin/tutors' : '/admin/tutees';
  const editing = mode === 'edit';
  const val = (name, fallback = '') => valueFor(ctx, name, person?.[name] ?? fallback);
  const err = (name) => errorFor(ctx, name);
  const subjectsFieldName = 'subjects';
  const selected = (() => {
    const fromFlash = ctx.flash?.values?.[subjectsFieldName];
    if (fromFlash !== undefined) return (Array.isArray(fromFlash) ? fromFlash : [fromFlash]).map(String);
    return (person?.subjects || []).map((s) => String(s.id ?? s));
  })();

  return html`
    ${pageHeader({
      title: `${editing ? 'Edit' : 'Add'} ${isTutor ? 'tutor' : 'tutee'}`,
      subtitle: editing
        ? `Update the record for ${person?.full_name || person?.email}.`
        : `Create the record now — a secure single-use invitation link is generated so the ${isTutor ? 'tutor' : 'tutee'} sets their own password.`,
      breadcrumbs: html`<a href="${basePath}">${isTutor ? 'Tutors' : 'Tutees'}</a> <span aria-hidden="true">/</span> <span>${editing ? 'Edit' : 'New'}</span>`,
    })}

    ${invitationLink
      ? alert(html`Invitation created. Copy this single-use link and send it securely — it will not be shown again in full.
          <div class="copy-row">
            <label class="sr-only" for="invite-link">Invitation link</label>
            <input class="input" id="invite-link" type="text" value="${invitationLink}" readonly />
            <button type="button" class="btn btn--secondary btn--sm" data-copy="#invite-link">${icon('link', { size: 14 })}<span>Copy</span></button>
          </div>`, 'success', { title: 'Secure invitation ready' })
      : null}
    ${conflictNote ? alert(conflictNote, 'warning') : null}

    <div class="grid grid--2">
      ${card({
        title: isTutor ? 'Tutor details' : 'Tutee details',
        body: html`
          <form method="post" action="${editing ? `${basePath}/${person.id}` : basePath}" class="form" enctype="multipart/form-data">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            ${!editing && isTutor
              ? field({ label: 'Email address', name: 'email', type: 'email', required: true, value: val('email'), error: err('email'), hint: 'The invitation is sent to this address.' })
              : null}
            ${!editing && !isTutor
              ? field({ label: 'Email address', name: 'email', type: 'email', required: true, value: val('email'), error: err('email'), hint: 'The invitation is sent to this address.' })
              : null}
            <div class="form-grid form-grid--2">
              ${field({ label: 'Full name', name: 'full_name', required: true, value: val('full_name'), error: err('full_name') })}
              ${field({ label: 'Preferred name', name: 'preferred_name', value: val('preferred_name'), error: err('preferred_name') })}
              ${field({ label: 'Phone number', name: 'phone', type: 'tel', value: val('phone'), error: err('phone') })}
              ${isTutor
                ? field({ label: 'Capacity (max tutees)', name: 'max_students', type: 'number', min: 1, max: 100, value: val('max_students', 12), error: err('max_students') })
                : field({ label: 'Year / group', name: 'year_level', value: val('year_level'), error: err('year_level') })}
              ${isTutor
                ? field({ label: 'Session frequency preference', name: 'session_frequency', value: val('session_frequency'), placeholder: 'e.g. twice weekly', error: err('session_frequency') })
                : field({ label: 'Sessions per week', name: 'sessions_per_week', type: 'number', min: 1, max: 14, value: val('sessions_per_week', 1), error: err('sessions_per_week') })}
              ${isTutor
                ? field({ label: 'Preferred session times', name: 'preferred_session_times', value: val('preferred_session_times'), placeholder: 'e.g. weekday evenings', error: err('preferred_session_times') })
                : field({ label: 'Guardian name', name: 'guardian_name', value: val('guardian_name'), error: err('guardian_name') })}
              ${!isTutor ? field({ label: 'Guardian contact', name: 'guardian_contact', value: val('guardian_contact'), error: err('guardian_contact') }) : null}
            </div>
            ${isTutor
              ? field({ label: 'Qualifications', name: 'qualifications', type: 'textarea', rows: 2, value: val('qualifications'), error: err('qualifications') })
              : null}
            ${isTutor
              ? field({ label: 'Experience', name: 'experience', type: 'textarea', rows: 3, value: val('experience'), error: err('experience') })
              : null}
            ${field({ label: 'Internal notes', name: 'notes', type: 'textarea', rows: 3, value: val('notes'), hint: 'Visible to administrators only.', error: err('notes') })}
            ${field({
              label: isTutor ? 'Select every subject this tutor can teach' : 'Select every subject this tutee needs',
              name: 'subjects', type: 'checkbox-group', error: err('subjects'),
              options: subjects.map((s) => ({ value: s.id, label: s.name, hint: s.description })),
              value: selected,
              help: 'Used by the matching engine together with availability.',
            })}
            <div class="form-actions">
              ${button({ label: editing ? 'Save changes' : `Create ${isTutor ? 'tutor' : 'tutee'} & invitation`, iconName: 'check' })}
              <a class="btn btn--ghost" href="${basePath}">Cancel</a>
            </div>
          </form>`,
      })}

      ${card({
        title: isTutor ? 'Subjects taught' : 'Subjects needed',
        subtitle: 'Matching compares these selections with availability.',
        body: html`
          <div class="chip-row">${subjectChips(selected.map((id) => subjects.find((s) => String(s.id) === String(id))).filter(Boolean), { empty: 'Select subjects in the form to the left.' })}</div>
          <p class="muted small">Subjects are saved with the record. Use the edit form to change them at any time.</p>
          ${subjects.length ? html`<ul class="checklist checklist--tight">
            ${subjects.map((s) => html`<li>${icon('book', { size: 14 })} ${s.name}${s.description ? html` <span class="muted small">— ${s.description}</span>` : null}</li>`)}
          </ul>` : null}`,
      })}
    </div>

    ${editing
      ? html`<div class="grid grid--2">
          ${card({
            title: 'Account',
            subtitle: 'Account status and password controls.',
            body: html`
              <div class="stack">
                <div class="row-between">
                  <span>Status</span>${accountBadgeTone(person.status)}
                </div>
                ${definitionList([
                  ['Registered', fmtDateTime(person.created_at)],
                  ['Last login', person.last_login_at ? `${fmtDateTime(person.last_login_at)} (${relativeTime(person.last_login_at)})` : 'Never'],
                ])}
                <div class="row-actions">
                  ${person.status !== ACCOUNT_STATUS.ACTIVE
                    ? confirmButton({ action: `${basePath}/${person.id}/status`, label: 'Enable account', variant: 'secondary', confirm: 'Enable this account?', hidden: { _csrf: ctx.csrfToken, status: ACCOUNT_STATUS.ACTIVE } })
                    : confirmButton({ action: `${basePath}/${person.id}/status`, label: 'Disable account', confirm: 'Disable this account? The person will not be able to sign in.', hidden: { _csrf: ctx.csrfToken, status: ACCOUNT_STATUS.DISABLED } })}
                  ${confirmButton({ action: `${basePath}/${person.id}/reset-password`, label: 'Create password reset link', variant: 'ghost', confirm: 'Generate a single-use password reset link?', hidden: { _csrf: ctx.csrfToken } })}
                </div>
              </div>`,
          })}
          ${card({
            title: 'Availability',
            subtitle: person.availability_count ? `${person.availability_count} availability rows recorded.` : 'No availability recorded yet.',
            actions: html`<a class="btn btn--secondary btn--sm" href="/admin/availability/${person.id}">Manage availability</a>`,
            body: html`<p class="muted small">Administrators can add or adjust availability on the person's behalf. Matching and conflict detection read directly from these records.</p>`,
          })}
        </div>`
      : card({
          title: 'What happens next',
          body: html`<ol class="steps">
            <li>Create the record — the account starts as <strong>pending activation</strong>.</li>
            <li>Copy the secure invitation link and send it to the ${isTutor ? 'tutor' : 'tutee'}.</li>
            <li>They set their own password and complete their profile — no shared passwords are ever issued.</li>
            <li>They add availability, then you match them and schedule sessions.</li>
          </ol>`,
        })}`;
}

export function personDetailPage({
  ctx, kind, person, subjects, assignments, upcoming, history, availabilityDays, stats, pageInfo,
  sessionsParams, resetLink, invitationLink = null,
}) {
  const isTutor = kind === 'tutor';
  const basePath = isTutor ? '/admin/tutors' : '/admin/tutees';
  const name = person.full_name || person.email;
  return html`
    ${pageHeader({
      title: name,
      subtitle: `${ROLE_LABELS[person.role] || person.role} · ${person.email}`,
      breadcrumbs: html`<a href="${basePath}">${isTutor ? 'Tutors' : 'Tutees'}</a> <span aria-hidden="true">/</span> <span>${name}</span>`,
      actions: html`
        <a class="btn btn--secondary btn--sm" href="${basePath}/${person.id}/edit">${icon('edit', { size: 14 })}<span>Edit</span></a>
        ${isTutor
          ? html`<a class="btn btn--secondary btn--sm" href="/admin/matches?tutor=${person.id}">${icon('match', { size: 14 })}<span>Find tutees</span></a>`
          : html`<a class="btn btn--secondary btn--sm" href="/admin/matches?tutee=${person.id}">${icon('match', { size: 14 })}<span>Find tutors</span></a>`}
        <a class="btn btn--primary btn--sm" href="/admin/sessions/new?${isTutor ? 'tutor' : 'tutee'}=${person.id}">${icon('plus', { size: 14 })}<span>Schedule session</span></a>`,
    })}

    ${invitationLink
      ? alert(html`Registration invitation created. Copy this single-use link and send it securely — it is shown in full only once.
          <div class="copy-row">
            <input class="input" type="text" value="${invitationLink}" readonly id="invite-link" />
            <button type="button" class="btn btn--secondary btn--sm" data-copy="#invite-link">${icon('link', { size: 14 })}<span>Copy</span></button>
          </div>
          <p class="muted small">They will set their own password. The link expires automatically and stops working after use.</p>`, 'success', { title: 'Secure invitation ready' })
      : null}
    ${resetLink
      ? alert(html`Password reset link generated. Send it securely — it is single-use and expires in 24 hours.
          <div class="copy-row">
            <input class="input" type="text" value="${resetLink}" readonly id="reset-link" />
            <button type="button" class="btn btn--secondary btn--sm" data-copy="#reset-link">${icon('link', { size: 14 })}<span>Copy</span></button>
          </div>`, 'success')
      : null}

    <div class="grid grid--2">
      ${card({
        title: 'Profile',
        actions: accountBadgeTone(person.status),
        body: definitionList([
          ['Full name', person.full_name],
          ['Preferred name', person.preferred_name],
          ['Email', person.email],
          ['Phone', person.phone],
          ...(isTutor
            ? [['Qualifications', person.qualifications], ['Experience', person.experience], ['Capacity', `${person.max_students} tutees`], ['Session preference', person.session_frequency]]
            : [['Year / group', person.year_level], ['Guardian', person.guardian_name], ['Guardian contact', person.guardian_contact], ['Sessions per week', person.sessions_per_week]]),
          ['Preferred session times', person.preferred_session_times],
          ['Internal notes', person.notes],
          ['Registered', fmtDateTime(person.created_at)],
          ['Last login', person.last_login_at ? fmtDateTime(person.last_login_at) : 'Never'],
        ]),
      })}

      ${card({
        title: isTutor ? 'Subjects taught' : 'Subjects needed',
        subtitle: 'Matching uses these selections.',
        actions: html`<a class="btn btn--ghost btn--sm" href="${basePath}/${person.id}/edit">Edit subjects</a>`,
        body: html`
          <div class="chip-row">${subjectChips(isTutor ? subjects.teaches : subjects.needs, { empty: 'Nothing selected yet' })}</div>
          ${stats.duplicateSubjects?.length ? alert('Some subjects appear more than once.', 'warning') : null}`,
      })}
    </div>

    <section class="stat-grid stat-grid--compact" aria-label="Tutor statistics">
      ${statTile({ label: 'Sessions planned', value: stats.upcomingCount, hint: 'scheduled, confirmed or running' })}
      ${statTile({ label: 'Sessions completed', value: stats.completedCount, hint: 'all time' })}
      ${statTile({ label: 'Cancelled / missed', value: `${stats.cancelledCount} / ${stats.missedCount}`, hint: 'retained in history' })}
      ${statTile({ label: isTutor ? 'Active tutees' : 'Active tutors', value: assignments.length, hint: isTutor ? `capacity ${person.max_students}` : 'assignments' })}
      ${statTile({ label: 'Hours delivered', value: (stats.totalMinutes / 60).toFixed(1), hint: 'completed sessions' })}
    </section>

    <div class="grid grid--2">
      ${card({
        title: 'Weekly availability',
        subtitle: 'Current week — recurring and date-specific entries.',
        actions: html`<a class="btn btn--secondary btn--sm" href="/admin/availability/${person.id}">Edit availability</a>`,
        body: html`
          ${availabilityGrid({ days: availabilityDays })}
          ${availabilityLegend()}`,
      })}

      ${card({
        title: isTutor ? 'Assigned tutees' : 'Assigned tutors',
        subtitle: `${assignments.length} active assignment${assignments.length === 1 ? '' : 's'}.`,
        body: assignments.length
          ? html`<ul class="list">
              ${assignments.map((a) => html`
                <li class="list__item">
                  <div>
                    <a href="${isTutor ? `/admin/tutees/${a.tutee_id}` : `/admin/tutors/${a.tutor_id}`}">
                      ${isTutor ? a.tutee_name : a.tutor_name}
                    </a>
                    <br /><span class="muted small">${a.subject_name} · since ${fmtDate(String(a.started_at).slice(0, 10), 'short')} · ${a.completed_sessions ?? 0} completed</span>
                  </div>
                  ${confirmButton({
                    action: `/admin/assignments/${a.id}/end`,
                    label: 'End',
                    confirm: 'End this assignment? Sessions remain in the history.',
                    hidden: { _csrf: ctx.csrfToken },
                  })}
                </li>`)}
            </ul>`
          : emptyState({
              title: isTutor ? 'No tutees assigned' : 'No tutor assigned',
              message: isTutor ? 'Use the matching screen to assign a tutee.' : 'Use the matching screen to find a tutor for this tutee.',
              action: html`<a class="btn btn--primary btn--sm" href="/admin/matches?${isTutor ? 'tutor' : 'tutee'}=${person.id}">Find matches</a>`,
            }),
      })}
    </div>

    ${card({
      title: 'Upcoming sessions',
      padded: false,
      actions: html`<a class="btn btn--ghost btn--sm" href="/admin/sessions?${isTutor ? 'tutor' : 'tutee'}=${person.id}">All sessions</a>`,
      body: sessionsTable(upcoming, { basePath: '/admin/sessions' }),
    })}

    ${card({
      title: 'Session history',
      subtitle: 'Completed, cancelled and missed sessions are never deleted.',
      padded: false,
      body: sessionsTable(history, { basePath: '/admin/sessions' }),
      footer: pagination(pageInfo, `/admin/${isTutor ? 'tutors' : 'tutees'}/${person.id}`, sessionsParams),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Subjects                                                                   */
/* -------------------------------------------------------------------------- */

export function subjectsPage({ ctx, subjects }) {
  return html`
    ${pageHeader({
      title: 'Subjects',
      subtitle: 'Add, rename, enable or disable subjects. New subjects are immediately available for matching.',
    })}

    <div class="grid grid--2">
      ${card({
        title: 'Add a subject',
        body: html`
          <form method="post" action="/admin/subjects" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--2">
              ${field({ label: 'Subject name', name: 'name', required: true, value: valueFor(ctx, 'name'), error: errorFor(ctx, 'name'), placeholder: 'e.g. Geography' })}
              ${field({ label: 'Colour', name: 'colour', type: 'color', value: valueFor(ctx, 'colour', '#2563eb'), error: errorFor(ctx, 'colour') })}
            </div>
            ${field({ label: 'Description (optional)', name: 'description', value: valueFor(ctx, 'description'), error: errorFor(ctx, 'description') })}
            <div class="form-actions">${button({ label: 'Add subject', iconName: 'plus' })}</div>
          </form>`,
      })}
      ${card({
        title: 'How subjects are used',
        body: html`<ul class="checklist">
          <li>${icon('check', { size: 14 })} Tutors select the subjects they teach; tutees select the subjects they need.</li>
          <li>${icon('check', { size: 14 })} Matching only proposes a tutor who teaches the requested subject.</li>
          <li>${icon('check', { size: 14 })} Disabling hides a subject from selection but keeps historical records.</li>
          <li>${icon('check', { size: 14 })} Subjects in use cannot be deleted — disable them instead.</li>
        </ul>`,
      })}
    </div>

    ${card({
      title: `All subjects (${subjects.length})`,
      padded: false,
      body: dataTable({
        caption: 'Subject list',
        columns: [{ label: 'Subject' }, { label: 'Description' }, { label: 'Tutors' }, { label: 'Tutees' }, { label: 'Sessions' }, { label: 'Active' }, { label: 'Actions', align: 'right' }],
        rows: subjects.map((s) => ({
          cells: [
            subjectChip(s),
            html`<span class="muted small">${s.description || '—'}</span>`,
            s.tutor_count,
            s.tutee_count,
            s.session_count,
            badge(s.active ? 'Enabled' : 'Disabled', s.active ? 'success' : 'neutral', { dot: true }),
            html`<span class="row-actions">
              <details class="menu menu--inline">
                <summary class="btn btn--ghost btn--sm">${icon('edit', { size: 14 })}<span>Edit</span></summary>
                <div class="menu__panel menu__panel--right">
                  <form method="post" action="/admin/subjects/${s.id}" class="form form--tight">
                    <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                    ${field({ label: 'Name', name: 'name', value: s.name, required: true })}
                    ${field({ label: 'Colour', name: 'colour', type: 'color', value: s.colour })}
                    ${field({ label: 'Description', name: 'description', value: s.description || '' })}
                    ${field({ label: 'Sort order', name: 'sort_order', type: 'number', value: s.sort_order, min: 0 })}
                    ${field({ label: 'Enabled', name: 'active', type: 'checkbox', value: s.active })}
                    ${button({ label: 'Save subject', size: 'sm' })}
                  </form>
                  ${confirmButton({
                    action: `/admin/subjects/${s.id}/delete`,
                    label: 'Delete subject',
                    variant: 'danger',
                    confirm: `Delete ${s.name}? This only works when the subject is unused.`,
                    hidden: { _csrf: ctx.csrfToken },
                  })}
                </div>
              </details>
            </span>`,
          ],
        })),
      }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Availability                                                               */
/* -------------------------------------------------------------------------- */

export function availabilityOverviewPage({ ctx, rows, filters, weekdayStats }) {
  const grouped = {
    tutor: rows.filter((r) => r.kind === 'tutor'),
    tutee: rows.filter((r) => r.kind === 'tutee'),
  };
  return html`
    ${pageHeader({
      title: 'Availability',
      subtitle: 'Every tutor and tutee availability record. Open a person to add or adjust their slots.',
      actions: html`<a class="btn btn--secondary btn--sm" href="/admin/reports?report=availability_overview">${icon('report', { size: 14 })}<span>Availability report</span></a>`,
    })}

    ${filterBar({
      action: '/admin/availability',
      children: html`
        ${field({ label: 'Search', name: 'search', value: filters.search || '', placeholder: 'Name or email' })}
        ${field({ label: 'Type', name: 'role', type: 'select', value: filters.role, options: [{ value: 'all', label: 'Tutors & tutees' }, { value: 'tutor', label: 'Tutors only' }, { value: 'tutee', label: 'Tutees only' }] })}
        ${field({ label: 'Day', name: 'day', type: 'select', value: filters.day, options: dayFilterOptions })}
        ${field({ label: 'Availability', name: 'has', type: 'select', value: filters.has, options: [{ value: 'all', label: 'Any' }, { value: 'yes', label: 'Has availability' }, { value: 'no', label: 'Missing availability' }] })}`,
      resetHref: '/admin/availability',
    })}

    <section class="stat-grid stat-grid--compact">
      ${WEEKDAYS.map((d) => statTile({
        label: d.name,
        value: `${weekdayStats[d.n]?.tutors || 0} / ${weekdayStats[d.n]?.tutees || 0}`,
        hint: 'tutors / tutees available',
      }))}
    </section>

    ${card({
      title: 'People',
      subtitle: `${rows.length} record${rows.length === 1 ? '' : 's'}`,
      padded: false,
      body: dataTable({
        caption: 'Availability by person',
        columns: [{ label: 'Person' }, { label: 'Type' }, { label: 'Availability rows' }, { label: 'Status' }, { label: 'Actions', align: 'right' }],
        rows: rows.map((r) => ({
          cells: [
            personCell({ name: r.full_name || r.email, email: r.email, href: `/admin/availability/${r.id}` }),
            roleBadge(r.kind === 'tutor' ? ROLES.TUTOR : ROLES.TUTEE),
            html`<span class="${r.slots ? '' : 'muted'}">${r.slots ? `${r.slots} slot${r.slots === 1 ? '' : 's'}` : 'None recorded'}</span>`,
            accountBadgeTone(r.status),
            html`<a class="btn btn--secondary btn--sm" href="/admin/availability/${r.id}">${icon('grid', { size: 14 })}<span>Manage</span></a>`,
          ],
        })),
        empty: emptyState({ title: 'No records match', message: 'Try clearing the filters.', iconName: 'grid' }),
      }),
    })}

    <div class="grid grid--2">
      ${card({ title: `Tutors (${grouped.tutor.length})`, subtitle: 'Availability recorded', body: html`<div class="chip-row">${grouped.tutor.filter((r) => r.slots).length ? join(grouped.tutor.filter((r) => r.slots).map((r) => html`<a class="chip" href="/admin/availability/${r.id}">${r.full_name || r.email}</a>`), ' ') : html`<span class="muted">None</span>`}</div>` })}
      ${card({ title: `Tutees (${grouped.tutee.length})`, subtitle: 'Availability recorded', body: html`<div class="chip-row">${grouped.tutee.filter((r) => r.slots).length ? join(grouped.tutee.filter((r) => r.slots).map((r) => html`<a class="chip" href="/admin/availability/${r.id}">${r.full_name || r.email}</a>`), ' ') : html`<span class="muted">None</span>`}</div>` })}
    </div>`;
}

export function availabilityDetailPage({ ctx, person, days, extraDateRows, canManage = true }) {
  return html`
    ${pageHeader({
      title: `Availability — ${person.full_name || person.email}`,
      subtitle: `${ROLE_LABELS[person.role]} · ${person.email}`,
      breadcrumbs: html`<a href="/admin/availability">Availability</a> <span aria-hidden="true">/</span> <span>${person.full_name || person.email}</span>`,
      actions: html`<a class="btn btn--secondary btn--sm" href="${person.role === ROLES.TUTOR ? `/admin/tutors/${person.id}` : `/admin/tutees/${person.id}`}">Open record</a>`,
    })}

    ${alert('Administrator changes to availability are recorded in the audit log. The person sees these slots in their own dashboard.', 'info')}

    ${availabilityEditor({
      ctx,
      actionBase: canManage ? `/admin/availability/${person.id}` : `/admin/availability/${person.id}`,
      weeklyDays: days,
      extraDateRows,
      timeOptionsRange: { step: Number(getSettings().availability_slot_minutes || 30), startMin: 8 * 60, endMin: 21 * 60 },
    })}

    ${card({ title: 'Visual week view', body: html`${availabilityGrid({ days })}${availabilityLegend()}` })}`;
}

/* -------------------------------------------------------------------------- */
/* Matching                                                                   */
/* -------------------------------------------------------------------------- */

export function matchesPage({ ctx, tutees, tutors, waiting = [], selectedTutee, selectedTutor, result, mode, subjectId, days }) {
  const pickerParams = new URLSearchParams();
  if (selectedTutee) pickerParams.set('tutee', String(selectedTutee.id));
  if (selectedTutor) pickerParams.set('tutor', String(selectedTutor.id));
  if (subjectId) pickerParams.set('subject', String(subjectId));
  pickerParams.set('days', String(days));
  return html`
    ${pageHeader({
      title: 'Matching',
      subtitle: 'Compare tutor subjects and availability against what each tutee needs — including existing bookings.',
    })}

    ${card({
      title: 'Choose who to match',
      body: html`
        <form method="get" action="/admin/matches" class="filterbar">
          ${field({ label: 'Tutee', name: 'tutee', type: 'select', value: selectedTutee?.id, options: [{ value: '', label: '— select a tutee —' }, ...tutees.map((t) => ({ value: t.id, label: `${t.full_name || t.email} (${(t.subject_names || 'no subjects').slice(0, 40)})` }))] })}
          ${field({ label: 'Or tutor', name: 'tutor', type: 'select', value: selectedTutor?.id, options: [{ value: '', label: '— select a tutor (reverse match) —' }, ...tutors.map((t) => ({ value: t.id, label: `${t.full_name || t.email} (${(t.subject_names || 'no subjects').slice(0, 40)})` }))] })}
          ${field({ label: 'Search window', name: 'days', type: 'select', value: String(days), options: [7, 14, 21, 28].map((d) => ({ value: d, label: `Next ${d} days` })) })}
          <div class="filterbar__actions"><button class="btn btn--primary btn--sm" type="submit">${icon('match', { size: 14 })}<span>Find matches</span></button></div>
        </form>`,
    })}

    ${result
      ? html`
        ${card({
          title: mode === 'tutor' ? `Tutors for ${result.tutee?.name || ''}` : `Tutees for ${result.tutor?.name || ''}`,
          subtitle: `Availability compared ${fmtDate(result.fromDate, 'short')} → ${fmtDate(result.toDate, 'short')} · minimum useful overlap ${durationLabel(result.minOverlapMinutes || 60)}`,
          actions: html`<a class="btn btn--ghost btn--sm" href="/admin/matches?${raw(pickerParams.toString())}">Refresh</a>`,
          padded: false,
          body: matchTable(result.rows, {
            mode,
            ctx,
            tuteeId: result.tutee?.id || null,
            tutorId: result.tutor?.id || null,
            actionBase: '/admin/matches',
          }),
        })}

        ${mode === 'tutor' && result.tutee
          ? card({
              title: 'Tutee requirement summary',
              body: html`
                <div class="grid grid--2">
                  <div>
                    <h3 class="subhead">Subjects needed</h3>
                    <div class="chip-row">${subjectChips(result.tutee.subjects, { empty: 'No subjects recorded' })}</div>
                  </div>
                  <div>
                    <h3 class="subhead">Availability (${days} days)</h3>
                    ${result.tuteeAvailabilitySummary?.length
                      ? html`<ul class="window-list">
                          ${result.tuteeAvailabilitySummary.slice(0, 10).map((d) => html`<li class="window-list__item">
                            <strong>${d.weekday} ${fmtDate(d.date, 'short')}</strong>
                            ${d.free.map((iv) => html`<span class="window-list__slot">${fmtTimeRange(iv.start, iv.end)}</span>`)}
                          </li>`)}
                        </ul>`
                      : html`<p class="muted small">No availability recorded for this tutee yet.</p>`}
                  </div>
                </div>`,
            })
          : null}`
      : emptyState({
          title: 'Select a tutee or tutor to begin',
          message: 'The matching screen compares subjects, weekly availability and existing bookings, then ranks the best candidates.',
          iconName: 'match',
        })}

    ${waiting.length
      ? card({
          title: `Tutees waiting for a tutor (${waiting.length})`,
          padded: false,
          body: dataTable({
            columns: [{ label: 'Tutee' }, { label: 'Subjects needed' }, { label: 'Availability' }, { label: 'Action', align: 'right' }],
            rows: waiting.map((t) => ({
              cells: [
                personCell({ name: t.full_name || t.email, email: t.email, href: `/admin/tutees/${t.id}` }),
                subjectChips((t.subject_names || '').split(', ').filter(Boolean).map((name) => ({ name }))),
                html`<span class="muted small">${t.availability_count ? `${t.availability_count} slot(s)` : 'None recorded'}</span>`,
                html`<a class="btn btn--primary btn--sm" href="/admin/matches?tutee=${t.id}">Find tutors</a>`,
              ],
            })),
          }),
        })
      : null}`;
}

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

export function sessionsListPage({ ctx, rows, pageInfo, filters, subjects, tutors, tutees }) {
  const params = { ...filters };
  return html`
    ${pageHeader({
      title: 'Sessions',
      subtitle: `${pageInfo?.total ?? rows.length} session${(pageInfo?.total ?? rows.length) === 1 ? '' : 's'} matching the current filters.`,
      actions: html`
        <a class="btn btn--secondary btn--sm" href="/admin/sessions/export?${raw(new URLSearchParams(Object.entries(filters).filter(([, v]) => v)).toString())}">${icon('download', { size: 14 })}<span>Export CSV</span></a>
        <a class="btn btn--primary btn--sm" href="/admin/sessions/new">${icon('plus', { size: 14 })}<span>Schedule session</span></a>`,
    })}

    ${filterBar({
      action: '/admin/sessions',
      children: html`
        ${field({ label: 'Search', name: 'search', value: filters.search || '', placeholder: 'Tutor, tutee, subject, location' })}
        ${field({ label: 'From', name: 'from', type: 'date', value: filters.from || '' })}
        ${field({ label: 'To', name: 'to', type: 'date', value: filters.to || '' })}
        ${field({ label: 'Subject', name: 'subject', type: 'select', options: subjectFilterOptions(subjects), value: filters.subject })}
        ${field({ label: 'Tutor', name: 'tutor', type: 'select', value: filters.tutor, options: [{ value: 'all', label: 'All tutors' }, ...tutors.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })}
        ${field({ label: 'Tutee', name: 'tutee', type: 'select', value: filters.tutee, options: [{ value: 'all', label: 'All tutees' }, ...tutees.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })}
        ${field({ label: 'Status', name: 'status', type: 'select', value: filters.status, options: [{ value: 'all', label: 'Any status' }, ...Object.values(SESSION_STATUS).map((s) => ({ value: s, label: SESSION_STATUS_LABELS[s] }))] })}
        ${field({ label: 'Mode', name: 'mode', type: 'select', value: filters.mode, options: [{ value: 'all', label: 'Any mode' }, ...Object.values(SESSION_MODE).map((m) => ({ value: m, label: SESSION_MODE_LABELS[m] }))] })}
        ${field({ label: 'Sort', name: 'sort', type: 'select', value: filters.sort, options: [{ value: 'date', label: 'Date' }, { value: 'tutor', label: 'Tutor' }, { value: 'tutee', label: 'Tutee' }, { value: 'subject', label: 'Subject' }, { value: 'status', label: 'Status' }] })}
        ${field({ label: 'Direction', name: 'dir', type: 'select', value: filters.dir, options: [{ value: 'asc', label: 'Ascending' }, { value: 'desc', label: 'Descending' }] })}`,
      resetHref: '/admin/sessions',
    })}

    ${card({
      padded: false,
      body: sessionsTable(rows, { basePath: '/admin/sessions' }),
      footer: pagination(pageInfo, '/admin/sessions', params),
    })}`;
}

export function sessionFormPage({ ctx, mode, subjects, tutors, tutees, values = {}, errors = {}, conflicts = null, session = null, forced = false }) {
  const editing = mode === 'edit';
  const val = (name, fallback = '') => values[name] ?? session?.[name] ?? fallback;
  const settings = getSettings();
  const durationOptions = String(settings.session_duration_options || '30,45,60,90,120').split(',').map((v) => Number(v.trim())).filter(Boolean);
  const start = val('start_min') || val('start') || settings.availability_day_start;
  const end = val('end_min') || val('end') || '17:00';

  return html`
    ${pageHeader({
      title: editing ? `Edit session #${session.id}` : 'Schedule a session',
      subtitle: 'Conflicts with existing bookings or availability are detected before the session is saved.',
      breadcrumbs: html`<a href="/admin/sessions">Sessions</a> <span aria-hidden="true">/</span> <span>${editing ? `#${session.id}` : 'New'}</span>`,
    })}

    ${errors._form ? alert(errors._form, 'danger', { title: 'Session not saved' }) : null}
    ${conflicts?.errors?.length ? alert('The following problems must be resolved before this session can be saved:', 'danger', { title: 'Blocking conflicts', list: conflicts.errors.map((e) => e.message) }) : null}
    ${conflicts?.warnings?.length ? alert('Please review these before saving:', 'warning', { title: 'Warnings', list: conflicts.warnings.map((w) => w.message) }) : null}

    <div class="grid grid--2">
      ${card({
        title: 'Session details',
        body: html`
          <form method="post" action="${editing ? `/admin/sessions/${session.id}` : '/admin/sessions'}" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--2">
              ${field({
                label: 'Tutor', name: 'tutor_id', type: 'select', required: true, error: errorFor(ctx, 'tutor_id'),
                value: val('tutor_id'),
                options: [{ value: '', label: '— choose a tutor —' }, ...tutors.map((t) => ({ value: t.id, label: `${t.full_name || t.email}${t.subject_names ? ` · ${t.subject_names}` : ''}` }))],
              })}
              ${field({
                label: 'Tutee', name: 'tutee_id', type: 'select', required: true, error: errorFor(ctx, 'tutee_id'),
                value: val('tutee_id'),
                options: [{ value: '', label: '— choose a tutee —' }, ...tutees.map((t) => ({ value: t.id, label: `${t.full_name || t.email}${t.subject_names ? ` · ${t.subject_names}` : ''}` }))],
              })}
              ${field({
                label: 'Subject', name: 'subject_id', type: 'select', required: true, error: errorFor(ctx, 'subject_id'),
                value: val('subject_id'),
                options: [{ value: '', label: '— choose a subject —' }, ...subjects.map((s) => ({ value: s.id, label: s.name }))],
              })}
              ${field({ label: 'Date', name: 'date', type: 'date', required: true, value: val('date', todayISO()), error: errorFor(ctx, 'date') })}
              ${field({ label: 'Start time', name: 'start', type: 'time', required: true, value: typeof start === 'number' ? minutesToHHMM(start) : start, error: errorFor(ctx, 'start') })}
              ${field({ label: 'End time', name: 'end', type: 'time', required: true, value: typeof end === 'number' ? minutesToHHMM(end) : end, error: errorFor(ctx, 'end') })}
              ${field({
                label: 'Mode', name: 'mode', type: 'select', value: val('mode', 'in_person'),
                options: Object.values(SESSION_MODE).map((m) => ({ value: m, label: SESSION_MODE_LABELS[m] })),
              })}
              ${field({ label: 'Location or meeting link', name: 'location', value: val('location'), placeholder: 'Room 3, or https://meet.example.com/abc' })}
            </div>
            ${field({ label: 'Session notes (visible to all involved)', name: 'notes', type: 'textarea', rows: 3, value: val('notes'), placeholder: 'Focus areas, resources to bring…' })}
            ${!editing
              ? html`<div class="form-grid form-grid--3">
                  ${field({ label: 'Repeat weekly', name: 'repeat_weeks', type: 'select', value: val('repeat_weeks', '1'), options: [1, 2, 3, 4, 6, 8, 10, 12].map((w) => ({ value: w, label: w === 1 ? 'One-off session' : `${w} weekly sessions` })), hint: 'Occurrences that clash are skipped and reported.' })}
                  ${field({ label: 'Quick duration', name: 'duration_preset', type: 'select', value: val('duration_preset', String(settings.session_duration_default)), options: durationOptions.map((d) => ({ value: d, label: `${d} minutes` })), hint: 'Used by the interactive time helper.' })}
                  ${field({ label: 'Force save despite warnings', name: 'force', type: 'checkbox', value: forced, hint: 'Only blocking conflicts (double bookings) are overridable.' })}
                </div>`
              : html`<div class="form-grid form-grid--2">
                  ${field({ label: 'Update even with availability warnings', name: 'force', type: 'checkbox', value: forced })}
                  ${field({ label: 'Change reason (optional)', name: 'change_reason', placeholder: 'Recorded in session history' })}
                </div>`}
            <div class="form-actions">
              ${button({ label: editing ? 'Save session' : 'Schedule session', iconName: 'check' })}
              <a class="btn btn--ghost" href="/admin/sessions">Cancel</a>
            </div>
          </form>`,
      })}

      ${card({
        title: 'Conflict check',
        subtitle: 'Automatic validation',
        body: conflicts
          ? html`
            <ul class="checklist checklist--status">
              <li class="${conflicts.errors.length ? 'is-warn' : 'is-ok'}">
                ${icon(conflicts.errors.length ? 'warning' : 'check', { size: 15 })}
                <span>${conflicts.errors.length ? `${conflicts.errors.length} blocking conflict(s)` : 'No double bookings detected'}</span>
              </li>
              <li class="${conflicts.warnings.length ? 'is-warn' : 'is-ok'}">
                ${icon(conflicts.warnings.length ? 'warning' : 'check', { size: 15 })}
                <span>${conflicts.warnings.length ? `${conflicts.warnings.length} availability warning(s)` : 'Within both availability windows'}</span>
              </li>
            </ul>
            ${conflicts.tutorConflicts?.length
              ? html`<h3 class="subhead">Tutor is already booked</h3>
                  <ul class="window-list">${conflicts.tutorConflicts.map((c) => html`<li class="window-list__item">${fmtDate(c.date, 'day')} ${fmtTimeRange(c.start_min, c.end_min)} · ${c.subject_name} with ${c.tutee_name}</li>`)}</ul>`
              : null}
            ${conflicts.tuteeConflicts?.length
              ? html`<h3 class="subhead">Tutee is already booked</h3>
                  <ul class="window-list">${conflicts.tuteeConflicts.map((c) => html`<li class="window-list__item">${fmtDate(c.date, 'day')} ${fmtTimeRange(c.start_min, c.end_min)} · ${c.subject_name} with ${c.tutor_name}</li>`)}</ul>`
              : null}`
          : html`<p class="muted small">Choose a tutor, tutee, date and time — the schedule is validated on save, and any existing booking or availability clash is reported here without creating a conflicting session.</p>`,
      })}
    </div>`;
}

export function timetablePage({ ctx, view, date, sessions, filters, tutors, tutees, subjects, counts }) {
  const weekStart = weekStartISO(date);
  return html`
    ${pageHeader({
      title: 'Timetable',
      subtitle: `${counts.total} session${counts.total === 1 ? '' : 's'} in view · ${counts.upcoming} upcoming · ${counts.running} running`,
      actions: html`
        <a class="btn btn--secondary btn--sm" href="/admin/timetable?view=${view}&date=${date}&export=csv">${icon('download', { size: 14 })}<span>Export view</span></a>
        <a class="btn btn--primary btn--sm" href="/admin/sessions/new?date=${date}">${icon('plus', { size: 14 })}<span>Schedule session</span></a>`,
    })}

    ${filterBar({
      action: '/admin/timetable',
      extraHidden: `<input type="hidden" name="view" value="${view}" /><input type="hidden" name="date" value="${date}" />`,
      children: html`
        ${field({ label: 'Subject', name: 'subject', type: 'select', options: subjectFilterOptions(subjects || []), value: filters.subject })}
        ${field({ label: 'Tutor', name: 'tutor', type: 'select', value: filters.tutor, options: [{ value: 'all', label: 'All tutors' }, ...tutors.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })}
        ${field({ label: 'Tutee', name: 'tutee', type: 'select', value: filters.tutee, options: [{ value: 'all', label: 'All tutees' }, ...tutees.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })}
        ${field({ label: 'Status', name: 'status', type: 'select', value: filters.status, options: [{ value: 'all', label: 'Any status' }, ...Object.values(SESSION_STATUS).map((s) => ({ value: s, label: SESSION_STATUS_LABELS[s] }))] })}`,
      resetHref: `/admin/timetable?view=${view}&date=${date}`,
    })}

    ${calendarToolbar({ view, date, basePath: '/admin/timetable', params: { subject: filters.subject, tutor: filters.tutor, tutee: filters.tutee, status: filters.status } })}

    ${card({
      padded: false,
      body: view === 'month'
        ? calendarMonth({ date, sessions, basePath: '/admin/timetable', params: { subject: filters.subject, tutor: filters.tutor, tutee: filters.tutee, status: filters.status } })
        : view === 'week'
          ? calendarWeek({ weekStart, sessions, basePath: '/admin/timetable', params: { subject: filters.subject, tutor: filters.tutor, tutee: filters.tutee, status: filters.status } })
          : calendarDay({ date, sessions }),
    })}

    ${card({
      title: 'Sessions in this view',
      subtitle: 'Click a session to open its full record.',
      padded: false,
      body: sessionsTable(sessions, { basePath: '/admin/sessions', showDate: view !== 'day' }),
    })}`;
}

export function weeklyPage({ ctx, week, stats, filters }) {
  return html`
    ${pageHeader({
      title: 'Weekly session tracking',
      subtitle: `${stats.total} session${stats.total === 1 ? '' : 's'} in the week of ${fmtDate(week, 'long')} · ${durationLabel(stats.totalMinutes)} of tutoring`,
      actions: html`
        <a class="btn btn--secondary btn--sm" href="/admin/weekly/export?week=${week}">${icon('download', { size: 14 })}<span>Export week (CSV)</span></a>
        <a class="btn btn--primary btn--sm" href="/admin/sessions/new?date=${week}">${icon('plus', { size: 14 })}<span>Schedule session</span></a>`,
    })}

    ${weekNavigator({ weekStart: week, basePath: '/admin/weekly' })}

    <section class="stat-grid" aria-label="Weekly totals">
      ${statTile({ label: 'Total sessions', value: stats.total, hint: `Week ${fmtDate(week, 'short')}`, tone: 'primary', iconName: 'calendar' })}
      ${statTile({ label: 'Upcoming', value: stats.upcoming, hint: 'scheduled or confirmed', tone: 'info', iconName: 'clock' })}
      ${statTile({ label: 'Running now', value: stats.counts.running || 0, hint: 'in progress', tone: 'info', iconName: 'activity' })}
      ${statTile({ label: 'Completed', value: stats.counts.completed || 0, hint: 'recorded in history', tone: 'success', iconName: 'check' })}
      ${statTile({ label: 'Cancelled', value: stats.counts.cancelled || 0, hint: 'with reasons', tone: 'danger', iconName: 'x' })}
      ${statTile({ label: 'Missed', value: stats.counts.missed || 0, hint: 'no attendance recorded', tone: 'warning', iconName: 'warning' })}
      ${statTile({ label: 'Hours', value: (stats.totalMinutes / 60).toFixed(1), hint: 'scheduled tutoring time' })}
      ${statTile({ label: 'Today', value: stats.todayTotal, hint: 'sessions today' })}
    </section>

    <div class="grid grid--3">
      ${card({
        title: 'By subject',
        padded: false,
        body: dataTable({
          columns: [{ label: 'Subject' }, { label: 'Total' }, { label: 'Completed' }, { label: 'Cancelled' }, { label: 'Missed' }],
          rows: stats.bySubject.sort((a, b) => b.total - a.total).map((g) => ({
            cells: [g.label, g.total, g.completed, g.cancelled, g.missed],
          })),
          empty: emptyState({ title: 'No sessions this week', iconName: 'book' }),
        }),
      })}
      ${card({
        title: 'By tutor',
        padded: false,
        body: dataTable({
          columns: [{ label: 'Tutor' }, { label: 'Total' }, { label: 'Completed' }, { label: 'Hours' }],
          rows: stats.byTutor.sort((a, b) => b.total - a.total).map((g) => ({
            cells: [g.label, g.total, g.completed, (g.minutes / 60).toFixed(1)],
          })),
          empty: emptyState({ title: 'No tutor sessions', iconName: 'users' }),
        }),
      })}
      ${card({
        title: 'By tutee',
        padded: false,
        body: dataTable({
          columns: [{ label: 'Tutee' }, { label: 'Total' }, { label: 'Completed' }, { label: 'Hours' }],
          rows: stats.byTutee.sort((a, b) => b.total - a.total).map((g) => ({
            cells: [g.label, g.total, g.completed, (g.minutes / 60).toFixed(1)],
          })),
          empty: emptyState({ title: 'No tutee sessions', iconName: 'user' }),
        }),
      })}
    </div>

    ${card({
      title: 'Day-by-day',
      padded: false,
      body: dataTable({
        columns: [{ label: 'Day' }, { label: 'Date' }, { label: 'Sessions' }, { label: 'Completed' }, { label: 'Cancelled' }, { label: 'Missed' }, { label: 'Action', align: 'right' }],
        rows: stats.byDay.map((d) => ({
          cells: [
            d.name,
            fmtDate(d.date, 'short'),
            d.total,
            d.completed,
            d.cancelled,
            d.missed,
            html`<a class="btn btn--ghost btn--sm" href="/admin/timetable?view=day&date=${d.date}">Day view</a>`,
          ],
        })),
      }),
    })}

    ${card({
      title: 'All sessions this week',
      padded: false,
      body: sessionsTable(stats.sessions, { basePath: '/admin/sessions' }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Invitations                                                                */
/* -------------------------------------------------------------------------- */

const invitationTone = (status) => ({ pending: 'info', used: 'success', expired: 'warning', revoked: 'danger' }[status] || 'neutral');

export function invitationsPage({ ctx, list, counts, filters, pageInfo, newLink = null, subjects }) {
  return html`
    ${pageHeader({
      title: 'Invitations',
      subtitle: 'Tutors and tutees can only register through a secure, single-use invitation link.',
      actions: html`<a class="btn btn--primary btn--sm" href="/admin/invitations/new">${icon('plus', { size: 14 })}<span>Create invitation</span></a>`,
    })}

    ${newLink
      ? alert(html`Invitation created for ${newLink.email}. Copy this secure link now — it is shown in full only once.
          <div class="copy-row">
            <input class="input" type="text" value="${newLink.url}" readonly id="new-invite" />
            <button type="button" class="btn btn--secondary btn--sm" data-copy="#new-invite">${icon('link', { size: 14 })}<span>Copy</span></button>
          </div>
          <p class="muted small">Expires ${fmtDateTime(newLink.expiresAt)}. Registration invalidates the link immediately.</p>`, 'success', { title: 'Secure link generated' })
      : null}

    ${tabs([
      { key: 'all', label: 'All', href: '/admin/invitations', count: counts.pending + counts.used + counts.expired + counts.revoked },
      { key: 'pending', label: 'Pending', href: '/admin/invitations?status=pending', count: counts.pending },
      { key: 'used', label: 'Used', href: '/admin/invitations?status=used', count: counts.used },
      { key: 'expired', label: 'Expired', href: '/admin/invitations?status=expired', count: counts.expired },
      { key: 'revoked', label: 'Revoked', href: '/admin/invitations?status=revoked', count: counts.revoked },
    ], filters.status)}

    ${counts.expiringSoon
      ? alert(`${counts.expiringSoon} invitation${counts.expiringSoon === 1 ? '' : 's'} expiring within ${settingInt('invitation_expiry_warning_hours', 24)} hours. Resend to extend the deadline.`, 'warning')
      : null}

    ${filterBar({
      action: '/admin/invitations',
      extraHidden: `<input type="hidden" name="status" value="${filters.status}" />`,
      children: html`
        ${field({ label: 'Search', name: 'search', value: filters.search || '', placeholder: 'Email or name' })}
        ${field({ label: 'Role', name: 'role', type: 'select', value: filters.role, options: [{ value: 'all', label: 'Tutors & tutees' }, { value: 'tutor', label: 'Tutors' }, { value: 'tutee', label: 'Tutees' }] })}`,
      resetHref: `/admin/invitations?status=${filters.status}`,
    })}

    ${card({
      padded: false,
      body: dataTable({
        caption: 'Invitations',
        columns: [{ label: 'Email' }, { label: 'Role' }, { label: 'Subjects' }, { label: 'Created by' }, { label: 'Created' }, { label: 'Expires' }, { label: 'Status' }, { label: 'Actions', align: 'right' }],
        rows: list.rows.map((inv) => ({
          cells: [
            html`<strong>${inv.email}</strong>${inv.full_name ? html`<br /><span class="muted small">${inv.full_name}</span>` : null}`,
            roleBadge(inv.role),
            html`<span class="muted small">${inv.subject_ids ? (JSON.parse(inv.subject_ids || '[]').length ? `${JSON.parse(inv.subject_ids).length} preselected` : '—') : '—'}</span>`,
            html`<span class="muted small">${inv.created_by_label || 'system'}</span>`,
            html`<span class="muted small">${relativeTime(inv.created_at)}</span>`,
            html`<span class="${inv.status === 'expired' ? 'muted' : ''}">${fmtDateTime(inv.expires_at)}</span>`,
            badge(inv.status, invitationTone(inv.status), { dot: true }),
            html`<span class="row-actions">
              ${inv.status === INVITATION_STATUS.PENDING
                ? html`
                  <form class="inline-form" method="post" action="/admin/invitations/${inv.id}/resend">
                    <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                    ${button({ label: 'Resend', variant: 'secondary', size: 'sm', iconName: 'refresh', confirm: 'Resend this invitation? A new link is generated and the old one stops working.' })}
                  </form>
                  <form class="inline-form" method="post" action="/admin/invitations/${inv.id}/revoke">
                    <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
                    ${button({ label: 'Revoke', variant: 'ghost', size: 'sm', iconName: 'x', confirm: 'Revoke this invitation? The link will stop working immediately.' })}
                  </form>`
                : html`<span class="muted small">${inv.used_by_label ? `Used by ${inv.used_by_label}` : 'No actions available'}</span>`}
            </span>`,
          ],
        })),
        empty: emptyState({
          title: 'No invitations here',
          message: 'Create an invitation to onboard a tutor or tutee securely.',
          action: html`<a class="btn btn--primary btn--sm" href="/admin/invitations/new">Create invitation</a>`,
        }),
      }),
      footer: pagination(pageInfo, '/admin/invitations', filters),
    })}`;
}

export function invitationNewPage({ ctx, subjects, defaults = {} }) {
  return html`
    ${pageHeader({
      title: 'Create an invitation',
      subtitle: 'Generate a secure, single-use registration link for a tutor or tutee.',
      breadcrumbs: html`<a href="/admin/invitations">Invitations</a> <span aria-hidden="true">/</span> <span>New</span>`,
    })}

    <div class="grid grid--2">
      ${card({
        title: 'Invitation details',
        body: html`
          <form method="post" action="/admin/invitations" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--2">
              ${field({
                label: 'Invite as', name: 'role', type: 'radio-group', required: true, value: valueFor(ctx, 'role', defaults.role || ROLES.TUTOR),
                options: [
                  { value: ROLES.TUTOR, label: 'Tutor', hint: 'Teaches subjects and holds sessions' },
                  { value: ROLES.TUTEE, label: 'Tutee / student', hint: 'Receives tutoring' },
                ],
                error: errorFor(ctx, 'role'),
              })}
              ${field({
                label: 'Expires in', name: 'expires_hours', type: 'select', value: valueFor(ctx, 'expires_hours', String(settingInt('invitation_expiry_hours', 72))),
                options: [12, 24, 48, 72, 168, 336].map((h) => ({ value: h, label: h < 24 ? `${h} hours` : h === 168 ? '7 days' : h === 336 ? '14 days' : `${h / 24} days` })),
                hint: 'Links expire automatically — the default comes from Settings.',
              })}
            </div>
            <div class="form-grid form-grid--2">
              ${field({ label: 'Email address', name: 'email', type: 'email', required: true, value: valueFor(ctx, 'email'), error: errorFor(ctx, 'email'), hint: 'Must not already have an account.' })}
              ${field({ label: 'Full name (optional)', name: 'full_name', value: valueFor(ctx, 'full_name'), error: errorFor(ctx, 'full_name') })}
            </div>
            ${field({
              label: 'Preselect subjects (optional)', name: 'subjects', type: 'checkbox-group',
              options: subjects.map((s) => ({ value: s.id, label: s.name })),
              value: (() => {
                const raw = ctx.flash?.values?.subjects;
                return raw === undefined ? [] : (Array.isArray(raw) ? raw : [raw]).map(String);
              })(),
              hint: 'Helps the invitee pick the right subjects during registration.',
            })}
            ${field({ label: 'Internal note (optional)', name: 'note', type: 'textarea', rows: 2, value: valueFor(ctx, 'note'), hint: 'Visible to administrators only.', error: errorFor(ctx, 'note') })}
            <div class="form-actions">${button({ label: 'Generate secure link', iconName: 'link' })}</div>
          </form>`,
      })}

      ${card({
        title: 'How secure invitations work',
        body: html`<ol class="steps">
          <li>A 256-bit random token is generated; only its SHA-256 hash is stored, so the raw link is never persisted.</li>
          <li>The link is single-use — registration immediately invalidates it.</li>
          <li>Links expire automatically and can be revoked or resent at any time.</li>
          <li>Resending rotates the token, so any previously shared link stops working.</li>
          <li>Duplicate accounts are blocked by email address.</li>
          <li>Every create, resend, revoke and acceptance is written to the audit log.</li>
        </ol>`,
      })}
    </div>`;
}

/* -------------------------------------------------------------------------- */
/* Administrators                                                             */
/* -------------------------------------------------------------------------- */

export function adminsPage({ ctx, admins, canManage, activity }) {
  return html`
    ${pageHeader({
      title: 'Administrators',
      subtitle: 'Create additional administrators, change roles, disable accounts and review admin activity.',
      actions: canManage ? html`<a class="btn btn--primary btn--sm" href="/admin/admins/new">${icon('plus', { size: 14 })}<span>Add administrator</span></a>` : null,
    })}

    ${!canManage ? alert('Only a Super Admin can create, edit, disable or reset other administrators. You have read-only access to this list.', 'info') : null}

    ${card({
      padded: false,
      body: dataTable({
        caption: 'Administrator accounts',
        columns: [{ label: 'Administrator' }, { label: 'Role' }, { label: 'Status' }, { label: 'Last login' }, { label: 'Actions logged' }, { label: 'Sessions' }, { label: 'Actions', align: 'right' }],
        rows: admins.map((admin) => ({
          cells: [
            personCell({ name: admin.username || admin.email, email: admin.email, href: `/admin/admins/${admin.id}` }),
            roleBadge(admin.role),
            accountBadgeTone(admin.status),
            html`<span class="muted small">${admin.last_login_at ? relativeTime(admin.last_login_at) : 'Never'}</span>`,
            html`<a href="/admin/audit?actor=${admin.id}">${admin.action_count}</a>`,
            html`<span class="muted small">${admin.active_sessions} active</span>`,
            html`<span class="row-actions">
              <a class="btn btn--ghost btn--sm" href="/admin/admins/${admin.id}">${icon('eye', { size: 14 })}<span>View</span></a>
              ${canManage ? html`<a class="btn btn--ghost btn--sm" href="/admin/admins/${admin.id}/edit">${icon('edit', { size: 14 })}<span>Edit</span></a>` : null}
            </span>`,
          ],
        })),
      }),
    })}

    <div class="grid grid--2">
      ${card({
        title: 'Roles & permissions',
        body: html`<ul class="role-list">
          ${STAFF_ROLES.map((role) => html`<li class="role-list__item">
            <div>${roleBadge(role)}</div>
            <p class="muted small">${ROLE_DESCRIPTIONS[role]}</p>
          </li>`)}
        </ul>`,
      })}
      ${card({
        title: 'Recent administrator activity',
        padded: false,
        actions: html`<a class="btn btn--ghost btn--sm" href="/admin/audit">Full log</a>`,
        body: activity.length
          ? html`<ul class="activity">
              ${activity.map((a) => html`<li class="activity__item">
                <span class="activity__action">${a.summary || a.action}</span>
                <span class="muted small">${a.actor_label || 'system'} · ${relativeTime(a.created_at)}</span>
              </li>`)}
            </ul>`
          : emptyState({ title: 'No administrator activity yet', iconName: 'activity' }),
      })}
    </div>`;
}

export function adminFormPage({ ctx, mode, admin = null, canManage, resetLink = null }) {
  const editing = mode === 'edit';
  const val = (name, fallback = '') => valueFor(ctx, name, admin?.[name] ?? fallback);
  return html`
    ${pageHeader({
      title: editing ? `Edit ${admin.username || admin.email}` : 'Add an administrator',
      subtitle: editing ? 'Update role, status and password for this administrator.' : 'Create an additional administrator account with its own credentials.',
      breadcrumbs: html`<a href="/admin/admins">Administrators</a> <span aria-hidden="true">/</span> <span>${editing ? 'Edit' : 'New'}</span>`,
    })}

    ${!canManage ? alert('Only a Super Admin can perform this action.', 'danger') : null}
    ${resetLink
      ? alert(html`Password reset link generated. Send it securely — single use, expires in 24 hours.
          <div class="copy-row">
            <input class="input" type="text" value="${resetLink}" readonly id="admin-reset" />
            <button type="button" class="btn btn--secondary btn--sm" data-copy="#admin-reset">${icon('link', { size: 14 })}<span>Copy</span></button>
          </div>`, 'success')
      : null}

    <div class="grid grid--2">
      ${card({
        title: editing ? 'Account details' : 'New administrator',
        body: html`
          <form method="post" action="${editing ? `/admin/admins/${admin.id}` : '/admin/admins'}" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--2">
              ${field({ label: 'Username', name: 'username', required: true, value: val('username'), error: errorFor(ctx, 'username'), autocomplete: 'off', hint: 'Used to sign in.' })}
              ${field({ label: 'Email address', name: 'email', type: 'email', required: true, value: val('email'), error: errorFor(ctx, 'email') })}
              ${field({
                label: 'Role', name: 'role', type: 'select', required: true, value: val('role', ROLES.ADMIN), error: errorFor(ctx, 'role'),
                options: STAFF_ROLES.map((role) => ({ value: role, label: `${ROLE_LABELS[role]} — ${ROLE_DESCRIPTIONS[role]}` })),
              })}
              ${field({ label: 'Status', name: 'status', type: 'select', value: val('status', ACCOUNT_STATUS.ACTIVE), options: [{ value: ACCOUNT_STATUS.ACTIVE, label: 'Active' }, { value: ACCOUNT_STATUS.DISABLED, label: 'Disabled' }] })}
            </div>
            ${!editing
              ? html`<div class="form-grid form-grid--2">
                  ${field({ label: 'Temporary password', name: 'password', type: 'password', required: true, error: errorFor(ctx, 'password'), hint: 'The new administrator must change this at first sign-in.', autocomplete: 'new-password' })}
                  ${field({ label: 'Confirm password', name: 'password_confirm', type: 'password', required: true, error: errorFor(ctx, 'password_confirm'), autocomplete: 'new-password' })}
                </div>`
              : html`<div class="form-grid form-grid--2">
                  ${field({ label: 'New password (optional)', name: 'password', type: 'password', hint: 'Leave blank to keep the current password.', autocomplete: 'new-password' })}
                  ${field({ label: 'Confirm new password', name: 'password_confirm', type: 'password', autocomplete: 'new-password' })}
                </div>`}
            <div class="form-actions">
              ${button({ label: editing ? 'Save administrator' : 'Create administrator', iconName: 'check', disabled: !canManage })}
              <a class="btn btn--ghost" href="/admin/admins">Cancel</a>
            </div>
          </form>`,
      })}

      ${editing
        ? card({
            title: 'Account security',
            body: html`
              <div class="stack">
                <div class="row-between"><span>Status</span>${accountBadgeTone(admin.status)}</div>
                ${definitionList([
                  ['Last login', admin.last_login_at ? fmtDateTime(admin.last_login_at) : 'Never'],
                  ['Created', fmtDateTime(admin.created_at)],
                  ['Active sessions', String(admin.active_sessions ?? 0)],
                ])}
                <div class="row-actions">
                  ${confirmButton({ action: `/admin/admins/${admin.id}/reset-password`, label: 'Create password reset link', variant: 'secondary', iconName: 'lock', confirm: 'Generate a single-use password reset link for this administrator?', hidden: { _csrf: ctx.csrfToken } })}
                  ${admin.status === ACCOUNT_STATUS.ACTIVE
                    ? confirmButton({ action: `/admin/admins/${admin.id}/status`, label: 'Disable account', confirm: 'Disable this administrator? Their sessions are revoked immediately.', hidden: { _csrf: ctx.csrfToken, status: ACCOUNT_STATUS.DISABLED } })
                    : confirmButton({ action: `/admin/admins/${admin.id}/status`, label: 'Enable account', variant: 'secondary', confirm: 'Enable this administrator?', hidden: { _csrf: ctx.csrfToken, status: ACCOUNT_STATUS.ACTIVE } })}
                  ${confirmButton({ action: `/admin/admins/${admin.id}/sessions/revoke`, label: 'Revoke sessions', variant: 'ghost', confirm: 'Sign this administrator out of every device?', hidden: { _csrf: ctx.csrfToken } })}
                </div>
              </div>`,
          })
        : card({
            title: 'Role capabilities',
            body: html`<ul class="role-list">
              ${STAFF_ROLES.map((role) => html`<li class="role-list__item">
                <div>${roleBadge(role)}</div>
                <p class="muted small">${ROLE_DESCRIPTIONS[role]}</p>
              </li>`)}
            </ul>`,
          })}
    </div>`;
}

export function adminDetailPage({ ctx, admin, permissionsList, recentActivity, canManage, resetLink }) {
  return html`
    ${pageHeader({
      title: admin.username || admin.email,
      subtitle: `${ROLE_LABELS[admin.role]} · ${admin.email}`,
      breadcrumbs: html`<a href="/admin/admins">Administrators</a> <span aria-hidden="true">/</span> <span>${admin.username || admin.email}</span>`,
      actions: canManage ? html`<a class="btn btn--secondary btn--sm" href="/admin/admins/${admin.id}/edit">${icon('edit', { size: 14 })}<span>Edit</span></a>` : null,
    })}

    ${resetLink ? alert(html`Reset link: <code>${resetLink}</code>`, 'success') : null}

    <div class="grid grid--2">
      ${card({
        title: 'Account',
        actions: accountBadgeTone(admin.status),
        body: definitionList([
          ['Username', admin.username],
          ['Email', admin.email],
          ['Role', roleBadge(admin.role)],
          ['Last login', admin.last_login_at ? fmtDateTime(admin.last_login_at) : 'Never'],
          ['Created', fmtDateTime(admin.created_at)],
          ['Actions logged', String(admin.action_count ?? 0)],
        ]),
      })}
      ${card({
        title: 'Effective permissions',
        subtitle: permissionsList.includes('*') ? 'Full system access.' : `${permissionsList.length} permissions granted by role.`,
        body: html`<div class="chip-row">${permissionsList.includes('*')
          ? badge('All permissions', 'primary')
          : join(permissionsList.map((p) => badge(p, 'neutral')), ' ')}</div>`,
      })}
    </div>

    ${card({
      title: 'Recent actions by this administrator',
      padded: false,
      actions: html`<a class="btn btn--ghost btn--sm" href="/admin/audit?actor=${admin.id}">Full log</a>`,
      body: recentActivity.length
        ? html`<ul class="activity">
            ${recentActivity.map((a) => html`<li class="activity__item">
              <span class="activity__action">${a.summary || a.action}</span>
              <span class="muted small">${fmtDateTime(a.created_at)} · ${a.ip || 'unknown IP'}</span>
            </li>`)}
          </ul>`
        : emptyState({ title: 'No recorded actions', iconName: 'activity' }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Reports                                                                    */
/* -------------------------------------------------------------------------- */

export function reportsPage({ ctx, report, reports, from, to }) {
  const exportBase = `/admin/reports/export`;
  return html`
    ${pageHeader({
      title: 'Reports',
      subtitle: 'Filter by date, review the numbers, then export to CSV or PDF.',
      actions: html`
        <a class="btn btn--secondary btn--sm" href="${exportBase}?report=${report.key}&from=${from}&to=${to}&format=csv">${icon('download', { size: 14 })}<span>Export CSV</span></a>
        <a class="btn btn--primary btn--sm" href="${exportBase}?report=${report.key}&from=${from}&to=${to}&format=pdf">${icon('download', { size: 14 })}<span>Export PDF</span></a>`,
    })}

    ${filterBar({
      action: '/admin/reports',
      children: html`
        ${field({ label: 'Report', name: 'report', type: 'select', value: report.key, options: reports.map((r) => ({ value: r.key, label: r.title })) })}
        ${field({ label: 'From', name: 'from', type: 'date', value: from })}
        ${field({ label: 'To', name: 'to', type: 'date', value: to })}
        <div class="filterbar__actions">
          <button class="btn btn--primary btn--sm" type="submit">${icon('report', { size: 14 })}<span>Run report</span></button>
          <button class="btn btn--ghost btn--sm" type="submit" name="quick" value="this_week">This week</button>
          <button class="btn btn--ghost btn--sm" type="submit" name="quick" value="this_month">This month</button>
          <button class="btn btn--ghost btn--sm" type="submit" name="quick" value="this_term">Last 90 days</button>
        </div>`,
    })}

    <section class="stat-grid stat-grid--compact" aria-label="Report totals">
      ${Object.entries(report.totals || {}).map(([key, value]) => statTile({
        label: key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
        value,
      }))}
    </section>

    ${card({
      title: report.title,
      subtitle: `${reports.find((r) => r.key === report.key)?.description || ''} · ${fmtDate(from)} → ${fmtDate(to)} · ${report.rows.length} row${report.rows.length === 1 ? '' : 's'}`,
      padded: false,
      body: dataTable({
        caption: report.title,
        columns: report.columns.map((c) => ({ label: c.label })),
        rows: report.rows.map((row) => ({ cells: report.columns.map((c) => (row[c.key] === undefined || row[c.key] === '' ? html`<span class="muted">—</span>` : String(row[c.key]))) })),
        empty: emptyState({ title: 'No data for this period', message: 'Try widening the date range.', iconName: 'report' }),
      }),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Audit log                                                                  */
/* -------------------------------------------------------------------------- */

export function auditPage({ ctx, entries, pageInfo, filters, actions, actors }) {
  return html`
    ${pageHeader({
      title: 'Activity log',
      subtitle: `${pageInfo.total} recorded action${pageInfo.total === 1 ? '' : 's'} — logins, records created or edited, sessions, invitations and account changes.`,
      actions: html`<a class="btn btn--secondary btn--sm" href="/admin/audit/export?${raw(new URLSearchParams(Object.entries(filters).filter(([, v]) => v)).toString())}">${icon('download', { size: 14 })}<span>Export CSV</span></a>`,
    })}

    ${filterBar({
      action: '/admin/audit',
      children: html`
        ${field({ label: 'Search', name: 'search', value: filters.search || '', placeholder: 'Summary, action or user' })}
        ${field({ label: 'Action', name: 'action', type: 'select', value: filters.action || 'all', options: [{ value: 'all', label: 'All actions' }, ...actions.map((a) => ({ value: a, label: a.replace(/_/g, ' ') }))] })}
        ${field({ label: 'Administrator', name: 'actor', type: 'select', value: filters.actor || 'all', options: [{ value: 'all', label: 'Anyone' }, ...actors.map((a) => ({ value: a.id, label: a.username || a.email }))] })}
        ${field({ label: 'From', name: 'from', type: 'date', value: filters.from || '' })}
        ${field({ label: 'To', name: 'to', type: 'date', value: filters.to || '' })}`,
      resetHref: '/admin/audit',
    })}

    ${card({
      padded: false,
      body: dataTable({
        caption: 'Audit log',
        columns: [{ label: 'When' }, { label: 'Action' }, { label: 'Details' }, { label: 'By' }, { label: 'IP' }],
        rows: entries.map((entry) => ({
          cells: [
            html`<span class="nowrap">${fmtDateTime(entry.created_at)}</span>`,
            html`${badge(entry.action.replace(/_/g, ' '), actionTone(entry.action))}${entry.entity_type ? html`<br /><span class="muted small">${entry.entity_type}${entry.entity_id ? ` #${entry.entity_id}` : ''}</span>` : null}`,
            html`<span>${entry.summary}</span>${entry.details ? html`<details class="inline-details"><summary>Details</summary><pre class="code">${entry.details}</pre></details>` : null}`,
            html`<span class="muted small">${entry.actor_label || 'system'}${entry.actor_role ? ` · ${ROLE_LABELS[entry.actor_role] || entry.actor_role}` : ''}</span>`,
            html`<span class="muted small">${entry.ip || '—'}</span>`,
          ],
        })),
        empty: emptyState({ title: 'No audit entries match', message: 'Adjust the filters to see more history.', iconName: 'activity' }),
      }),
      footer: pagination(pageInfo, '/admin/audit', filters),
    })}`;
}

function actionTone(action) {
  if (/login_failed|disabled|revoked|cancelled|deleted/.test(action)) return 'danger';
  if (/created|approved|enabled/.test(action)) return 'success';
  if (/changed|edited|updated|rescheduled|reset/.test(action)) return 'warning';
  if (/login/.test(action)) return 'info';
  return 'neutral';
}

/* -------------------------------------------------------------------------- */
/* Settings                                                                   */
/* -------------------------------------------------------------------------- */

export function settingsPage({ ctx, settings, system, outbox, canManage }) {
  return html`
    ${pageHeader({
      title: 'Settings',
      subtitle: 'System configuration for sessions, availability, registration, matching and notifications.',
      actions: html`<a class="btn btn--secondary btn--sm" href="/admin/notifications">${icon('bell', { size: 14 })}<span>Notification outbox</span></a>`,
    })}

    ${!canManage ? alert('You can view settings but not change them.', 'info') : null}

    <form method="post" action="/admin/settings" class="form">
      <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
      <div class="grid grid--2">
        ${SETTINGS_GROUPS.map((group) => card({
          title: group.title,
          subtitle: group.hint,
          body: html`<div class="stack">
            ${group.fields.map((key) => settingsField(key, settings[key], key === 'session_duration_options'))}
          </div>`,
        }))}
      </div>
      <div class="form-actions form-actions--sticky">
        ${button({ label: 'Save settings', iconName: 'check', disabled: !canManage })}
        <a class="btn btn--ghost" href="/admin/settings">Reset form</a>
      </div>
    </form>

    <div class="grid grid--2">
      ${card({
        title: 'System information',
        body: definitionList([
          ['Environment', system.env],
          ['Node.js', system.nodeVersion],
          ['Database', system.databasePath],
          ['Database size', system.databaseSize],
          ['Session lifetime', `${system.sessionTtlHours} hours`],
          ['Password hashing', 'scrypt (N=32768, r=8, p=1)'],
          ['Email transport', system.emailTransport],
          ['Uptime', system.uptime],
          ['Accounts', `${system.counts.users} total · ${system.counts.tutors} tutors · ${system.counts.tutees} tutees`],
          ['Sessions stored', String(system.counts.sessions)],
          ['Audit entries', String(system.counts.audit)],
          ['Base URL', system.baseUrl || 'not set (invitation links use the request host)'],
        ]),
      })}

      ${card({
        title: 'Email notifications',
        subtitle: `Transport: ${system.emailTransport}. Every notification is recorded in the outbox, so nothing is lost if SMTP is not configured yet.`,
        actions: html`<a class="btn btn--ghost btn--sm" href="/admin/outbox">Open outbox</a>`,
        body: outbox.length
          ? html`<ul class="list list--tight">
              ${outbox.map((mail) => html`<li class="list__item">
                <div>
                  <strong>${mail.subject}</strong><br />
                  <span class="muted small">to ${mail.to_email} · ${relativeTime(mail.created_at)}</span>
                </div>
                ${badge(mail.status, mail.status === 'sent' ? 'success' : mail.status === 'failed' ? 'danger' : 'warning', { dot: true })}
              </li>`)}
            </ul>`
          : emptyState({ title: 'Outbox empty', message: 'Queued emails appear here.', iconName: 'mail' }),
      })}
    </div>`;
}

function settingsField(key, value, isList = false) {
  const label = key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  const hints = {
    organisation_name: 'Shown in the sidebar, page titles and emails.',
    organisation_email: 'Reply-to address used for outbound mail.',
    session_duration_default: 'Default length used when scheduling.',
    session_duration_options: 'Comma-separated minutes, e.g. 30,45,60,90.',
    availability_day_start: 'Earliest selectable availability time (24h).',
    availability_day_end: 'Latest selectable availability time (24h).',
    availability_slot_minutes: 'Granularity of the availability grid (minutes).',
    invitation_expiry_hours: 'How long a secure registration link stays valid.',
    registration_requires_approval: 'When true, new registrations stay pending until an administrator activates them.',
    default_invited_role: 'Preselected role on the invitation form.',
    min_password_length: 'Minimum number of characters for new passwords.',
    tutor_capacity_default: 'Default maximum tutees per tutor.',
    match_min_overlap_minutes: 'Minimum overlapping free time for an “Available” match.',
    allow_tutor_status_updates: 'Allow tutors to mark their own sessions completed or cancelled.',
    allow_tutor_notes: 'Allow tutors to add session notes.',
    allow_tutee_notes: 'Allow tutees to add session notes.',
    notifications_in_app: 'Show notifications inside the website.',
    notifications_email: 'Also queue email copies of notifications.',
    notify_on_registration: 'Notify administrators when someone registers.',
    notify_on_invitation: 'Notify administrators when invitations are created.',
    session_reminder_lead_minutes: 'How long before a session participants are reminded.',
    invitation_expiry_warning_hours: 'Warn administrators when invitations are within this many hours of expiring.',
    timezone_label: 'Descriptive label shown near times.',
    availability_min_notice_hours: 'Minimum notice (hours) recorded when scheduling.',
  };
  const textish = ['organisation_name', 'organisation_email', 'timezone_label', 'session_duration_default', 'session_duration_options', 'availability_day_start', 'availability_day_end', 'availability_slot_minutes', 'invitation_expiry_hours', 'default_invited_role', 'min_password_length', 'tutor_capacity_default', 'match_min_overlap_minutes', 'session_reminder_lead_minutes', 'invitation_expiry_warning_hours', 'availability_min_notice_hours'];
  if (!textish.includes(key)) {
    return field({ label, name: key, type: 'checkbox', value: value === 'true', hint: hints[key] });
  }
  return field({ label, name: key, value, hint: hints[key] });
}

export function outboxPage({ ctx, list, pageInfo }) {
  return html`
    ${pageHeader({
      title: 'Notification outbox',
      subtitle: 'Every notification email queued by the system. Configure SMTP to deliver these automatically.',
      actions: html`
        <a class="btn btn--secondary btn--sm" href="/admin/outbox/flush">${icon('refresh', { size: 14 })}<span>Retry queued</span></a>
        <a class="btn btn--ghost btn--sm" href="/admin/settings">Email settings</a>`,
    })}

    ${card({
      padded: false,
      body: dataTable({
        caption: 'Email outbox',
        columns: [{ label: 'Queued' }, { label: 'To' }, { label: 'Subject' }, { label: 'Status' }],
        rows: list.rows.map((mail) => ({
          cells: [
            html`<span class="nowrap">${fmtDateTime(mail.created_at)}</span>`,
            mail.to_email,
            html`<details class="inline-details"><summary>${mail.subject}</summary><pre class="code">${mail.body}</pre></details>`,
            badge(mail.status, mail.status === 'sent' ? 'success' : mail.status === 'failed' ? 'danger' : 'warning', { dot: true }),
          ],
        })),
        empty: emptyState({ title: 'Outbox is empty', message: 'Notification emails will appear here.', iconName: 'mail' }),
      }),
      footer: pagination(pageInfo, '/admin/outbox', {}),
    })}`;
}

/* -------------------------------------------------------------------------- */
/* Assignments                                                                */
/* -------------------------------------------------------------------------- */

export function assignmentsPage({ ctx, list, pageInfo, filters, tutors, tutees, subjects }) {
  return html`
    ${pageHeader({
      title: 'Tutor & tutee assignments',
      subtitle: `${pageInfo.total} assignment${pageInfo.total === 1 ? '' : 's'} recorded. Assignments link a tutor to a tutee for a specific subject.`,
    })}

    <div class="grid grid--2">
      ${card({
        title: 'Create an assignment',
        subtitle: 'Usually done from the matching screen once an administrator reviews the match.',
        body: html`
          <form method="post" action="/admin/assignments" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="form-grid form-grid--2">
              ${field({ label: 'Tutor', name: 'tutor_id', type: 'select', required: true, value: valueFor(ctx, 'tutor_id'), error: errorFor(ctx, 'tutor_id'), options: [{ value: '', label: '— choose a tutor —' }, ...tutors.map((t) => ({ value: t.id, label: `${t.full_name || t.email} (${t.student_count}/${t.max_students})` }))] })}
              ${field({ label: 'Tutee', name: 'tutee_id', type: 'select', required: true, value: valueFor(ctx, 'tutee_id'), error: errorFor(ctx, 'tutee_id'), options: [{ value: '', label: '— choose a tutee —' }, ...tutees.map((t) => ({ value: t.id, label: t.full_name || t.email }))] })}
              ${field({ label: 'Subject', name: 'subject_id', type: 'select', required: true, value: valueFor(ctx, 'subject_id'), error: errorFor(ctx, 'subject_id'), options: [{ value: '', label: '— choose a subject —' }, ...subjects.map((s) => ({ value: s.id, label: s.name }))] })}
              ${field({ label: 'Notes (optional)', name: 'notes', value: valueFor(ctx, 'notes') })}
            </div>
            <div class="form-actions">${button({ label: 'Create assignment', iconName: 'link' })}</div>
          </form>`,
      })}
      ${card({
        title: 'Why assignments matter',
        body: html`<ul class="checklist">
          <li>${icon('check', { size: 14 })} They record who teaches whom, from when, for which subject.</li>
          <li>${icon('check', { size: 14 })} Scheduling warns when a session has no matching assignment.</li>
          <li>${icon('check', { size: 14 })} Tutors see their assigned tutees on their dashboard.</li>
          <li>${icon('check', { size: 14 })} Ending an assignment keeps the session history intact.</li>
        </ul>`,
      })}
    </div>

    ${filterBar({
      action: '/admin/assignments',
      children: html`
        ${field({ label: 'Search', name: 'search', value: filters.search || '', placeholder: 'Tutor or tutee name' })}
        ${field({ label: 'Status', name: 'status', type: 'select', value: filters.status, options: [{ value: 'all', label: 'All' }, { value: 'active', label: 'Active' }, { value: 'ended', label: 'Ended' }] })}
        ${field({ label: 'Subject', name: 'subject', type: 'select', options: subjectFilterOptions(subjects), value: filters.subject })}`,
      resetHref: '/admin/assignments',
    })}

    ${card({
      padded: false,
      body: dataTable({
        caption: 'Assignments',
        columns: [{ label: 'Tutor' }, { label: 'Tutee' }, { label: 'Subject' }, { label: 'Started' }, { label: 'Ended' }, { label: 'Sessions' }, { label: 'Status' }, { label: 'Actions', align: 'right' }],
        rows: list.rows.map((a) => ({
          cells: [
            html`<a href="/admin/tutors/${a.tutor_id}">${a.tutor_name}</a>`,
            html`<a href="/admin/tutees/${a.tutee_id}">${a.tutee_name}</a>`,
            subjectChip({ name: a.subject_name, colour: a.subject_colour }),
            fmtDate(String(a.started_at).slice(0, 10), 'short'),
            a.ended_at ? fmtDate(String(a.ended_at).slice(0, 10), 'short') : html`<span class="muted">—</span>`,
            a.session_count,
            badge(a.status === 'active' ? 'Active' : 'Ended', a.status === 'active' ? 'success' : 'neutral', { dot: true }),
            html`<span class="row-actions">
              ${a.status === 'active'
                ? confirmButton({ action: `/admin/assignments/${a.id}/end`, label: 'End', confirm: 'End this assignment? Sessions remain in the history.', hidden: { _csrf: ctx.csrfToken } })
                : html`<span class="muted small">${a.end_reason || 'No actions'}</span>`}
              <a class="btn btn--ghost btn--sm" href="/admin/sessions/new?tutor=${a.tutor_id}&tutee=${a.tutee_id}&subject=${a.subject_id}">${icon('calendar', { size: 14 })}<span>Schedule</span></a>
            </span>`,
          ],
        })),
        empty: emptyState({ title: 'No assignments yet', message: 'Use the matching screen to pair a tutor with a tutee.', iconName: 'link' }),
      }),
      footer: pagination(pageInfo, '/admin/assignments', filters),
    })}`;
}

export { BLOCKING_STATUSES, PERMISSIONS, permissionLabel };

function permissionLabel(permission) {
  return permission.replace(/[._]/g, ' ');
}
