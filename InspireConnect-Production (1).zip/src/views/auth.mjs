/**
 * Public-facing views: sign in, invitation based registration, blocked
 * invitation notices and password management.
 */
import { DEFAULT_BRAND, INVITATION_STATUS, ROLE_LABELS, ROLES, WEEKDAYS } from '../config.mjs';
import { getSettings } from '../db.mjs';
import { alert, badge, button, card, field, html, icon, raw, subjectChip } from '../html.mjs';
import { fmtDate, todayISO } from '../util.mjs';
import { errorFor, timeOptions, valueFor } from './partials.mjs';

const authBrand = (orgName = DEFAULT_BRAND) => html`
  <div class="auth-brand">
    <span class="brand__mark" aria-hidden="true">${icon('match', { size: 22 })}</span>
    <div>
      <strong>${DEFAULT_BRAND}</strong>
      <small>${String(orgName).toLowerCase() === DEFAULT_BRAND.toLowerCase() ? 'Tutor & tutee management' : `${orgName} · tutor & tutee management`}</small>
    </div>
  </div>`;

export function loginPage({ ctx, next = '', error = null, notice = null }) {
  const settings = getSettings();
  return html`
    <div class="auth-card">
      ${authBrand(settings.organisation_name)}
      <h1 class="auth-title">Sign in</h1>
      <p class="auth-subtitle">Administrators, tutors and tutees use the same secure sign-in.</p>
      ${error ? alert(error, 'danger', { title: 'Sign-in failed' }) : null}
      ${notice ? alert(notice, 'info') : null}
      <form method="post" action="/login" class="form" autocomplete="on">
        <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
        <input type="hidden" name="next" value="${next}" />
        ${field({
          label: 'Username or email', name: 'identifier', required: true, autocomplete: 'username',
          placeholder: 'admin or name@example.com', value: valueFor(ctx, 'identifier'),
          error: errorFor(ctx, 'identifier'),
        })}
        ${field({
          label: 'Password', name: 'password', type: 'password', required: true,
          autocomplete: 'current-password', error: errorFor(ctx, 'password'),
        })}
        <div class="form-actions form-actions--between">
          ${button({ label: 'Sign in', iconName: 'logout' })}
          <span class="muted small">Protected by rate limiting and account lockout.</span>
        </div>
      </form>
      <div class="auth-foot">
        <p class="muted small">
          ${icon('lock', { size: 14 })}
          Registration is by invitation only. Tutors and tutees join through a secure, single-use link issued by an administrator.
        </p>
      </div>
    </div>`;
}

export function registerPage({ ctx, invitation, token, subjects, error = null, errors = {}, values = {} }) {
  const settings = getSettings();
  const isTutor = invitation.role === ROLES.TUTOR;
  const val = (name, fallback = '') => values[name] ?? fallback;
  const err = (name) => errors[name] || null;
  const selectedSubjects = (Array.isArray(val('subjects', [])) ? val('subjects', []) : [val('subjects', '')]).map(String);

  return html`
    <div class="auth-card auth-card--wide">
      ${authBrand(settings.organisation_name)}
      <h1 class="auth-title">Create your ${isTutor ? 'tutor' : 'tutee'} account</h1>
      <p class="auth-subtitle">
        You were invited as ${badge(ROLE_LABELS[invitation.role], isTutor ? 'success' : 'info')}.
        This secure link can only be used once and expires ${fmtDate(String(invitation.expires_at).slice(0, 10), 'day')}.
      </p>
      ${error ? alert(error, 'danger', { title: 'Registration could not be completed' }) : null}
      ${Object.keys(errors).length ? alert('Please correct the highlighted fields and try again.', 'danger', { title: 'Check your details' }) : null}

      <form method="post" action="/register/${token}" class="form" autocomplete="on" novalidate>
        <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />

        <fieldset class="fieldset">
          <legend>Your details</legend>
          <div class="form-grid form-grid--2">
            ${field({ label: 'Full name', name: 'full_name', required: true, value: val('full_name', invitation.full_name || ''), autocomplete: 'name', error: err('full_name') })}
            ${field({ label: 'Preferred name', name: 'preferred_name', value: val('preferred_name'), hint: 'What should we call you?', error: err('preferred_name') })}
            ${field({ label: 'Email address', name: 'email', type: 'email', required: true, value: invitation.email, autocomplete: 'email', hint: 'Email is fixed by your invitation.', error: err('email'), disabled: true })}
            ${field({ label: 'Phone number', name: 'phone', type: 'tel', value: val('phone'), autocomplete: 'tel', error: err('phone') })}
            ${isTutor
              ? field({ label: 'Qualifications', name: 'qualifications', value: val('qualifications'), placeholder: 'e.g. BSc Mathematics, PGCE', error: err('qualifications') })
              : field({ label: 'Year / group', name: 'year_level', value: val('year_level'), placeholder: 'e.g. Year 9, GCSE', error: err('year_level') })}
            ${isTutor
              ? field({ label: 'Experience', name: 'experience', type: 'textarea', rows: 3, value: val('experience'), placeholder: 'Years tutoring, specialisms, results…', error: err('experience') })
              : field({ label: 'Guardian name', name: 'guardian_name', value: val('guardian_name'), error: err('guardian_name') })}
          </div>
        </fieldset>

        <fieldset class="fieldset">
          <legend>${isTutor ? 'Subjects you teach' : 'Subjects you need help with'}</legend>
          ${field({
            label: isTutor ? 'Select all that apply' : 'Select all that apply',
            name: 'subjects', type: 'checkbox-group', required: true,
            options: subjects.map((s) => ({ value: s.id, label: s.name, hint: s.description })),
            value: selectedSubjects,
            error: err('subjects'),
          })}
        </fieldset>

        <fieldset class="fieldset">
          <legend>Password</legend>
          ${field({
            label: 'Create a password', name: 'password', type: 'password', required: true,
            autocomplete: 'new-password', error: err('password'),
            hint: `At least ${settings.min_password_length || 10} characters, including a letter and a number.`,
            attributes: 'data-password-strength="true" minlength="' + String(settings.min_password_length || 10) + '"',
          })}
          <div class="strength" data-strength hidden>
            <span class="strength__bar"><span class="strength__fill" data-strength-fill></span></span>
            <span class="strength__label" data-strength-label>Strength</span>
          </div>
          ${field({ label: 'Confirm password', name: 'password_confirm', type: 'password', required: true, autocomplete: 'new-password', error: err('password_confirm') })}
        </fieldset>

        <fieldset class="fieldset">
          <legend>When are you usually available? <span class="muted small">(optional — you can change this later)</span></legend>
          <p class="muted small">Add up to three weekly periods. You can fine-tune these from your dashboard once you sign in.</p>
          <div class="stack stack--tight">
            ${[0, 1, 2].map((i) => html`
              <div class="form-grid form-grid--3">
                ${field({ label: i === 0 ? 'Day' : `Day ${i + 1}`, name: `avail_day_${i}`, type: 'select', options: [{ value: '', label: '— none —' }, ...WEEKDAYS.map((d) => ({ value: d.n, label: d.name }))], value: val(`avail_day_${i}`) })}
                ${field({ label: 'From', name: `avail_from_${i}`, type: 'select', options: [{ value: '', label: '—' }, ...timeOptions(null)], value: val(`avail_from_${i}`) })}
                ${field({ label: 'To', name: `avail_to_${i}`, type: 'select', options: [{ value: '', label: '—' }, ...timeOptions(null)], value: val(`avail_to_${i}`) })}
              </div>`)}
          </div>
        </fieldset>

        <div class="form-actions">
          ${button({ label: 'Create account', iconName: 'check' })}
          <p class="muted small">By creating an account you agree to your tutoring centre's policies. Your invitation link is invalidated as soon as you register.</p>
        </div>
      </form>
    </div>`;
}

export function registerBlockedPage({ ctx, status, message, token = null }) {
  const tone = status === INVITATION_STATUS.PENDING ? 'info' : 'warning';
  const titles = {
    used: 'This invitation has already been used',
    expired: 'This invitation has expired',
    revoked: 'This invitation was revoked',
    invalid: 'This link is not valid',
  };
  return html`
    <div class="auth-card">
      ${authBrand(getSettings().organisation_name)}
      <h1 class="auth-title">${titles[status] || 'Invitation unavailable'}</h1>
      ${alert(message, tone, { title: 'Registration not available' })}
      <ul class="checklist">
        <li>${icon('check', { size: 14 })} Registration links are single-use and expire automatically.</li>
        <li>${icon('check', { size: 14 })} Only administrators can issue or resend an invitation.</li>
        <li>${icon('check', { size: 14 })} If you already registered, sign in instead.</li>
      </ul>
      <div class="auth-actions">
        <a class="btn btn--primary" href="/login">Go to sign in</a>
      </div>
      ${token ? html`<p class="muted small">Reference: ${token.slice(0, 6)}••••••</p>` : null}
    </div>`;
}

export function passwordPage({ ctx, error = null, currentUser }) {
  const settings = getSettings();
  return html`
    <div class="auth-card auth-card--wide">
      <h1 class="auth-title">Change password</h1>
      <p class="auth-subtitle">Signed in as ${currentUser.email} (${ROLE_LABELS[currentUser.role] || currentUser.role}).</p>
      ${error ? alert(error, 'danger', { title: 'Password not changed' }) : null}
      ${ctx.user?.must_change_password
        ? alert('You are still using the initial password. Please choose a new one to continue securely.', 'warning', { title: 'Password change required' })
        : null}
      <form method="post" action="/account/password" class="form" autocomplete="off">
        <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
        ${field({ label: 'Current password', name: 'current_password', type: 'password', required: true, autocomplete: 'current-password' })}
        ${field({
          label: 'New password', name: 'password', type: 'password', required: true, autocomplete: 'new-password',
          hint: `At least ${settings.min_password_length || 10} characters with a letter and a number.`,
        })}
        ${field({ label: 'Confirm new password', name: 'password_confirm', type: 'password', required: true, autocomplete: 'new-password' })}
        <div class="form-actions">
          ${button({ label: 'Update password', iconName: 'lock' })}
          <a class="btn btn--ghost" href="/">Cancel</a>
        </div>
      </form>
    </div>`;
}

export function mustChangePasswordNotice() {
  return alert('You must change the initial administrator password before continuing.', 'warning');
}

export { subjectChip, todayISO, raw };
