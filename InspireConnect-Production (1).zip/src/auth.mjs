/**
 * Authentication, session security and role based access control.
 *
 *  - Passwords: scrypt (N=32768, r=8, p=1) with a per-password random salt,
 *    stored as `scrypt$N$r$p$salt$hash` and compared in constant time.
 *  - Sessions: opaque 256-bit random tokens; only the SHA-256 hash is stored,
 *    so a database leak cannot be replayed as a cookie.
 *  - CSRF: every mutating request must echo the session bound CSRF token.
 *  - RBAC: permissions are derived from the role on the server for every
 *    request. Hiding a button in the UI is never the only protection.
 */
import crypto from 'node:crypto';
import { promisify } from 'node:util';
import { config, ROLES, ROLE_PERMISSIONS, ACCOUNT_STATUS, STAFF_ROLES } from './config.mjs';
import { all, get, run, lastId, tx } from './db.mjs';
import { nowSQL, randomToken, sha256 } from './util.mjs';

const scrypt = promisify(crypto.scrypt);

const SCRYPT = { N: 32768, r: 8, p: 1, keylen: 64, maxmem: 128 * 1024 * 1024 };

/* -------------------------------------------------------------------------- */
/* Passwords                                                                  */
/* -------------------------------------------------------------------------- */

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = await scrypt(String(password), salt, SCRYPT.keylen, {
    N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: SCRYPT.maxmem,
  });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('hex')}$${derived.toString('hex')}`;
}

export async function verifyPassword(password, stored) {
  if (!stored || typeof stored !== 'string') return false;
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, n, r, p, saltHex, hashHex] = parts;
  const salt = Buffer.from(saltHex, 'hex');
  const expected = Buffer.from(hashHex, 'hex');
  let derived;
  try {
    derived = await scrypt(String(password), salt, expected.length, {
      N: Number(n), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem,
    });
  } catch {
    return false;
  }
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

/** Dummy verify used to equalise timing for unknown accounts. */
export async function dummyVerify(password) {
  try {
    await scrypt(String(password), crypto.randomBytes(16), SCRYPT.keylen, {
      N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p, maxmem: SCRYPT.maxmem,
    });
  } catch { /* ignore */ }
  return false;
}

/* -------------------------------------------------------------------------- */
/* Cookies                                                                    */
/* -------------------------------------------------------------------------- */

export function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (!key) continue;
    try {
      out[key] = decodeURIComponent(value);
    } catch {
      out[key] = value;
    }
  }
  return out;
}

export function serializeCookie(name, value, {
  maxAge, expires, httpOnly = true, secure = config.cookieSecure, sameSite = 'Lax', path = '/',
} = {}) {
  const parts = [`${name}=${encodeURIComponent(value ?? '')}`, `Path=${path}`];
  if (httpOnly) parts.push('HttpOnly');
  if (secure) parts.push('Secure');
  parts.push(`SameSite=${sameSite}`);
  if (maxAge !== undefined) parts.push(`Max-Age=${Math.floor(maxAge)}`);
  if (expires) parts.push(`Expires=${expires.toUTCString()}`);
  return parts.join('; ');
}

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

export function createSession(userId, { ip = null, userAgent = null } = {}) {
  const token = randomToken(32);
  const csrf = randomToken(24);
  const expires = new Date(Date.now() + config.sessionTtlHours * 3600 * 1000);
  const result = run(
    `INSERT INTO auth_sessions (user_id, token_hash, csrf_token, ip, user_agent, created_at, last_seen_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, sha256(token), csrf, ip, (userAgent || '').slice(0, 250), nowSQL(), nowSQL(), nowSQL(expires)],
  );
  return { token, csrf, sessionId: lastId(result), expiresAt: expires };
}

export function resolveSession(token) {
  if (!token || typeof token !== 'string') return null;
  const row = get(
    `SELECT s.*, u.role, u.status, u.email, u.username, u.must_change_password, u.last_login_at, u.created_at AS user_created_at
       FROM auth_sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ? AND s.revoked_at IS NULL`,
    [sha256(token)],
  );
  if (!row) return null;
  if (new Date(String(row.expires_at).replace(' ', 'T')) < new Date()) {
    run('UPDATE auth_sessions SET revoked_at = ? WHERE id = ?', [nowSQL(), row.id]);
    return null;
  }
  if (row.status === ACCOUNT_STATUS.DISABLED || row.status === ACCOUNT_STATUS.LOCKED) return null;
  run('UPDATE auth_sessions SET last_seen_at = ? WHERE id = ?', [nowSQL(), row.id]);
  return row;
}

export function revokeSession(token) {
  if (!token) return;
  run('UPDATE auth_sessions SET revoked_at = ? WHERE token_hash = ?', [nowSQL(), sha256(token)]);
}

export function revokeAllSessionsForUser(userId, exceptToken = null) {
  run(
    `UPDATE auth_sessions SET revoked_at = ?
      WHERE user_id = ? AND revoked_at IS NULL AND (? IS NULL OR token_hash <> ?)`,
    [nowSQL(), userId, exceptToken ? sha256(exceptToken) : null, exceptToken ? sha256(exceptToken) : null],
  );
}

/** Alias used by the route modules. */
export const revokeAllSessions = revokeAllSessionsForUser;

export function activeSessionCount(userId) {
  return Number(get(
    'SELECT COUNT(*) AS c FROM auth_sessions WHERE user_id = ? AND revoked_at IS NULL AND expires_at > ?',
    [userId, nowSQL()],
  )?.c || 0);
}

export function sessionsForUser(userId, limit = 8) {
  return all(
    `SELECT id, ip, user_agent, created_at, last_seen_at, expires_at
       FROM auth_sessions WHERE user_id = ? AND revoked_at IS NULL
      ORDER BY last_seen_at DESC LIMIT ?`,
    [userId, limit],
  );
}

/* -------------------------------------------------------------------------- */
/* Permissions                                                                */
/* -------------------------------------------------------------------------- */

export function permissionsFor(role) {
  const perms = ROLE_PERMISSIONS[role] || [];
  return perms.includes('*') ? new Set(['*']) : new Set(perms);
}

export function can(user, permission) {
  if (!user) return false;
  if (user.status && user.status !== ACCOUNT_STATUS.ACTIVE) return false;
  const set = permissionsFor(user.role);
  if (set.has('*')) return true;
  if (set.has(permission)) return true;
  // Any of the .manage permissions implies the matching .view permission.
  if (permission.endsWith('.view')) {
    const manage = `${permission.slice(0, -5)}.manage`;
    if (set.has(manage)) return true;
  }
  return false;
}

export const isStaff = (user) => Boolean(user) && STAFF_ROLES.includes(user.role);
export const isTutor = (user) => Boolean(user) && user.role === ROLES.TUTOR;
export const isTutee = (user) => Boolean(user) && user.role === ROLES.TUTEE;
export const isSuperAdmin = (user) => Boolean(user) && user.role === ROLES.SUPER_ADMIN;

export function portalFor(role) {
  if (role === ROLES.TUTOR) return 'tutor';
  if (role === ROLES.TUTEE) return 'tutee';
  return 'admin';
}

/**
 * The URL a signed-in account belongs at. Kept separate from `portalFor`
 * because the tutee portal is served from `/student`.
 */
export function landingPath(role) {
  if (role === ROLES.TUTOR) return '/tutor';
  if (role === ROLES.TUTEE) return '/student';
  return '/admin';
}

export class HttpError extends Error {
  constructor(status, message, { redirectTo, field, errors } = {}) {
    super(message);
    this.status = status;
    this.expose = status < 500;
    this.redirectTo = redirectTo;
    this.field = field;
    this.errors = errors;
  }
}

export function requirePermission(user, permission) {
  if (!user) throw new HttpError(401, 'Please sign in to continue.');
  if (!can(user, permission)) {
    throw new HttpError(403, 'You do not have permission to perform this action.');
  }
  return true;
}

export function assertOwnershipOrPermission(user, ownerId, permission, message = 'You can only access your own records.') {
  if (!user) throw new HttpError(401, 'Please sign in to continue.');
  if (Number(user.id) === Number(ownerId)) return true;
  if (can(user, permission)) return true;
  throw new HttpError(403, message);
}

/* -------------------------------------------------------------------------- */
/* Login throttling                                                           */
/* -------------------------------------------------------------------------- */

export function recordLoginAttempt(identifier, ip, success, reason = null) {
  run(
    'INSERT INTO login_attempts (identifier, ip, success, reason, created_at) VALUES (?, ?, ?, ?, ?)',
    [String(identifier || '').slice(0, 200).toLowerCase(), ip, success ? 1 : 0, reason, nowSQL()],
  );
}

export function failedAttemptsWithin(identifier, minutes, ip = null) {
  const since = nowSQL(new Date(Date.now() - minutes * 60000));
  const byIdentifier = Number(get(
    'SELECT COUNT(*) AS c FROM login_attempts WHERE success = 0 AND identifier = ? AND created_at >= ?',
    [String(identifier || '').toLowerCase(), since],
  )?.c || 0);
  const byIp = ip
    ? Number(get('SELECT COUNT(*) AS c FROM login_attempts WHERE success = 0 AND ip = ? AND created_at >= ?', [ip, since])?.c || 0)
    : 0;
  return { byIdentifier, byIp };
}

export function clearLoginAttempts(identifier) {
  run('DELETE FROM login_attempts WHERE identifier = ? AND success = 0', [String(identifier || '').toLowerCase()]);
}

export function purgeOldLoginAttempts() {
  run('DELETE FROM login_attempts WHERE created_at < ?', [nowSQL(new Date(Date.now() - 14 * 86400000))]);
}

export function lockAccount(userId, minutes) {
  run('UPDATE users SET locked_until = ?, status = CASE WHEN status = ? THEN ? ELSE status END, updated_at = ? WHERE id = ?', [
    nowSQL(new Date(Date.now() + minutes * 60000)), ACCOUNT_STATUS.ACTIVE, ACCOUNT_STATUS.LOCKED, nowSQL(), userId,
  ]);
}

export function unlockAccount(userId) {
  run(
    'UPDATE users SET locked_until = NULL, failed_attempts = 0, status = CASE WHEN status = ? THEN ? ELSE status END, updated_at = ? WHERE id = ?',
    [ACCOUNT_STATUS.LOCKED, ACCOUNT_STATUS.ACTIVE, nowSQL(), userId],
  );
}

export function isLocked(user) {
  if (!user) return false;
  if (!user.locked_until) return false;
  return new Date(String(user.locked_until).replace(' ', 'T')) > new Date();
}

/* -------------------------------------------------------------------------- */
/* Account helpers                                                            */
/* -------------------------------------------------------------------------- */

export const findUserById = (id) => get('SELECT * FROM users WHERE id = ?', [id]);

export const findUserByLogin = (identifier) => {
  const value = String(identifier || '').trim().toLowerCase();
  if (!value) return null;
  return get('SELECT * FROM users WHERE LOWER(username) = ? OR email = ? LIMIT 1', [value, value]);
};

export function displayName(user) {
  if (!user) return 'Unknown';
  if (user.role === ROLES.TUTOR) {
    const p = get('SELECT full_name, preferred_name FROM tutor_profiles WHERE user_id = ?', [user.id]);
    return p?.preferred_name || p?.full_name || user.email;
  }
  if (user.role === ROLES.TUTEE) {
    const p = get('SELECT full_name, preferred_name FROM tutee_profiles WHERE user_id = ?', [user.id]);
    return p?.preferred_name || p?.full_name || user.email;
  }
  return user.username || user.email;
}

export function displayNameMap(ids = []) {
  const map = new Map();
  for (const id of [...new Set(ids.filter(Boolean))]) {
    const user = findUserById(id);
    map.set(Number(id), displayName(user));
  }
  return map;
}

export function userPublicShape(user) {
  if (!user) return null;
  return {
    id: user.id,
    role: user.role,
    status: user.status,
    username: user.username,
    email: user.email,
    name: displayName(user),
  };
}

/* -------------------------------------------------------------------------- */
/* Audit log                                                                  */
/* -------------------------------------------------------------------------- */

export const AUDIT_ACTIONS = {
  ADMIN_LOGIN: 'admin_login',
  LOGIN: 'login',
  LOGIN_FAILED: 'login_failed',
  LOGOUT: 'logout',
  PASSWORD_CHANGED: 'password_changed',
  PASSWORD_RESET: 'password_reset',
  TUTOR_CREATED: 'tutor_created',
  TUTOR_EDITED: 'tutor_edited',
  TUTOR_STATUS_CHANGED: 'tutor_status_changed',
  TUTOR_DELETED: 'tutor_deleted',
  TUTEE_CREATED: 'tutee_created',
  TUTEE_EDITED: 'tutee_edited',
  TUTEE_STATUS_CHANGED: 'tutee_status_changed',
  TUTEE_DELETED: 'tutee_deleted',
  SUBJECT_CREATED: 'subject_created',
  SUBJECT_EDITED: 'subject_edited',
  SUBJECT_STATUS_CHANGED: 'subject_status_changed',
  SUBJECT_DELETED: 'subject_deleted',
  AVAILABILITY_UPDATED: 'availability_updated',
  SESSION_CREATED: 'session_created',
  SESSION_CHANGED: 'session_changed',
  SESSION_RESCHEDULED: 'session_rescheduled',
  SESSION_CANCELLED: 'session_cancelled',
  SESSION_STATUS_CHANGED: 'session_status_changed',
  SESSION_NOTE_ADDED: 'session_note_added',
  ASSIGNMENT_CREATED: 'assignment_created',
  ASSIGNMENT_ENDED: 'assignment_ended',
  INVITATION_CREATED: 'invitation_created',
  INVITATION_REVOKED: 'invitation_revoked',
  INVITATION_RESENT: 'invitation_resent',
  INVITATION_ACCEPTED: 'invitation_accepted',
  ADMIN_CREATED: 'admin_created',
  ADMIN_EDITED: 'admin_edited',
  ADMIN_STATUS_CHANGED: 'admin_status_changed',
  ACCOUNT_DISABLED: 'account_disabled',
  ACCOUNT_ENABLED: 'account_enabled',
  SETTINGS_UPDATED: 'settings_updated',
  REGISTRATION_SUBMITTED: 'registration_submitted',
  REGISTRATION_BLOCKED: 'registration_blocked',
  REPORT_EXPORTED: 'report_exported',
};

export function audit(actor, action, {
  entityType = null, entityId = null, summary = '', details = null, ip = null,
} = {}) {
  try {
    run(
      `INSERT INTO audit_log (actor_id, actor_label, actor_role, action, entity_type, entity_id, summary, details, ip, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        actor?.id ?? null,
        actor?.label ?? actor?.username ?? 'system',
        actor?.role ?? 'system',
        action,
        entityType,
        entityId,
        summary,
        details ? JSON.stringify(details) : null,
        ip,
        nowSQL(),
      ],
    );
  } catch (error) {
    console.error('[audit] failed to write entry', error.message);
  }
}

export function auditList({ action, actorId, entityType, from, to, search, limit = 50, offset = 0 }) {
  const where = [];
  const params = [];
  if (action) { where.push('action = ?'); params.push(action); }
  if (actorId) { where.push('actor_id = ?'); params.push(actorId); }
  if (entityType) { where.push('entity_type = ?'); params.push(entityType); }
  if (from) { where.push('created_at >= ?'); params.push(`${from} 00:00:00`); }
  if (to) { where.push('created_at <= ?'); params.push(`${to} 23:59:59`); }
  if (search) {
    where.push('(summary LIKE ? OR actor_label LIKE ? OR action LIKE ?)');
    const like = `%${search}%`;
    params.push(like, like, like);
  }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = Number(get(`SELECT COUNT(*) AS c FROM audit_log ${clause}`, params)?.c || 0);
  const rows = all(
    `SELECT * FROM audit_log ${clause} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset],
  );
  return { total, rows };
}

export function toastFor(errors) {
  if (!errors) return null;
  const list = Array.isArray(errors) ? errors : Object.values(errors);
  return list.filter(Boolean).join(' • ');
}

export { ACCOUNT_STATUS, ROLES, tx };
