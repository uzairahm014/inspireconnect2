/**
 * Notification service — in-app notifications (the notification centre) plus
 * optional email delivery for the same events.
 */
import { PERMISSIONS, ROLES, ROLE_PERMISSIONS, STAFF_ROLES } from './config.mjs';
import { all, get, run, lastId, getSettings, settingBool } from './db.mjs';
import { addDaysISO, fmtTime, fmtDate, nowSQL, todayISO } from './util.mjs';
import { queueEmail, renderEmail, flushOutbox, transportName } from './mail.mjs';
import { can } from './auth.mjs';

export const NOTIFICATION_TYPES = {
  REGISTRATION: 'registration',
  REGISTRATION_APPROVED: 'registration_approved',
  INVITATION_USED: 'invitation_used',
  INVITATION_EXPIRING: 'invitation_expiring',
  TUTOR_ASSIGNED: 'tutor_assigned',
  SESSION_SCHEDULED: 'session_scheduled',
  SESSION_CHANGED: 'session_changed',
  SESSION_CANCELLED: 'session_cancelled',
  SESSION_REMINDER: 'session_reminder',
  AVAILABILITY_CONFLICT: 'availability_conflict',
  MATCH_FOUND: 'match_found',
  SYSTEM: 'system',
};

const LEVELS = ['info', 'success', 'warning', 'danger'];

export function notifyUser(userId, { type, title, body = null, link = null, level = 'info', email = null }) {
  const settings = getSettings();
  const user = get('SELECT id, email, status FROM users WHERE id = ?', [userId]);
  if (!user || user.status === 'disabled') return null;
  let notification = null;
  if (settings.notifications_in_app !== 'false') {
    const id = lastId(run(
      `INSERT INTO notifications (user_id, type, title, body, link, level, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, type, title, body, link, LEVELS.includes(level) ? level : 'info', nowSQL()],
    ));
    notification = get('SELECT * FROM notifications WHERE id = ?', [id]);
  }
  const wantEmail = email === null ? settings.notifications_email === 'true' : Boolean(email);
  if (wantEmail && settings.notifications_email === 'true') {
    queueEmail({
      to: user.email,
      subject: title,
      body: renderEmail({
        heading: title,
        lines: [body || ''],
        link,
        linkLabel: 'View in InspireConnect',
      }),
      meta: { type, userId },
    });
    if (transportName() === 'smtp') flushOutbox(5).catch(() => {});
  }
  return notification;
}

/** Notify every active staff member holding a permission (e.g. invitations.manage). */
export function notifyStaff(permission, payload) {
  const staff = all(
    "SELECT id, role FROM users WHERE status = 'active' AND role IN ('super_admin','admin','scheduler','viewer')",
  );
  const delivered = [];
  for (const user of staff) {
    const perms = ROLE_PERMISSIONS[user.role] || [];
    if (!(perms.includes('*') || perms.includes(permission))) continue;
    const notification = notifyUser(user.id, payload);
    if (notification) delivered.push(notification);
  }
  return delivered;
}

export const notifyAdmins = (payload) => notifyStaff('tutors.view', payload);

export function unreadCount(userId) {
  return Number(get('SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND read_at IS NULL', [userId])?.c || 0);
}

export function listNotifications(userId, { unreadOnly = false, limit = 40, offset = 0, type = 'all' } = {}) {
  const where = ['user_id = ?'];
  const params = [userId];
  if (unreadOnly) where.push('read_at IS NULL');
  if (type && type !== 'all') { where.push('type = ?'); params.push(type); }
  const clause = `WHERE ${where.join(' AND ')}`;
  return {
    total: Number(get(`SELECT COUNT(*) AS c FROM notifications ${clause}`, params)?.c || 0),
    unread: unreadCount(userId),
    rows: all(`SELECT * FROM notifications ${clause} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`, [...params, limit, offset]),
  };
}

export function markRead(notificationId, userId) {
  run('UPDATE notifications SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL', [nowSQL(), notificationId, userId]);
}

export function markAllRead(userId) {
  run('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', [nowSQL(), userId]);
}

export function markAllReadFor(list, userId) {
  for (const n of list) markRead(n.id, userId);
}

export function deleteNotification(id, userId) {
  run('DELETE FROM notifications WHERE id = ? AND user_id = ?', [id, userId]);
}

/* -------------------------------------------------------------------------- */
/* Event helpers                                                              */
/* -------------------------------------------------------------------------- */

export function onNewRegistration(user, invitation) {
  notifyStaff('invitations.view', {
    type: NOTIFICATION_TYPES.REGISTRATION,
    title: `New ${user.role} registration`,
    body: `${user.email} registered using an invitation and is awaiting review.`,
    link: user.role === ROLES.TUTOR ? `/admin/tutors/${user.id}` : `/admin/tutees/${user.id}`,
    level: 'info',
  });
  if (getSettings().notify_on_registration === 'true') {
    notifyAdmins({
      type: NOTIFICATION_TYPES.REGISTRATION,
      title: `Registration submitted: ${user.email}`,
      body: 'A new account was created through a secure invitation link.',
      link: '/admin/invitations',
    });
  }
  notifyUser(user.id, {
    type: NOTIFICATION_TYPES.REGISTRATION_APPROVED,
    title: 'Welcome to InspireConnect',
    body: 'Your account is active. Complete your profile and add your availability so we can match you.',
    link: user.role === ROLES.TUTOR ? '/tutor/profile' : '/student/profile',
    level: 'success',
  });
  return invitation;
}

export function onInvitationUsed(invitation, user) {
  notifyStaff('invitations.view', {
    type: NOTIFICATION_TYPES.INVITATION_USED,
    title: `Invitation used — ${invitation.role}`,
    body: `${user.email} completed registration.`,
    link: '/admin/invitations',
    level: 'success',
  });
}

export function onInvitationCreated(invitation, actor) {
  if (getSettings().notify_on_invitation !== 'true') return;
  notifyStaff('invitations.manage', {
    type: NOTIFICATION_TYPES.INVITATION_USED,
    title: `Invitation created for ${invitation.email}`,
    body: `${actor?.label || 'An administrator'} created a ${invitation.role} invitation expiring ${fmtDate(String(invitation.expires_at).slice(0, 10), 'day')}.`,
    link: '/admin/invitations',
  });
}

export function onAssignmentCreated(assignment, actor) {
  notifyUser(assignment.tutor_id, {
    type: NOTIFICATION_TYPES.TUTOR_ASSIGNED,
    title: `New tutee assigned: ${assignment.tutee_name}`,
    body: `${assignment.subject_name} · assigned by ${actor?.label || 'an administrator'}.`,
    link: '/tutor/students',
    level: 'success',
  });
  notifyUser(assignment.tutee_id, {
    type: NOTIFICATION_TYPES.TUTOR_ASSIGNED,
    title: `Your tutor is ${assignment.tutor_name}`,
    body: `You have been assigned a tutor for ${assignment.subject_name}.`,
    link: '/student/tutor',
    level: 'success',
  });
}

export function onAssignmentEnded(assignment, actor, reason) {
  notifyUser(assignment.tutor_id, {
    type: NOTIFICATION_TYPES.TUTOR_ASSIGNED,
    title: `Assignment ended: ${assignment.tutee_name}`,
    body: reason || `${assignment.subject_name} assignment closed by ${actor?.label || 'an administrator'}.`,
    link: '/tutor/students',
    level: 'warning',
  });
  notifyUser(assignment.tutee_id, {
    type: NOTIFICATION_TYPES.TUTOR_ASSIGNED,
    title: `Tutor assignment ended`,
    body: reason || `Your ${assignment.subject_name} assignment has ended.`,
    link: '/student/tutor',
    level: 'warning',
  });
}

export function onSessionScheduled(session, actor) {
  const when = `${fmtDate(session.date, 'long')}, ${fmtTime(session.start_min)}–${fmtTime(session.end_min)}`;
  for (const [userId, link] of [[session.tutor_id, '/tutor/sessions'], [session.tutee_id, '/student/sessions']]) {
    notifyUser(userId, {
      type: NOTIFICATION_TYPES.SESSION_SCHEDULED,
      title: `New session: ${session.subject_name}`,
      body: `${when}${session.location ? ` · ${session.location}` : ''}${session.mode === 'online' ? ' · online' : ''}`,
      link,
      level: 'success',
    });
  }
  notifyStaff('sessions.view', {
    type: NOTIFICATION_TYPES.SESSION_SCHEDULED,
    title: `Session scheduled: ${session.subject_name}`,
    body: `${session.tutor_name || session.tutor_email} with ${session.tutee_name || session.tutee_email} — ${when}`,
    link: `/admin/sessions/${session.id}`,
  });
}

export function onSessionChanged(session, actor, changeSummary) {
  const when = `${fmtDate(session.date, 'long')}, ${fmtTime(session.start_min)}–${fmtTime(session.end_min)}`;
  for (const [userId, link] of [[session.tutor_id, '/tutor/sessions'], [session.tutee_id, '/student/sessions']]) {
    notifyUser(userId, {
      type: NOTIFICATION_TYPES.SESSION_CHANGED,
      title: `Session updated: ${session.subject_name}`,
      body: `${changeSummary} New time: ${when}.`,
      link,
      level: 'warning',
    });
  }
}

export function onSessionCancelled(session, actor, reason) {
  const when = `${fmtDate(session.date, 'long')}, ${fmtTime(session.start_min)}–${fmtTime(session.end_min)}`;
  for (const [userId, link] of [[session.tutor_id, '/tutor/sessions'], [session.tutee_id, '/student/sessions']]) {
    notifyUser(userId, {
      type: NOTIFICATION_TYPES.SESSION_CANCELLED,
      title: `Session cancelled: ${session.subject_name}`,
      body: `${when} was cancelled${reason ? ` — ${reason}` : ''}.`,
      link,
      level: 'danger',
    });
  }
  notifyStaff('sessions.view', {
    type: NOTIFICATION_TYPES.SESSION_CANCELLED,
    title: `Session cancelled: ${session.subject_name}`,
    body: `${session.tutor_name || ''} / ${session.tutee_name || ''} — ${when}`,
    link: `/admin/sessions/${session.id}`,
    level: 'danger',
  });
}

export function onSessionRescheduled(original, created, actor, reason) {
  const when = `${fmtDate(created.date, 'long')}, ${fmtTime(created.start_min)}–${fmtTime(created.end_min)}`;
  for (const [userId, link] of [[created.tutor_id, '/tutor/sessions'], [created.tutee_id, '/student/sessions']]) {
    notifyUser(userId, {
      type: NOTIFICATION_TYPES.SESSION_CHANGED,
      title: `Session rescheduled: ${created.subject_name}`,
      body: `Moved to ${when}${reason ? ` — ${reason}` : ''}.`,
      link,
      level: 'warning',
    });
  }
}

export function onAvailabilityConflict(userId, message, link = null) {
  notifyUser(userId, {
    type: NOTIFICATION_TYPES.AVAILABILITY_CONFLICT,
    title: 'Availability conflict detected',
    body: message,
    link,
    level: 'warning',
  });
}

export function onSessionNoteAdded(session, author) {
  const targets = new Set([session.tutor_id, session.tutee_id]);
  for (const userId of targets) {
    if (Number(userId) === Number(author?.id)) continue;
    notifyUser(userId, {
      type: NOTIFICATION_TYPES.SYSTEM,
      title: `New note on ${session.subject_name} session`,
      body: `${author?.label || 'Someone'} added a session note.`,
      link: userId === Number(session.tutor_id) ? '/tutor/sessions' : '/student/sessions',
    });
  }
}

/** Remind participants about sessions starting soon (idempotent per session/user). */
export function sendUpcomingReminders(settings = getSettings()) {
  const leadMinutes = Number(settings.session_reminder_lead_minutes || 60);
  const now = new Date();
  const today = todayISO(now);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const horizon = nowMin + leadMinutes;
  const todayRows = all(
    `SELECT s.*, sub.name AS subject_name, tp.full_name AS tutor_name, ep.full_name AS tutee_name
       FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
       LEFT JOIN tutor_profiles tp ON tp.user_id = s.tutor_id
       LEFT JOIN tutee_profiles ep ON ep.user_id = s.tutee_id
      WHERE s.date = ? AND s.status IN ('scheduled','confirmed') AND s.start_min > ? AND s.start_min <= ?`,
    [today, nowMin, horizon],
  );
  let sent = 0;
  for (const session of todayRows) {
    for (const userId of [session.tutor_id, session.tutee_id]) {
      const already = get(
        "SELECT 1 AS ok FROM notifications WHERE user_id = ? AND type = 'session_reminder' AND link = ? AND created_at >= ?",
        [userId, `/sessions/${session.id}`, `${today} 00:00:00`],
      );
      if (already) continue;
      const notification = notifyUser(userId, {
        type: NOTIFICATION_TYPES.SESSION_REMINDER,
        title: `Session starting at ${fmtTime(session.start_min)}`,
        body: `${session.subject_name} — ${session.tutor_name || ''} with ${session.tutee_name || ''}.`,
        link: `/sessions/${session.id}`,
        level: 'info',
      });
      if (notification) sent += 1;
    }
  }
  return sent;
}

/** Warn admins about invitations that expire soon. */
export function warnExpiringInvitations(settings = getSettings()) {
  const hours = Number(settings.invitation_expiry_warning_hours || 24);
  const rows = all(
    `SELECT * FROM invitations
      WHERE used_at IS NULL AND revoked_at IS NULL
        AND expires_at > datetime('now') AND expires_at <= datetime('now', ?)`,
    [`+${hours} hours`],
  );
  let sent = 0;
  for (const invitation of rows) {
    const already = get(
      "SELECT 1 AS ok FROM notifications WHERE type = 'invitation_expiring' AND link = ? AND created_at >= datetime('now','-12 hours')",
      [`/admin/invitations?focus=${invitation.id}`],
    );
    if (already) continue;
    const delivered = notifyStaff('invitations.manage', {
      type: NOTIFICATION_TYPES.INVITATION_EXPIRING,
      title: `Invitation expiring soon for ${invitation.email}`,
      body: `Expires ${fmtDate(String(invitation.expires_at).slice(0, 10), 'day')}. Resend or revoke it from Invitation management.`,
      link: `/admin/invitations?focus=${invitation.id}`,
      level: 'warning',
    });
    sent += delivered.length;
  }
  return sent;
}

export { PERMISSIONS, STAFF_ROLES, addDaysISO, can };
