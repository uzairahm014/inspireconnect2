/**
 * Server-side HTML helpers.
 *
 * `html` is a tagged template that escapes every interpolated value by default,
 * which makes cross-site scripting structurally hard: you must opt in with
 * `raw()` to inject markup. All views are written with it.
 */
import { esc } from './util.mjs';
import { SESSION_STATUS_LABELS, ACCOUNT_STATUS_LABELS, MATCH_STATUS_LABELS, ROLE_LABELS, NOTE_VISIBILITY_LABELS, SESSION_NOTE_CATEGORIES } from './config.mjs';

export class Safe {
  constructor(value) {
    this.value = value;
  }

  toString() {
    return this.value === null || this.value === undefined ? '' : String(this.value);
  }
}

export const raw = (value) => new Safe(value);
export const isSafe = (value) => value instanceof Safe;

function renderValue(value) {
  if (value instanceof Safe) return value.toString();
  if (value === null || value === undefined || value === false) return '';
  if (Array.isArray(value)) return value.map(renderValue).join('');
  return esc(value);
}

export function html(strings, ...values) {
  let out = strings[0];
  for (let i = 0; i < values.length; i += 1) {
    out += renderValue(values[i]) + strings[i + 1];
  }
  return raw(out);
}

/** Join a list into a Safe fragment. */
export const join = (items, separator = '') => raw(items.map(renderValue).join(separator));

/* -------------------------------------------------------------------------- */
/* Icons (inline SVG, no external dependencies)                               */
/* -------------------------------------------------------------------------- */

const ICON_PATHS = {
  dashboard: 'M3 3h7v7H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 14h7v7H3z',
  users: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
  calendar: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
  clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
  book: 'M4 19.5A2.5 2.5 0 0 1 6.5 17H20M4 19.5V5a2 2 0 0 1 2-2h14v14H6.5A2.5 2.5 0 0 0 4 19.5z',
  match: 'M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3M21 16v3a2 2 0 0 1-2 2h-3M9 12h6',
  mail: 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 7l-10 6L2 7',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  report: 'M3 3v18h18M7 15v3M12 10v8M17 6v12',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.36.44.65.81.79H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
  bell: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.35-4.35',
  plus: 'M12 5v14M5 12h14',
  edit: 'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z',
  trash: 'M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6',
  check: 'M20 6L9 17l-5-5',
  x: 'M18 6L6 18M6 6l12 12',
  warning: 'M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01',
  info: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-4M12 8h.01',
  logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  filter: 'M22 3H2l8 9.46V19l4 2v-8.54z',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  left: 'M15 18l-6-6 6-6',
  right: 'M9 18l6-6-6-6',
  menu: 'M3 12h18M3 6h18M3 18h18',
  eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  link: 'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71',
  refresh: 'M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15',
  lock: 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM7 11V7a5 5 0 0 1 10 0v4',
  activity: 'M22 12h-4l-3 9L9 3l-3 9H2',
  grid: 'M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z',
  pin: 'M12 22s8-4.5 8-12a8 8 0 1 0-16 0c0 7.5 8 12 8 12zM12 14a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  video: 'M23 7l-7 5 7 5V7zM14 5H3a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z',
};

export function icon(name, { size = 18, className = 'icon' } = {}) {
  const path = ICON_PATHS[name] || ICON_PATHS.info;
  return raw(
    `<svg class="${esc(className)}" width="${Number(size)}" height="${Number(size)}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="${esc(path)}"/></svg>`,
  );
}

/* -------------------------------------------------------------------------- */
/* Badges & chips                                                             */
/* -------------------------------------------------------------------------- */

export function badge(text, tone = 'neutral', { dot = false } = {}) {
  return html`<span class="badge badge--${raw(tone)}">${dot ? raw('<span class="badge__dot" aria-hidden="true"></span>') : ''}${text}</span>`;
}

const SESSION_TONES = {
  scheduled: 'info', confirmed: 'primary', running: 'running', completed: 'success',
  cancelled: 'danger', missed: 'warning', rescheduled: 'neutral',
};
const ACCOUNT_TONES = { active: 'success', pending: 'warning', disabled: 'danger', locked: 'danger' };
const MATCH_TONES = {
  available: 'success', partial: 'warning', busy: 'warning', no_overlap: 'neutral',
  no_subject: 'neutral', assigned: 'primary', inactive: 'danger',
};
const NOTE_TONES = { topics: 'primary', homework: 'info', progress: 'success', follow_up: 'warning', general: 'neutral' };

export const sessionStatusBadge = (status) =>
  badge(SESSION_STATUS_LABELS[status] || status, SESSION_TONES[status] || 'neutral', { dot: true });

export const accountBadge = (status) =>
  badge(ACCOUNT_STATUS_LABELS[status] || status, ACCOUNT_TONES[status] || 'neutral', { dot: true });

export const matchBadge = (status) =>
  badge(MATCH_STATUS_LABELS[status] || status, MATCH_TONES[status] || 'neutral', { dot: true });

export const roleBadge = (role) => badge(ROLE_LABELS[role] || role, role === 'super_admin' ? 'primary' : role === 'tutor' ? 'success' : role === 'tutee' ? 'info' : 'neutral');

export const noteCategoryLabel = (category) => SESSION_NOTE_CATEGORIES[category] || category;

export const noteVisibilityLabel = (visibility) => NOTE_VISIBILITY_LABELS[visibility] || visibility;

export const noteCategoryBadge = (category) => badge(noteCategoryLabel(category), NOTE_TONES[category] || 'neutral');

/**
 * Subject chips carry their colour as a data attribute rather than an inline
 * `style`, because the Content-Security-Policy forbids inline styles. The
 * client applies it to the `--chip-colour` custom property (see public/app.js),
 * and the stylesheet keeps a neutral fallback so the chip still reads well
 * without JavaScript.
 */
export function subjectChip(subject, { link = null } = {}) {
  if (!subject) return raw('');
  const colour = subject.colour || '#475569';
  return link
    ? html`<a class="chip" data-chip-colour="${colour}" href="${link}">${subject.name}</a>`
    : html`<span class="chip" data-chip-colour="${colour}">${subject.name}</span>`;
}

export function subjectChips(subjects = [], { empty = 'None recorded' } = {}) {
  if (!subjects?.length) return html`<span class="muted">${empty}</span>`;
  return join(subjects.map((s) => subjectChip(s)), ' ');
}

export function avatar({ name, photo = null, size = 'md', id = null } = {}) {
  const label = name || 'Unknown';
  const initial = String(label).trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase() || '').join('') || '?';
  const content = photo
    ? raw(`<img src="${esc(photo)}" alt="" class="avatar__img" />`)
    : html`<span class="avatar__initial" aria-hidden="true">${initial}</span>`;
  const inner = html`${content}<span class="sr-only">${label}</span>`;
  return id
    ? html`<a class="avatar avatar--${raw(size)}" href="${id}" aria-label="${label}">${inner}</a>`
    : html`<span class="avatar avatar--${raw(size)}" aria-hidden="true">${content}</span>`;
}

/* -------------------------------------------------------------------------- */
/* Layout primitives                                                          */
/* -------------------------------------------------------------------------- */

export function card({ title = null, subtitle = null, actions = null, body = null, footer = null, padded = true, className = '' } = {}) {
  return html`
    <section class="card ${raw(className)}">
      ${title || actions
        ? html`<header class="card__head">
            <div>
              ${title ? html`<h2 class="card__title">${title}</h2>` : null}
              ${subtitle ? html`<p class="card__subtitle">${subtitle}</p>` : null}
            </div>
            ${actions ? html`<div class="card__actions">${actions}</div>` : null}
          </header>`
        : null}
      <div class="card__body ${padded ? '' : 'card__body--flush'}">${body}</div>
      ${footer ? html`<footer class="card__foot">${footer}</footer>` : null}
    </section>`;
}

export function statTile({ label, value, hint = null, href = null, tone = 'neutral', iconName = null }) {
  const inner = html`
    <div class="stat__top">
      <span class="stat__label">${label}</span>
      ${iconName ? html`<span class="stat__icon stat__icon--${raw(tone)}">${icon(iconName, { size: 16 })}</span>` : null}
    </div>
    <span class="stat__value">${value}</span>
    ${hint ? html`<span class="stat__hint">${hint}</span>` : null}`;
  return href
    ? html`<a class="stat stat--${raw(tone)}" href="${href}">${inner}</a>`
    : html`<div class="stat stat--${raw(tone)}">${inner}</div>`;
}

export function emptyState({ title, message = null, action = null, iconName = 'info' } = {}) {
  return html`
    <div class="empty">
      <span class="empty__icon">${icon(iconName, { size: 26 })}</span>
      <h3 class="empty__title">${title}</h3>
      ${message ? html`<p class="empty__text">${message}</p>` : null}
      ${action ? html`<div class="empty__action">${action}</div>` : null}
    </div>`;
}

export function pageHeader({ title, subtitle = null, actions = null, breadcrumbs = null }) {
  return html`
    <div class="page-head">
      <div>
        ${breadcrumbs ? html`<nav class="crumbs" aria-label="Breadcrumb">${breadcrumbs}</nav>` : null}
        <h1 class="page-title">${title}</h1>
        ${subtitle ? html`<p class="page-subtitle">${subtitle}</p>` : null}
      </div>
      ${actions ? html`<div class="page-actions">${actions}</div>` : null}
    </div>`;
}

export function alert(message, tone = 'info', { title = null, dismissible = false, list = null } = {}) {
  const icons = { info: 'info', success: 'check', warning: 'warning', danger: 'warning', neutral: 'info' };
  return html`
    <div class="alert alert--${raw(tone)}" role="${tone === 'danger' ? 'alert' : 'status'}">
      <span class="alert__icon">${icon(icons[tone] || 'info', { size: 18 })}</span>
      <div class="alert__body">
        ${title ? html`<p class="alert__title">${title}</p>` : null}
        ${message ? html`<p class="alert__text">${message}</p>` : null}
        ${list?.length ? html`<ul class="alert__list">${list.map((item) => html`<li>${item}</li>`)}</ul>` : null}
      </div>
      ${dismissible ? html`<button type="button" class="alert__close" data-dismiss aria-label="Dismiss message">${icon('x', { size: 14 })}</button>` : null}
    </div>`;
}

export function button({ label, variant = 'primary', type = 'submit', href = null, name = null, value = null, size = 'md', iconName = null, attributes = '', confirm = null, disabled = false, ariaLabel = null }) {
  const classes = `btn btn--${variant} btn--${size}`;
  const attrs = raw([
    attributes,
    confirm ? `data-confirm="${esc(confirm)}"` : '',
    disabled ? 'disabled aria-disabled="true"' : '',
    ariaLabel ? `aria-label="${esc(ariaLabel)}"` : '',
  ].filter(Boolean).join(' '));
  const inner = html`${iconName ? icon(iconName, { size: size === 'sm' ? 14 : 16 }) : null}<span>${label}</span>`;
  if (href) return html`<a class="${raw(classes)}" href="${href}" ${attrs}>${inner}</a>`;
  return html`<button class="${raw(classes)}" type="${raw(type)}" ${name ? raw(`name="${esc(name)}" value="${esc(value ?? '')}"`) : ''} ${attrs}>${inner}</button>`;
}

/* -------------------------------------------------------------------------- */
/* Forms                                                                      */
/* -------------------------------------------------------------------------- */

export function field({
  label, name, type = 'text', value = '', hint = null, error = null, required = false,
  placeholder = '', autocomplete = null, options = null, rows = 4, min = null, max = null,
  step = null, id = null, attributes = '', help = null, disabled = false, multiple = false,
}) {
  const fieldId = id || `f_${name}`;
  const described = [hint ? `${fieldId}_hint` : null, error ? `${fieldId}_error` : null].filter(Boolean).join(' ');
  const shared = raw([
    `id="${esc(fieldId)}" name="${esc(name)}"`,
    required ? 'required aria-required="true"' : '',
    disabled ? 'disabled' : '',
    described ? `aria-describedby="${described}"` : '',
    error ? 'aria-invalid="true"' : '',
    placeholder ? `placeholder="${esc(placeholder)}"` : '',
    autocomplete ? `autocomplete="${esc(autocomplete)}"` : '',
    attributes,
  ].filter(Boolean).join(' '));

  let control;
  if (type === 'select') {
    control = html`<select class="input" ${shared}>
      ${(options || []).map((opt) => html`<option value="${opt.value}" ${String(opt.value) === String(value ?? '') ? raw('selected') : ''}>${opt.label}</option>`)}
    </select>`;
  } else if (type === 'textarea') {
    control = html`<textarea class="input input--area" rows="${rows}" ${shared}>${value ?? ''}</textarea>`;
  } else if (type === 'checkbox-group') {
    control = html`<div class="checkgrid" role="group" aria-labelledby="${fieldId}_label" id="${fieldId}">
      ${(options || []).map((opt) => html`
        <label class="check">
          <input type="checkbox" name="${name}" value="${opt.value}" ${(Array.isArray(value) ? value.map(String) : [String(value)]).includes(String(opt.value)) ? raw('checked') : ''} ${disabled ? raw('disabled') : ''} />
          <span class="check__box" aria-hidden="true">${icon('check', { size: 12 })}</span>
          <span class="check__label">${opt.label}${opt.hint ? html`<span class="check__hint">${opt.hint}</span>` : null}</span>
        </label>`)}
    </div>`;
  } else if (type === 'radio-group') {
    control = html`<div class="radiogrid" role="radiogroup" aria-labelledby="${fieldId}_label">
      ${(options || []).map((opt) => html`
        <label class="check check--radio">
          <input type="radio" name="${name}" value="${opt.value}" ${String(opt.value) === String(value ?? '') ? raw('checked') : ''} ${disabled ? raw('disabled') : ''} />
          <span class="check__box" aria-hidden="true">${icon('check', { size: 12 })}</span>
          <span class="check__label">${opt.label}${opt.hint ? html`<span class="check__hint">${opt.hint}</span>` : null}</span>
        </label>`)}
    </div>`;
  } else if (type === 'checkbox') {
    control = html`<label class="switch">
      <input type="checkbox" id="${fieldId}" name="${name}" value="1" ${value ? raw('checked') : ''} ${disabled ? raw('disabled') : ''} />
      <span class="switch__track" aria-hidden="true"><span class="switch__thumb"></span></span>
      <span class="switch__label">${label}</span>
    </label>`;
    return html`<div class="field field--switch ${error ? 'field--error' : ''}">
      ${control}
      ${hint ? html`<p class="field__hint" id="${fieldId}_hint">${hint}</p>` : null}
      ${error ? html`<p class="field__error" id="${fieldId}_error">${error}</p>` : null}
    </div>`;
  } else {
    control = html`<input class="input" type="${raw(type)}" value="${value ?? ''}" ${shared}
      ${min !== null ? raw(`min="${esc(min)}"`) : ''} ${max !== null ? raw(`max="${esc(max)}"`) : ''} ${step !== null ? raw(`step="${esc(step)}"`) : ''}
      ${multiple ? raw('multiple') : ''} />`;
  }

  return html`
    <div class="field ${error ? 'field--error' : ''}">
      <label class="field__label" for="${fieldId}" id="${fieldId}_label">${label}${required ? html`<span class="req" aria-hidden="true">*</span>` : null}</label>
      ${control}
      ${help ? html`<p class="field__help">${help}</p>` : null}
      ${hint ? html`<p class="field__hint" id="${fieldId}_hint">${hint}</p>` : null}
      ${error ? html`<p class="field__error" id="${fieldId}_error">${error}</p>` : null}
    </div>`;
}

export function formGrid(children, { columns = 2 } = {}) {
  return html`<div class="form-grid form-grid--${raw(columns)}">${children}</div>`;
}

export function formActions(children) {
  return html`<div class="form-actions">${children}</div>`;
}

/* -------------------------------------------------------------------------- */
/* Tables, filters, pagination                                                */
/* -------------------------------------------------------------------------- */

export function dataTable({ columns = [], rows = [], empty = null, className = '', caption = null }) {
  if (!rows.length) {
    return empty || emptyState({ title: 'Nothing to show yet', message: 'Records will appear here once they are added.' });
  }
  return html`
    <div class="table-wrap ${raw(className)}">
      <table class="data-table">
        ${caption ? html`<caption class="sr-only">${caption}</caption>` : null}
        <thead>
          <tr>${columns.map((c) => html`<th scope="col" class="${c.align ? `ta-${raw(c.align)}` : ''}">${c.label}</th>`)}</tr>
        </thead>
        <tbody>
          ${rows.map((row) => html`<tr class="${row?._class ? raw(`data-${row._class}`) : ''}">${row.cells.map((cell, i) => html`<td class="${columns[i]?.align ? `ta-${raw(columns[i].align)}` : ''}">${cell}</td>`)}</tr>`)}
        </tbody>
      </table>
    </div>`;
}

export function filterBar({ action, method = 'get', children, resetHref = null, extraHidden = null }) {
  return html`
    <form class="filterbar" method="${raw(method)}" action="${action}" role="search">
      ${extraHidden ? raw(extraHidden) : null}
      ${children}
      <div class="filterbar__actions">
        <button class="btn btn--secondary btn--sm" type="submit">${icon('filter', { size: 14 })}<span>Apply</span></button>
        ${resetHref ? html`<a class="btn btn--ghost btn--sm" href="${resetHref}">Reset</a>` : null}
      </div>
    </form>`;
}

export function pagination(pageInfo, basePath, params = {}) {
  if (!pageInfo || pageInfo.pages <= 1) {
    return pageInfo?.total
      ? html`<p class="pagination__summary">${pageInfo.total} record${pageInfo.total === 1 ? '' : 's'}</p>`
      : null;
  }
  const link = (page) => {
    const qs = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value === undefined || value === null || value === '' || key === 'page') continue;
      if (Array.isArray(value)) for (const v of value) qs.append(key, String(v));
      else qs.set(key, String(value));
    }
    if (page > 1) qs.set('page', String(page));
    const suffix = qs.toString();
    return suffix ? `${basePath}?${suffix}` : basePath;
  };
  const window = [];
  const start = Math.max(1, pageInfo.page - 2);
  const end = Math.min(pageInfo.pages, start + 4);
  for (let i = start; i <= end; i += 1) window.push(i);
  return html`
    <nav class="pagination" aria-label="Pagination">
      <p class="pagination__summary">Showing ${pageInfo.from}–${pageInfo.to} of ${pageInfo.total}</p>
      <div class="pagination__links">
        ${pageInfo.hasPrev ? html`<a class="pagination__link" href="${link(pageInfo.page - 1)}" rel="prev">${icon('left', { size: 14 })}<span>Previous</span></a>` : null}
        ${window.map((p) => (p === pageInfo.page
          ? html`<span class="pagination__link pagination__link--current" aria-current="page">${p}</span>`
          : html`<a class="pagination__link" href="${link(p)}">${p}</a>`))}
        ${pageInfo.hasNext ? html`<a class="pagination__link" href="${link(pageInfo.page + 1)}" rel="next"><span>Next</span>${icon('right', { size: 14 })}</a>` : null}
      </div>
    </nav>`;
}

/* -------------------------------------------------------------------------- */
/* Misc                                                                       */
/* -------------------------------------------------------------------------- */

export function definitionList(items = []) {
  return html`<dl class="defs">${items.filter(Boolean).map(([term, value]) => html`
    <div class="defs__row"><dt>${term}</dt><dd>${value === null || value === undefined || value === '' ? html`<span class="muted">—</span>` : value}</dd></div>`)}</dl>`;
}

export function tabs(items = [], active = null) {
  return html`<nav class="tabs" aria-label="Section">${items.map((item) => html`
    <a class="tabs__item ${item.key === active ? 'is-active' : ''}" href="${item.href}" ${item.key === active ? raw('aria-current="page"') : ''}>${item.label}${item.count !== undefined ? html`<span class="tabs__count">${item.count}</span>` : null}</a>`)}</nav>`;
}

export function confirmButton({ action, label, variant = 'danger', confirm, hidden = {}, iconName = null, size = 'sm' }) {
  return html`
    <form class="inline-form" method="post" action="${action}">
      ${Object.entries(hidden).map(([k, v]) => html`<input type="hidden" name="${k}" value="${v ?? ''}" />`)}
      ${button({ label, variant, confirm, iconName, size })}
    </form>`;
}

export const tone = (value) => raw(value);
