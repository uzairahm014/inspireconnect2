/**
 * Email delivery.
 *
 * Every message is written to the `email_outbox` table first (so nothing is
 * lost and admins can audit what was sent), then handed to a transport:
 *
 *   - `log`  (default): recorded in the outbox as sent, no network needed —
 *            perfect for local development and for this build.
 *   - `smtp` : a small built-in SMTP client (STARTTLS + AUTH LOGIN) used as
 *            soon as SMTP_* environment variables are configured.
 *
 * Notification code never talks to SMTP directly, so swapping in a provider
 * (SendGrid, Postmark, SES…) only means adding another transport here.
 */
import net from 'node:net';
import tls from 'node:tls';
import { config } from './config.mjs';
import { all, get, run, lastId } from './db.mjs';
import { nowSQL } from './util.mjs';

export function queueEmail({ to, subject, body, meta = null, actorId = null }) {
  const id = lastId(run(
    `INSERT INTO email_outbox (to_email, subject, body, status, meta, created_at)
     VALUES (?, ?, ?, 'queued', ?, ?)`,
    [to, subject, body, meta ? JSON.stringify({ ...meta, actorId }) : null, nowSQL()],
  ));
  return get('SELECT * FROM email_outbox WHERE id = ?', [id]);
}

export function outboxList({ status, limit = 50, offset = 0 } = {}) {
  const where = status && status !== 'all' ? 'WHERE status = ?' : '';
  const params = status && status !== 'all' ? [status] : [];
  return {
    total: Number(get(`SELECT COUNT(*) AS c FROM email_outbox ${where}`, params)?.c || 0),
    rows: all(`SELECT * FROM email_outbox ${where} ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`, [...params, limit, offset]),
  };
}

/* -------------------------------------------------------------------------- */
/* Minimal SMTP client                                                        */
/* -------------------------------------------------------------------------- */

const SMTP_TIMEOUT_MS = 12000;

function smtpSend({ host, port, secure, user, password, from, to, subject, body }) {
  return new Promise((resolve, reject) => {
    let socket = secure
      ? tls.connect({ host, port, servername: host, rejectUnauthorized: true })
      : net.connect({ host, port });
    let buffer = '';
    let finished = false;
    const abort = (error) => {
      if (finished) return;
      finished = true;
      try { socket.destroy(); } catch { /* ignore */ }
      reject(error instanceof Error ? error : new Error(String(error)));
    };
    const timer = setTimeout(() => abort(new Error('SMTP connection timed out')), SMTP_TIMEOUT_MS);
    const finish = () => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      try { socket.end(); } catch { /* ignore */ }
      resolve(true);
    };

    const payload = [
      `From: ${from}`,
      `To: ${to}`,
      `Subject: ${subject}`,
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset=utf-8',
      '',
      body.replace(/\r?\n\./g, '\n..'),
    ].join('\r\n');

    const steps = [
      { expect: 220, send: `EHLO inspirelink.local` },
      ...(secure ? [] : [{ expect: 250, send: 'STARTTLS' }]),
      ...(user ? [
        { expect: 334, send: 'AUTH LOGIN' },
        { expect: 334, send: Buffer.from(user).toString('base64') },
        { expect: 235, send: Buffer.from(password || '').toString('base64') },
      ] : []),
      { expect: 250, send: `MAIL FROM:<${extractAddress(from)}>` },
      { expect: 250, send: `RCPT TO:<${extractAddress(to)}>` },
      { expect: 354, send: 'DATA' },
      { expect: 250, send: `${payload}\r\n.` },
      { expect: 221, send: 'QUIT' },
    ];

    const expectFor = (step) => {
      if (!step) return 221;
      if (!secure && step.send === 'EHLO inspirelink.local') return 250;
      return step.expect;
    };

    let index = 0;
    let awaitingUpgrade = false;

    const handleResponse = (code, text) => {
      if (code >= 400) return abort(new Error(`SMTP error ${code}: ${text}`));
      const step = steps[index];
      const expected = expectFor(step);
      if (step && expected && code !== expected && !(expected === 334 && code === 334)) {
        // Tolerate servers that answer 250 to EHLO after STARTTLS negotiation.
        if (!(expected === 220 && code === 250)) return abort(new Error(`SMTP unexpected reply ${code}: ${text}`));
      }
      if (!secure && step?.send === 'STARTTLS' && code === 220) {
        awaitingUpgrade = true;
        return;
      }
      index += 1;
      if (index >= steps.length) return finish();
      sendNext();
    };

    const sendNext = () => {
      const step = steps[index];
      if (!step) return finish();
      socket.write(`${step.send}\r\n`);
    };

    const onData = (chunk) => {
      buffer += chunk.toString('utf8');
      let nl = buffer.indexOf('\n');
      while (nl !== -1) {
        const line = buffer.slice(0, nl).replace(/\r$/, '');
        buffer = buffer.slice(nl + 1);
        if (/^\d{3}[ -]/.test(line)) {
          const code = Number(line.slice(0, 3));
          const text = line.slice(4);
          if (awaitingUpgrade && code === 220) {
            awaitingUpgrade = false;
            socket.removeAllListeners('data');
            socket = tls.connect({ socket, servername: host, rejectUnauthorized: true }, () => {
              socket.on('data', onData);
              socket.on('error', abort);
              index += 1;
              sendNext();
            });
            socket.on('error', abort);
            return;
          }
          handleResponse(code, text);
        }
        nl = buffer.indexOf('\n');
      }
    };

    socket.on('data', onData);
    socket.on('error', abort);
    socket.on('close', () => { if (!finished) abort(new Error('SMTP connection closed unexpectedly')); });
  });
}

const extractAddress = (value) => {
  const match = /<([^>]+)>/.exec(String(value || ''));
  return (match ? match[1] : String(value || '')).trim();
};

/* -------------------------------------------------------------------------- */
/* Transport dispatch                                                         */
/* -------------------------------------------------------------------------- */

export const transportName = () => (config.email.transport === 'smtp' && config.email.host ? 'smtp' : 'log');

export async function deliver(email) {
  if (transportName() === 'smtp') {
    await smtpSend({
      host: config.email.host,
      port: config.email.port,
      secure: config.email.secure,
      user: config.email.user,
      password: config.email.password,
      from: config.email.from,
      to: email.to_email,
      subject: email.subject,
      body: email.body,
    });
    return 'sent';
  }
  // `log` transport: the message remains visible in the admin outbox.
  console.log(`[mail:log] to=${email.to_email} subject="${email.subject}"`);
  return 'sent';
}

export async function flushOutbox(limit = 25) {
  const pending = all("SELECT * FROM email_outbox WHERE status = 'queued' ORDER BY id LIMIT ?", [limit]);
  let sent = 0;
  let failed = 0;
  for (const email of pending) {
    try {
      await deliver(email);
      run("UPDATE email_outbox SET status = 'sent', sent_at = ? WHERE id = ?", [nowSQL(), email.id]);
      sent += 1;
    } catch (error) {
      failed += 1;
      run("UPDATE email_outbox SET status = 'failed', error = ? WHERE id = ?", [String(error.message).slice(0, 500), email.id]);
    }
  }
  return { sent, failed, total: pending.length };
}

export function renderEmail({ heading, lines = [], link = null, linkLabel = 'Open InspireConnect', footer = null }) {
  const body = [
    heading,
    '',
    ...lines,
    ...(link ? ['', `${linkLabel}: ${link}`] : []),
    '',
    '—',
    footer || 'You are receiving this message because you have an InspireConnect tutoring account.',
  ].join('\n');
  return body;
}
