/**
 * Tutor ⇄ tutee matching engine.
 *
 * A match is only "available" when the tutor teaches a subject the tutee needs
 * AND their recorded availability overlaps for long enough to hold a session,
 * after removing time already occupied by scheduled sessions.
 */
import { BLOCKING_STATUSES, MATCH_STATUS, ROLES } from './config.mjs';
import { all, get, getSettings, settingInt } from './db.mjs';
import {
  addDaysISO, fmtTime, isoWeekday, overlapMinutes, todayISO, weekStartISO, weekdayShort,
} from './util.mjs';
import { freeIntervalsForDate, listAvailability, subjectIdsForUser, subjectsForUser } from './people.mjs';

const blockingList = BLOCKING_STATUSES.map(() => '?').join(',');

function scheduleFor(userId, from, to, field) {
  const rows = all(
    `SELECT date, start_min, end_min, subject_id, status FROM sessions
      WHERE ${field} = ? AND date >= ? AND date <= ? AND status IN (${blockingList})`,
    [userId, from, to, ...BLOCKING_STATUSES],
  );
  const map = new Map();
  for (const row of rows) {
    if (!map.has(row.date)) map.set(row.date, []);
    map.get(row.date).push({ start: Number(row.start_min), end: Number(row.end_min), subjectId: row.subject_id });
  }
  return map;
}

function subtractAny(intervals, blocks) {
  let result = intervals.map((iv) => ({ ...iv }));
  for (const block of blocks) {
    const next = [];
    for (const iv of result) {
      if (block.end <= iv.start || block.start >= iv.end) { next.push(iv); continue; }
      if (block.start > iv.start) next.push({ ...iv, end: block.start });
      if (block.end < iv.end) next.push({ ...iv, start: block.end });
    }
    result = next;
  }
  return result.filter((iv) => iv.end > iv.start);
}

function intersect(a, b) {
  const out = [];
  for (const x of a) {
    for (const y of b) {
      const start = Math.max(x.start, y.start);
      const end = Math.min(x.end, y.end);
      if (end > start) out.push({ start, end });
    }
  }
  return out.sort((p, q) => p.start - q.start);
}

/**
 * Find suitable tutors for a tutee.
 *
 * @param {number} tuteeId
 * @param {{subjectId?:number|null, fromDate?:string, days?:number, tutorStatus?:string|'all', minOverlapMinutes?:number}} options
 */
export function matchTutorsForTutee(tuteeId, options = {}) {
  const settings = getSettings();
  const fromDate = options.fromDate || todayISO();
  const days = Math.min(56, Math.max(1, Number(options.days) || 14));
  const toDate = addDaysISO(fromDate, days - 1);
  const minOverlap = Number(options.minOverlapMinutes ?? settings.match_min_overlap_minutes ?? 60);

  const tutee = get(
    `SELECT u.id, u.email, u.status, tp.full_name, tp.preferred_name FROM users u
       LEFT JOIN tutee_profiles tp ON tp.user_id = u.id WHERE u.id = ? AND u.role = ?`,
    [tuteeId, ROLES.TUTEE],
  );
  if (!tutee) return { tutee: null, rows: [], fromDate, toDate, days };

  const tuteeSubjects = subjectIdsForUser(tuteeId, 'need');
  const wantedSubjects = options.subjectId ? [Number(options.subjectId)] : tuteeSubjects;
  const tuteeAvailability = listAvailability(tuteeId);
  const tuteeSchedule = scheduleFor(tuteeId, fromDate, toDate, 'tutee_id');

  const tutors = all(
    `SELECT u.id, u.email, u.status, tp.full_name, tp.preferred_name, tp.max_students, tp.photo
       FROM users u LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
      WHERE u.role = ? ${options.tutorStatus && options.tutorStatus !== 'all' ? 'AND u.status = ?' : ''}
      ORDER BY COALESCE(tp.full_name, u.email)`,
    options.tutorStatus && options.tutorStatus !== 'all' ? [ROLES.TUTOR, options.tutorStatus] : [ROLES.TUTOR],
  );

  const assignedSubjects = new Set(
    all(
      `SELECT subject_id FROM assignments WHERE tutor_id IN (${tutors.map(() => '?').join(',') || 'NULL'})
        AND tutee_id = ? AND status = 'active'`,
      [...tutors.map((t) => t.id), tuteeId],
    ).map((r) => Number(r.subject_id)),
  );

  const rows = tutors.map((tutor) => {
    const teaches = subjectIdsForUser(tutor.id, 'teach');
    const shared = teaches.filter((id) => wantedSubjects.includes(Number(id)));
    const tutorAvailability = listAvailability(tutor.id);
    const tutorSchedule = scheduleFor(tutor.id, fromDate, toDate, 'tutor_id');

    const windows = [];
    for (let i = 0; i < days; i += 1) {
      const date = addDaysISO(fromDate, i);
      const tuteeFree = freeIntervalsForDate(tuteeAvailability, date);
      if (!tuteeFree.length) continue;
      const tutorFree = freeIntervalsForDate(tutorAvailability, date);
      if (!tutorFree.length) continue;
      const raw = intersect(tutorFree, tuteeFree);
      if (!raw.length) continue;
      const blockedTutor = tutorSchedule.get(date) || [];
      const blockedTutee = tuteeSchedule.get(date) || [];
      const bookable = subtractAny(subtractAny(raw, blockedTutor), blockedTutee);
      for (const iv of bookable) {
        windows.push({
          date,
          weekday: weekdayShort(isoWeekday(date)),
          start: iv.start,
          end: iv.end,
          minutes: iv.end - iv.start,
          label: `${weekdayShort(isoWeekday(date))} ${fmtTime(iv.start)}–${fmtTime(iv.end)}`,
        });
      }
    }

    const overlapTotal = windows.reduce((sum, w) => sum + w.minutes, 0);
    const studentCount = Number(get(
      `SELECT COUNT(DISTINCT tutee_id) AS c FROM assignments WHERE tutor_id = ? AND status = 'active'`,
      [tutor.id],
    )?.c || 0);
    const maxStudents = Number(tutor.max_students || settingInt('tutor_capacity_default', 12));
    const sessionsPlanned = Number(get(
      `SELECT COUNT(*) AS c FROM sessions WHERE tutor_id = ? AND date >= ? AND date <= ? AND status IN (${blockingList})`,
      [tutor.id, fromDate, toDate, ...BLOCKING_STATUSES],
    )?.c || 0);

    let status;
    if (tutor.status !== 'active') status = MATCH_STATUS.INACTIVE;
    else if (!shared.length) status = MATCH_STATUS.NO_SUBJECT;
    else if (assignedSubjects.has(shared[0]) && shared.length === 1) status = MATCH_STATUS.ASSIGNED;
    else if (!windows.length) status = MATCH_STATUS.NO_OVERLAP;
    else if (overlapTotal < minOverlap) status = MATCH_STATUS.PARTIAL;
    else status = studentCount >= maxStudents ? MATCH_STATUS.BUSY : MATCH_STATUS.AVAILABLE;

    const capacityFree = Math.max(0, maxStudents - studentCount);
    const score = Math.round(
      (shared.length ? 40 : 0)
      + Math.min(30, (overlapTotal / 60) * 5)
      + Math.min(15, capacityFree * 3)
      + (tutor.status === 'active' ? 15 : 0),
    );

    return {
      tutorId: tutor.id,
      tutorName: tutor.preferred_name || tutor.full_name || tutor.email,
      tutorEmail: tutor.email,
      tutorPhoto: tutor.photo,
      tutorStatus: tutor.status,
      subjectsTaught: teaches.map((id) => id),
      matchedSubjects: subjectsForUser(tutor.id, 'teach').filter((s) => shared.includes(Number(s.id))),
      windows,
      windowCount: windows.length,
      overlapMinutes: overlapTotal,
      requiredMinutes: minOverlap,
      studentCount,
      maxStudents,
      capacityFree,
      sessionsPlanned,
      assigned: shared.some((id) => assignedSubjects.has(Number(id))),
      status,
      score,
      days: groupWindowsByDay(windows),
    };
  });

  const sorted = rows
    .filter((r) => options.includeIrrelevant || r.matchedSubjects.length || r.status === MATCH_STATUS.NO_OVERLAP)
    .sort((a, b) => b.score - a.score || b.overlapMinutes - a.overlapMinutes || a.tutorName.localeCompare(b.tutorName));

  return {
    tutee: { ...tutee, name: tutee.preferred_name || tutee.full_name || tutee.email, subjects: subjectsForUser(tuteeId, 'need') },
    rows: sorted,
    fromDate,
    toDate,
    days,
    minOverlapMinutes: minOverlap,
    tuteeAvailabilitySummary: summarizeDays(tuteeAvailability, fromDate, days),
  };
}

/** Find suitable tutees for a tutor (reverse matching). */
export function matchTuteesForTutor(tutorId, options = {}) {
  const fromDate = options.fromDate || todayISO();
  const days = Math.min(56, Math.max(1, Number(options.days) || 14));
  const toDate = addDaysISO(fromDate, days - 1);
  const tutor = get(
    `SELECT u.id, u.email, u.status, tp.full_name, tp.preferred_name FROM users u
       LEFT JOIN tutor_profiles tp ON tp.user_id = u.id WHERE u.id = ? AND u.role = ?`,
    [tutorId, ROLES.TUTOR],
  );
  if (!tutor) return { tutor: null, rows: [], fromDate, toDate, days };
  const teaches = options.subjectId ? [Number(options.subjectId)] : subjectIdsForUser(tutorId, 'teach');
  const tutorAvailability = listAvailability(tutorId);
  const tutorSchedule = scheduleFor(tutorId, fromDate, toDate, 'tutor_id');

  const tutees = all(
    `SELECT u.id, u.email, u.status, ep.full_name, ep.preferred_name FROM users u
       LEFT JOIN tutee_profiles ep ON ep.user_id = u.id WHERE u.role = 'tutee'
      ORDER BY COALESCE(ep.full_name, u.email)`,
  );

  const rows = tutees.map((tutee) => {
    const needs = subjectIdsForUser(tutee.id, 'need');
    const shared = needs.filter((id) => teaches.includes(Number(id)));
    const tuteeAvailability = listAvailability(tutee.id);
    const tuteeSchedule = scheduleFor(tutee.id, fromDate, toDate, 'tutee_id');
    const windows = [];
    for (let i = 0; i < days; i += 1) {
      const date = addDaysISO(fromDate, i);
      const raw = intersect(freeIntervalsForDate(tutorAvailability, date), freeIntervalsForDate(tuteeAvailability, date));
      if (!raw.length) continue;
      const bookable = subtractAny(subtractAny(raw, tutorSchedule.get(date) || []), tuteeSchedule.get(date) || []);
      for (const iv of bookable) {
        windows.push({ date, weekday: weekdayShort(isoWeekday(date)), start: iv.start, end: iv.end, minutes: iv.end - iv.start, label: `${weekdayShort(isoWeekday(date))} ${fmtTime(iv.start)}–${fmtTime(iv.end)}` });
      }
    }
    const overlapTotal = windows.reduce((sum, w) => sum + w.minutes, 0);
    const assigned = shared.some((id) => get(
      `SELECT 1 AS ok FROM assignments WHERE tutor_id = ? AND tutee_id = ? AND subject_id = ? AND status = 'active'`,
      [tutorId, tutee.id, id],
    ));
    let status;
    if (tutee.status !== 'active') status = MATCH_STATUS.INACTIVE;
    else if (!shared.length) status = MATCH_STATUS.NO_SUBJECT;
    else if (assigned) status = MATCH_STATUS.ASSIGNED;
    else if (!windows.length) status = MATCH_STATUS.NO_OVERLAP;
    else if (overlapTotal < Number(options.minOverlapMinutes ?? 60)) status = MATCH_STATUS.PARTIAL;
    else status = MATCH_STATUS.AVAILABLE;
    return {
      tuteeId: tutee.id,
      tuteeName: tutee.preferred_name || tutee.full_name || tutee.email,
      tuteeEmail: tutee.email,
      tuteeStatus: tutee.status,
      matchedSubjects: subjectsForUser(tutee.id, 'need').filter((s) => shared.includes(Number(s.id))),
      windows,
      overlapMinutes: overlapTotal,
      assigned: Boolean(assigned),
      status,
      score: Math.round((shared.length ? 40 : 0) + Math.min(35, (overlapTotal / 60) * 6) + (tutee.status === 'active' ? 15 : 0)),
      days: groupWindowsByDay(windows),
    };
  });

  return {
    tutor: { ...tutor, name: tutor.preferred_name || tutor.full_name || tutor.email, subjects: subjectsForUser(tutorId, 'teach') },
    rows: rows.sort((a, b) => b.score - a.score || a.tuteeName.localeCompare(b.tuteeName)),
    fromDate,
    toDate,
    days,
  };
}

function groupWindowsByDay(windows) {
  const map = new Map();
  for (const w of windows) {
    if (!map.has(w.date)) map.set(w.date, []);
    map.get(w.date).push(w);
  }
  return [...map.entries()].map(([date, list]) => ({
    date,
    weekday: weekdayShort(isoWeekday(date)),
    minutes: list.reduce((sum, w) => sum + w.minutes, 0),
    windows: list,
  }));
}

function summarizeDays(availabilityRows, fromDate, days) {
  const out = [];
  for (let i = 0; i < days; i += 1) {
    const date = addDaysISO(fromDate, i);
    const free = freeIntervalsForDate(availabilityRows, date);
    if (free.length) out.push({ date, weekday: weekdayShort(isoWeekday(date)), free });
  }
  return out;
}

/**
 * Dashboard helper: tutees still awaiting a tutor, each with their best
 * potential tutor suggestions.
 */
export function pendingMatchSuggestions({ limit = 6, days = 14 } = {}) {
  const tutees = all(
    `SELECT u.id, u.email, ep.full_name, ep.preferred_name FROM users u
       LEFT JOIN tutee_profiles ep ON ep.user_id = u.id
      WHERE u.role = 'tutee' AND u.status = 'active'
        AND NOT EXISTS (SELECT 1 FROM assignments a WHERE a.tutee_id = u.id AND a.status = 'active')
      ORDER BY u.created_at DESC LIMIT ?`,
    [limit],
  );
  return tutees.map((tutee) => {
    const result = matchTutorsForTutee(tutee.id, { days, fromDate: weekStartISO() });
    return {
      tutee: { id: tutee.id, name: tutee.preferred_name || tutee.full_name || tutee.email, email: tutee.email },
      subjects: result.tutee?.subjects || [],
      best: result.rows.filter((r) => r.status === MATCH_STATUS.AVAILABLE).slice(0, 3),
      totalCandidates: result.rows.length,
    };
  });
}

export function matchSummaryForPair(tutorId, tuteeId, { days = 14, subjectId = null } = {}) {
  const result = matchTutorsForTutee(tuteeId, { days, subjectId });
  return result.rows.find((r) => Number(r.tutorId) === Number(tutorId)) || null;
}

export { MATCH_STATUS };
