/**
 * Shared utilities: HTML escaping, date/time maths, validation, pagination,
 * CSV and a small dependency-free PDF writer.
 *
 * Time is stored everywhere as "minutes from midnight" integers so that
 * overlap/conflict maths is exact and free of timezone drift, while dates are
 * plain `YYYY-MM-DD` strings.
 */
import crypto from 'node:crypto';
import { WEEKDAYS, WEEKDAY_BY_N } from './config.mjs';

export const MINUTES_PER_DAY = 24 * 60;

/* -------------------------------------------------------------------------- */
/* Escaping / strings                                                         */
/* -------------------------------------------------------------------------- */

export function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Escape for use inside a JS string literal embedded in a <script> block. */
export function jsonForScript(value) {
  return JSON.stringify(value ?? null)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

export const truncate = (s, n = 80) =>
  s && String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s ?? '');

export const slugify = (s) =>
  String(s || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);

export const titleCase = (s) =>
  String(s || '').replace(/(^|[\s_-])([a-z])/g, (_, a, b) => a.replace(/[_-]/, ' ') + b.toUpperCase());

export const initials = (name) =>
  String(name || '?')
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join('');

/* -------------------------------------------------------------------------- */
/* Ids / tokens                                                               */
/* -------------------------------------------------------------------------- */

export const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
export const sha256 = (value) => crypto.createHash('sha256').update(String(value)).digest('hex');

/* -------------------------------------------------------------------------- */
/* Date helpers (UTC-free, string based)                                      */
/* -------------------------------------------------------------------------- */

export function todayISO(now = new Date()) {
  return toISODate(now);
}

export function toISODate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseISODate(iso) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(iso || ''))) return null;
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(y, m - 1, d, 12, 0, 0, 0);
  return Number.isNaN(dt.getTime()) ? null : dt;
}

export const isISODate = (iso) => parseISODate(iso) !== null;

export function addDaysISO(iso, days) {
  const dt = parseISODate(iso);
  if (!dt) return iso;
  dt.setDate(dt.getDate() + days);
  return toISODate(dt);
}

export function addWeeksISO(iso, weeks) {
  return addDaysISO(iso, weeks * 7);
}

/** ISO weekday: 1 = Monday … 7 = Sunday. */
export function isoWeekday(iso) {
  const dt = parseISODate(iso);
  if (!dt) return 1;
  return ((dt.getDay() + 6) % 7) + 1;
}

/** Monday of the week containing `iso`. */
export function weekStartISO(iso = todayISO()) {
  const dow = isoWeekday(iso);
  return addDaysISO(iso, -(dow - 1));
}

export function weekDays(weekStartIso) {
  return WEEKDAYS.map((d, i) => ({
    ...d,
    date: addDaysISO(weekStartIso, i),
  }));
}

export function monthLabel(iso) {
  const dt = parseISODate(iso);
  if (!dt) return '';
  return dt.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
}

export function fmtDate(iso, style = 'medium') {
  const dt = parseISODate(iso);
  if (!dt) return '—';
  if (style === 'long') return dt.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  if (style === 'short') return dt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  if (style === 'day') return dt.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  return dt.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

export function fmtDateTime(value) {
  if (!value) return '—';
  const dt = value instanceof Date ? value : new Date(String(value).replace(' ', 'T'));
  if (Number.isNaN(dt.getTime())) return String(value);
  return `${dt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}, ${dt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`;
}

export function relativeTime(value, now = new Date()) {
  if (!value) return 'never';
  const dt = value instanceof Date ? value : new Date(String(value).replace(' ', 'T'));
  if (Number.isNaN(dt.getTime())) return 'unknown';
  const diff = Math.round((dt.getTime() - now.getTime()) / 1000);
  const abs = Math.abs(diff);
  const units = [
    ['year', 31536000], ['month', 2592000], ['week', 604800],
    ['day', 86400], ['hour', 3600], ['minute', 60], ['second', 1],
  ];
  for (const [unit, secs] of units) {
    if (abs >= secs || unit === 'second') {
      const n = Math.round(diff / secs);
      try {
        return new Intl.RelativeTimeFormat('en', { numeric: 'auto' }).format(n, unit);
      } catch {
        return `${abs}s`;
      }
    }
  }
  return '';
}

export function nowSQL(date = new Date()) {
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

export function addHours(date, hours) {
  return new Date(date.getTime() + hours * 3600 * 1000);
}

/* -------------------------------------------------------------------------- */
/* Clock / time-of-day helpers                                                */
/* -------------------------------------------------------------------------- */

export function fmtTime(minutes) {
  const m = normalizeMinutes(minutes);
  const h24 = Math.floor(m / 60);
  const mm = String(m % 60).padStart(2, '0');
  const suffix = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${mm} ${suffix}`;
}

export function fmtTimeRange(startMin, endMin) {
  return `${fmtTime(startMin)} – ${fmtTime(endMin)}`;
}

export function hhmmToMinutes(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return normalizeMinutes(value);
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(value || '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h > 23 || mi > 59) return null;
  return h * 60 + mi;
}

export function minutesToHHMM(minutes) {
  const m = normalizeMinutes(minutes);
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
}

export function normalizeMinutes(minutes) {
  const n = Number(minutes) || 0;
  return Math.max(0, Math.min(MINUTES_PER_DAY, Math.round(n)));
}

export function durationLabel(minutes) {
  const m = Number(minutes) || 0;
  const h = Math.floor(m / 60);
  const mm = m % 60;
  if (h && mm) return `${h}h ${mm}m`;
  if (h) return `${h}h`;
  return `${mm}m`;
}

/** Overlap in minutes between two time ranges (0 when they do not overlap). */
export function overlapMinutes(aStart, aEnd, bStart, bEnd) {
  const start = Math.max(Number(aStart), Number(bStart));
  const end = Math.min(Number(aEnd), Number(bEnd));
  return Math.max(0, end - start);
}

export function rangesOverlap(aStart, aEnd, bStart, bEnd) {
  return overlapMinutes(aStart, aEnd, bStart, bEnd) > 0;
}

export function weekdayName(n) {
  return WEEKDAY_BY_N[Number(n)]?.name || '—';
}

export function weekdayShort(n) {
  return WEEKDAY_BY_N[Number(n)]?.short || '—';
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

const EMAIL_RE = /^[^\s@,;:<>()[\]\\"]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i;

export const isValidEmail = (email) =>
  typeof email === 'string' && email.length <= 254 && EMAIL_RE.test(email.trim());

export function normaliseEmail(email) {
  return String(email || '').trim().toLowerCase();
}

export function normalisePhone(phone) {
  return String(phone || '').trim().replace(/[^\d+()\s-]/g, '').slice(0, 32);
}

export function passwordIssues(password, minLength = 10) {
  const issues = [];
  const pw = String(password || '');
  if (pw.length < minLength) issues.push(`Password must be at least ${minLength} characters`);
  if (!/[A-Za-z]/.test(pw)) issues.push('Password must include a letter');
  if (!/\d/.test(pw)) issues.push('Password must include a number');
  if (/^\s|\s$/.test(pw)) issues.push('Password must not start or end with a space');
  if (pw.length > 200) issues.push('Password must be 200 characters or fewer');
  if (/^(password|123456|qwerty|letmein|admin|inspire)/i.test(pw) && pw.length < 14) {
    issues.push('Password is too easy to guess — choose something less common');
  }
  return issues;
}

export function passwordStrength(password) {
  const pw = String(password || '');
  let score = 0;
  if (pw.length >= 10) score += 1;
  if (pw.length >= 14) score += 1;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score += 1;
  if (/\d/.test(pw)) score += 1;
  if (/[^\w\s]/.test(pw)) score += 1;
  const label = ['Very weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'][score] || 'Weak';
  return { score, label, percent: Math.round((score / 5) * 100) };
}

/** Validator helper: collects field errors into a plain object. */
export class Validator {
  constructor(source = {}) {
    this.source = source;
    this.errors = {};
  }

  raw(field) {
    const v = this.source[field];
    return Array.isArray(v) ? v : v === undefined || v === null ? '' : String(v);
  }

  get(field) {
    return this.raw(field).trim();
  }

  fail(field, message) {
    if (!this.errors[field]) this.errors[field] = message;
    return this;
  }

  required(field, label = field) {
    if (!this.get(field)) this.fail(field, `${label} is required`);
    return this;
  }

  maxLength(field, n, label = field) {
    if (this.raw(field).length > n) this.fail(field, `${label} must be ${n} characters or fewer`);
    return this;
  }

  email(field = 'email', { required = true } = {}) {
    const value = this.get(field);
    if (!value) {
      if (required) this.fail(field, 'Email address is required');
      return this;
    }
    if (!isValidEmail(value)) this.fail(field, 'Enter a valid email address (e.g. name@school.org)');
    return this;
  }

  phone(field, { required = false, label = 'Phone number' } = {}) {
    const value = this.get(field);
    if (!value) {
      if (required) this.fail(field, `${label} is required`);
      return this;
    }
    if (value.replace(/\D/g, '').length < 7) this.fail(field, `${label} must contain at least 7 digits`);
    return this;
  }

  oneOf(field, allowed, label = field) {
    const value = this.get(field);
    if (value && !allowed.includes(value)) this.fail(field, `Choose a valid ${label}`);
    return this;
  }

  timeRange(startField, endField) {
    const start = hhmmToMinutes(this.get(startField));
    const end = hhmmToMinutes(this.get(endField));
    if (start === null) this.fail(startField, 'Enter a valid start time');
    if (end === null) this.fail(endField, 'Enter a valid end time');
    if (start !== null && end !== null && end <= start) {
      this.fail(endField, 'End time must be after the start time');
    }
    return this;
  }

  get ok() {
    return Object.keys(this.errors).length === 0;
  }
}

/* -------------------------------------------------------------------------- */
/* Collections / pagination / sorting                                         */
/* -------------------------------------------------------------------------- */

export function groupBy(list, keyFn) {
  const map = new Map();
  for (const item of list) {
    const key = typeof keyFn === 'function' ? keyFn(item) : item[keyFn];
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  }
  return map;
}

export function sum(list, keyFn) {
  return list.reduce((acc, item) => acc + (Number(typeof keyFn === 'function' ? keyFn(item) : item[keyFn]) || 0), 0);
}

export function paginate(total, page = 1, perPage = 20) {
  const per = Math.max(1, Math.min(200, Number(perPage) || 20));
  const pages = Math.max(1, Math.ceil(Number(total) / per));
  const current = Math.max(1, Math.min(pages, Number(page) || 1));
  return {
    total: Number(total) || 0,
    perPage: per,
    page: current,
    pages,
    offset: (current - 1) * per,
    hasPrev: current > 1,
    hasNext: current < pages,
    from: Number(total) ? (current - 1) * per + 1 : 0,
    to: Math.min(Number(total) || 0, current * per),
  };
}

export const PER_PAGE_CHOICES = [10, 20, 50, 100];

export function sortRows(rows, key, dir = 'asc') {
  const sign = dir === 'desc' ? -1 : 1;
  return [...rows].sort((a, b) => {
    const av = a?.[key];
    const bv = b?.[key];
    if (av === null || av === undefined) return 1;
    if (bv === null || bv === undefined) return -1;
    if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * sign;
    return String(av).localeCompare(String(bv), 'en', { sensitivity: 'base' }) * sign;
  });
}

export function paginationQuery(params, page) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params || {})) {
    if (v === undefined || v === null || v === '' || k === 'page') continue;
    qs.set(k, String(v));
  }
  qs.set('page', String(page));
  return qs.toString();
}

/* -------------------------------------------------------------------------- */
/* CSV                                                                        */
/* -------------------------------------------------------------------------- */

export function toCSV(headers, rows) {
  const cell = (value) => {
    const s = value === null || value === undefined ? '' : String(value);
    // Guard against spreadsheet formula injection.
    const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
    return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
  };
  const keys = headers.map((h) => (typeof h === 'string' ? h : (h.key ?? h.label)));
  const lines = [headers.map((h) => cell(typeof h === 'string' ? h : h.label)).join(',')];
  for (const row of rows) {
    const values = Array.isArray(row) ? row : keys.map((key) => row?.[key]);
    lines.push(values.map((value) => cell(value)).join(','));
  }
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

/* -------------------------------------------------------------------------- */
/* Minimal PDF writer (no external dependencies)                              */
/* -------------------------------------------------------------------------- */

function pdfEscape(text) {
  return String(text ?? '')
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
}

/**
 * Build a simple multi-page PDF.
 * @param {{title: string, subtitle?: string, meta?: string[], columns?: {label:string,width:number}[], rows?: any[][], fontSizes?: {title?:number, body?:number}}} doc
 */
export function buildPDF(doc) {
  const pageWidth = 842;   // A4 landscape — roomier for tables
  const pageHeight = 595;
  const margin = 36;
  const bodySize = doc.fontSizes?.body ?? 9;
  const titleSize = doc.fontSizes?.title ?? 16;
  const lineHeight = bodySize + 4;
  const headerBlock = 70;
  const footerBlock = 34;
  const rowsPerPage = Math.max(1, Math.floor((pageHeight - margin * 2 - headerBlock - footerBlock) / lineHeight));

  const columns = doc.columns || [];
  const totalWidth = columns.reduce((a, c) => a + c.width, 0) || 1;
  const usable = pageWidth - margin * 2;
  const colX = [];
  let acc = margin;
  for (const c of columns) {
    colX.push(acc);
    acc += (c.width / totalWidth) * usable;
  }

  const rows = doc.rows || [];
  const pages = [];
  for (let i = 0; i < Math.max(1, Math.ceil(rows.length / rowsPerPage)); i += 1) {
    pages.push(rows.slice(i * rowsPerPage, (i + 1) * rowsPerPage));
  }
  const totalPages = pages.length;

  const contentOf = (pageRows, pageIndex) => {
    const out = [];
    out.push(`BT /F2 ${titleSize} Tf ${margin} ${pageHeight - margin - titleSize} Td (${pdfEscape(doc.title)}) Tj ET`);
    let y = pageHeight - margin - titleSize - 16;
    if (doc.subtitle) {
      out.push(`BT /F1 ${bodySize + 1} Tf ${margin} ${y} Td (${pdfEscape(doc.subtitle)}) Tj ET`);
      y -= lineHeight;
    }
    for (const line of doc.meta || []) {
      out.push(`BT /F1 ${bodySize} Tf ${margin} ${y} Td (${pdfEscape(line)}) Tj ET`);
      y -= lineHeight;
    }
    y -= 4;
    if (columns.length) {
      out.push(`0.85 0.87 0.92 rg ${margin} ${y - 4} ${usable} ${lineHeight} re f 0 0 0 rg`);
      columns.forEach((c, idx) => {
        out.push(`BT /F2 ${bodySize} Tf ${colX[idx]} ${y} Td (${pdfEscape(c.label)}) Tj ET`);
      });
      y -= lineHeight;
      out.push(`0.8 0.82 0.88 RG 0.5 w ${margin} ${y + lineHeight - 4} m ${margin + usable} ${y + lineHeight - 4} l S`);
    }
    for (const row of pageRows) {
      if (y < margin + footerBlock) break;
      row.forEach((cell, idx) => {
        if (idx >= columns.length) return;
        const maxChars = Math.floor(((columns[idx].width / totalWidth) * usable) / (bodySize * 0.5));
        const text = truncate(String(cell ?? '').replace(/\s+/g, ' '), Math.max(4, maxChars));
        out.push(`BT /F1 ${bodySize} Tf ${colX[idx]} ${y} Td (${pdfEscape(text)}) Tj ET`);
      });
      y -= lineHeight;
    }
    const stamp = `Generated ${new Date().toISOString().slice(0, 16).replace('T', ' ')}  ·  Page ${pageIndex + 1} of ${totalPages}`;
    out.push(`BT /F1 8 Tf ${margin} ${margin - 12} Td (${pdfEscape(stamp)}) Tj ET`);
    return out.join('\n');
  };

  const objects = [];
  const pageObjectNumbers = pages.map((_, i) => 4 + i * 2);
  objects.push({ id: 1, body: '<< /Type /Catalog /Pages 2 0 R >>' });
  objects.push({ id: 2, body: `<< /Type /Pages /Kids [${pageObjectNumbers.map((n) => `${n} 0 R`).join(' ')}] /Count ${pages.length} >>` });
  objects.push({ id: 3, body: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>' });
  objects.push({ id: 4 + pages.length * 2, body: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>' });
  pages.forEach((pageRows, i) => {
    const pageId = 4 + i * 2;
    const contentId = pageId + 1;
    const stream = contentOf(pageRows, i);
    objects.push({
      id: pageId,
      body: `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 3 0 R /F2 ${4 + pages.length * 2} 0 R >> >> /Contents ${contentId} 0 R >>`,
    });
    objects.push({ id: contentId, stream });
  });

  objects.sort((a, b) => a.id - b.id);

  let pdf = '%PDF-1.4\n';
  const offsets = {};
  for (const obj of objects) {
    offsets[obj.id] = Buffer.byteLength(pdf, 'latin1');
    if (obj.stream !== undefined) {
      const buf = Buffer.from(obj.stream, 'latin1');
      pdf += `${obj.id} 0 obj\n<< /Length ${buf.length} >>\nstream\n`;
      pdf += `${obj.stream}\nendstream\nendobj\n`;
    } else {
      pdf += `${obj.id} 0 obj\n${obj.body}\nendobj\n`;
    }
  }
  const xrefOffset = Buffer.byteLength(pdf, 'latin1');
  const maxId = objects.reduce((m, o) => Math.max(m, o.id), 0);
  pdf += `xref\n0 ${maxId + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= maxId; i += 1) {
    const off = offsets[i];
    pdf += off === undefined
      ? '0000000000 65535 f \n'
      : `${String(off).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${maxId + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return Buffer.from(pdf, 'latin1');
}
