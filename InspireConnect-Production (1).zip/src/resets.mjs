/**
 * Password reset links.
 *
 * Instead of an administrator inventing a password (which would then be shared
 * insecurely), a single-use, expiring link is generated. Only the SHA-256 hash
 * of the token is stored.
 */
import { config } from './config.mjs';
import { get, run, lastId } from './db.mjs';
import { addHours, nowSQL, randomToken, sha256 } from './util.mjs';

const DEFAULT_TTL_HOURS = 24;

export function createPasswordReset(userId, actor, { ttlHours = DEFAULT_TTL_HOURS } = {}) {
  const token = randomToken(32);
  const expiresAt = addHours(new Date(), ttlHours);
  // Invalidate any outstanding links for this account.
  run('UPDATE password_resets SET used_at = ? WHERE user_id = ? AND used_at IS NULL', [nowSQL(), userId]);
  const id = lastId(run(
    `INSERT INTO password_resets (user_id, token_hash, created_by, created_at, expires_at)
     VALUES (?, ?, ?, ?, ?)`,
    [userId, sha256(token), actor?.id ?? null, nowSQL(), nowSQL(expiresAt)],
  ));
  return { id, token, expiresAt, url: resetUrl(token) };
}

export function resetUrl(token) {
  const base = (config.baseUrl || '').replace(/\/+$/, '');
  return `${base}/reset/${token}`;
}

export function resetByToken(token) {
  if (!token || typeof token !== 'string' || token.length < 20) return null;
  const row = get('SELECT * FROM password_resets WHERE token_hash = ?', [sha256(token)]);
  if (!row) return null;
  if (row.used_at) return { ...row, status: 'used' };
  if (new Date(String(row.expires_at).replace(' ', 'T')) < new Date()) return { ...row, status: 'expired' };
  return { ...row, status: 'pending' };
}

export function consumeReset(id) {
  run('UPDATE password_resets SET used_at = ? WHERE id = ?', [nowSQL(), id]);
}

export function resetStatusMessage(status) {
  switch (status) {
    case 'used': return 'This password reset link has already been used. Request a new one from your administrator.';
    case 'expired': return 'This password reset link has expired. Ask your administrator to generate a new one.';
    default: return 'This password reset link is not valid.';
  }
}
