/**
 * Administrator routes. Every handler checks permissions server-side; the UI
 * only hides what the role cannot use.
 */
import fs from 'node:fs';
import {
  ACCOUNT_STATUS, AVAILABILITY_KIND, AVAILABILITY_STATE, DEFAULT_SETTINGS, ROLES,
  SESSION_STATUS, SESSION_STATUS_LABELS, SETTINGS_GROUPS, STAFF_ROLES, WEEKDAYS,
} from '../config.mjs';
import {
  AUDIT_ACTIONS, audit, auditList, can, displayName, hashPassword, HttpError,
  isSuperAdmin, permissionsFor, revokeAllSessions,
} from '../auth.mjs';
import {
  all, get, run, getSettings, setSetting, lastId, settingBool,
} from '../db.mjs';
import {
  availabilityOverviewRows, availabilityRow, createAvailability, createSubject, createTuteeRecord,
  createTutorRecord, deleteAvailability, deleteSubject, emailTaken, listSubjects, listTutees, listTutors,
  setUserStatus, setUserSubjects, subjectById, subjectMap, subjectUsage, subjectsForUser,
  updateSubject, updateTuteeProfile, updateTutorProfile, usernameTaken, activeTutees, activeTutors,
  staffUsers, tutorRow, tuteeRow, weeklyGrid, listAvailability, freeIntervalsForDate,
} from '../people.mjs';
import {
  checkConflicts, createAssignment, createSession, dashboardCounts, endAssignment, addSessionNote,
  listAssignments, listSessions, rescheduleSession, sessionDetail, sessionRow, setSessionStatus,
  sessionsCSV, tutorAssignments, tuteeAssignments, updateSession, weekStats, visibleNotes,
} from '../sessions.mjs';
import {
  createInvitation, invitationById, invitationCounts, invitationStatus, listInvitations,
  resendInvitation, revokeInvitation, invitationUrl,
} from '../invitations.mjs';
import { matchTuteesForTutor, matchTutorsForTutee, pendingMatchSuggestions } from '../matching.mjs';
import { buildReport, reportToCSV, reportToPDF, REPORTS } from '../reports.mjs';
import { createPasswordReset } from '../resets.mjs';
import { flushOutbox, outboxList, transportName } from '../mail.mjs';
import {
  listNotifications, markAllRead, markRead, notifyStaff, onAssignmentCreated, onAssignmentEnded,
  onInvitationCreated, onSessionCancelled, onSessionChanged, onSessionNoteAdded, onSessionRescheduled,
  onSessionScheduled, unreadCount,
} from '../notify.mjs';
import {
  addDaysISO, hhmmToMinutes, isValidEmail, minutesToHHMM, normaliseEmail, nowSQL,
  paginate, passwordIssues, todayISO, weekStartISO, toCSV, isISODate,
} from '../util.mjs';
import {
  adminDashboard, adminDetailPage, adminFormPage, adminsPage, assignmentsPage, auditPage,
  availabilityDetailPage, availabilityOverviewPage, invitationNewPage, invitationsPage,
  matchesPage, outboxPage, peopleListPage, personDetailPage, personFormPage, reportsPage,
  sessionFormPage, sessionsListPage, settingsPage, subjectsPage, timetablePage, weeklyPage,
} from '../views/admin.mjs';
import { searchPage, sessionDetailPage, notificationsPage } from '../views/shared.mjs';
import { csvDownload, ensureCan, filters, pdfDownload, respond, setFormState, todayStamp } from './helpers.mjs';
import { config } from '../config.mjs';

const perPage = (ctx) => Math.min(100, Math.max(5, ctx.qInt('perPage', 20)));

function personStats(userId, role) {
  const column = role === ROLES.TUTOR ? 'tutor_id' : 'tutee_id';
  const rows = all(
    `SELECT status, COUNT(*) AS c, COALESCE(SUM(end_min - start_min), 0) AS m FROM sessions WHERE ${column} = ? GROUP BY status`,
    [userId],
  );
  const by = Object.fromEntries(rows.map((r) => [r.status, r]));
  const count = (status) => Number(by[status]?.c || 0);
  const minutes = Number(by.completed?.m || 0);
  return {
    completedCount: count('completed'),
    cancelledCount: count('cancelled'),
    missedCount: count('missed'),
    upcomingCount: count('scheduled') + count('confirmed') + count('running'),
    totalMinutes: minutes,
    duplicateSubjects: [],
  };
}

function tutorDetailData(ctx, id) {
  const person = tutorRow(id);
  if (!person) return null;
  const availability = weeklyGrid(id);
  const assignments = tutorAssignments(id);
  const upcoming = listSessions({ tutorId: id, from: todayISO(), limit: 10, sort: 'date' }).rows
    .filter((s) => ['scheduled', 'confirmed', 'running'].includes(s.status));
  const history = listSessions({ tutorId: id, to: todayISO(), limit: 10, sort: 'date', dir: 'desc' }).rows;
  return {
    person,
    subjects: { teaches: subjectsForUser(id, 'teach'), needs: [] },
    availabilityDays: availability.days,
    assignments,
    upcoming,
    history,
    stats: personStats(id, ROLES.TUTOR),
    pageInfo: paginate(history.length, 1, 10),
  };
}

function tuteeDetailData(ctx, id) {
  const person = tuteeRow(id);
  if (!person) return null;
  const availability = weeklyGrid(id);
  const assignments = tuteeAssignments(id);
  const upcoming = listSessions({ tuteeId: id, from: todayISO(), limit: 10, sort: 'date' }).rows
    .filter((s) => ['scheduled', 'confirmed', 'running'].includes(s.status));
  const history = listSessions({ tuteeId: id, to: todayISO(), limit: 10, sort: 'date', dir: 'desc' }).rows;
  return {
    person,
    subjects: { teaches: [], needs: subjectsForUser(id, 'need') },
    availabilityDays: availability.days,
    assignments,
    upcoming,
    history,
    stats: personStats(id, ROLES.TUTEE),
    pageInfo: paginate(history.length, 1, 10),
  };
}

export function registerAdminRoutes(router) {
  /* ------------------------------ dashboard ------------------------------ */

  router.get('/admin', (ctx) => {
    ensureCan(ctx.user, 'tutors.view', 'You do not have access to the administrator dashboard.');
    const counts = dashboardCounts();
    return respond(ctx, {
      title: 'Dashboard',
      active: 'dashboard',
      portal: 'admin',
      body: adminDashboard({
        ctx,
        counts,
        pendingMatches: pendingMatchSuggestions({ limit: 5 }),
        todayAgenda: listSessions({ date: todayISO(), limit: 50, sort: 'time' }).rows,
        activity: all('SELECT * FROM audit_log ORDER BY created_at DESC, id DESC LIMIT 8'),
        recentSessions: listSessions({ from: todayISO(), limit: 8, sort: 'date' }).rows,
        permissions: [...permissionsFor(ctx.user.role)],
      }),
    });
  });

  /* -------------------------------- search ------------------------------- */

  router.get('/admin/search', (ctx) => {
    ensureCan(ctx.user, 'tutors.view');
    const q = ctx.q('q', '').trim().slice(0, 80);
    const like = `%${q}%`;
    let results = { tutors: [], tutees: [], sessions: [], subjects: [], invitations: [] };
    if (q) {
      results = {
        tutors: all(
          `SELECT u.id, u.email, u.status, tp.full_name,
                  (SELECT GROUP_CONCAT(sb.name, ', ') FROM user_subjects us JOIN subjects sb ON sb.id = us.subject_id
                    WHERE us.user_id = u.id AND us.kind = 'teach') AS subject_names
             FROM users u LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
            WHERE u.role = 'tutor' AND (tp.full_name LIKE ? OR tp.preferred_name LIKE ? OR u.email LIKE ?) LIMIT 12`,
          [like, like, like],
        ),
        tutees: all(
          `SELECT u.id, u.email, u.status, tp.full_name,
                  (SELECT GROUP_CONCAT(sb.name, ', ') FROM user_subjects us JOIN subjects sb ON sb.id = us.subject_id
                    WHERE us.user_id = u.id AND us.kind = 'need') AS subject_names
             FROM users u LEFT JOIN tutee_profiles tp ON tp.user_id = u.id
            WHERE u.role = 'tutee' AND (tp.full_name LIKE ? OR tp.preferred_name LIKE ? OR u.email LIKE ?) LIMIT 12`,
          [like, like, like],
        ),
        sessions: listSessions({ search: q, limit: 12, sort: 'date', dir: 'desc' }).rows,
        subjects: all('SELECT * FROM subjects WHERE name LIKE ? OR description LIKE ? LIMIT 12', [like, like]),
        invitations: all('SELECT * FROM invitations WHERE email LIKE ? OR full_name LIKE ? LIMIT 12', [like, like])
          .map((i) => ({ ...i, status: invitationStatus(i) })),
      };
    }
    return respond(ctx, {
      title: 'Search',
      active: null,
      portal: 'admin',
      body: searchPage({
        ctx, query: q, results,
        counts: Object.fromEntries(Object.entries(results).map(([k, v]) => [k, v.length])),
      }),
    });
  });

  /* -------------------------------- tutors ------------------------------- */

  const tutorList = (ctx) => {
    ensureCan(ctx.user, 'tutors.view');
    const f = filters(ctx, { search: '', subject: 'all', status: 'all', day: 'all', assigned: 'all', hasAvailability: 'all', sort: 'name', dir: 'asc', page: '1', perPage: String(perPage(ctx)) });
    const per = perPage(ctx);
    const { total, rows } = listTutors({
      search: f.search, subjectId: f.subject, status: f.status,
      availabilityDay: f.day === 'all' ? null : f.day, assigned: f.assigned, hasAvailability: f.hasAvailability,
      sort: f.sort, dir: f.dir, limit: per, offset: (Math.max(1, Number(f.page)) - 1) * per,
    });
    return respond(ctx, {
      title: 'Tutors',
      active: 'tutors',
      portal: 'admin',
      body: peopleListPage({
        ctx, kind: 'tutor', rows, subjects: listSubjects(),
        filters: f,
        pageInfo: paginate(total, f.page, per),
      }),
    });
  };
  router.get('/admin/tutors', tutorList);

  router.get('/admin/tutors/new', (ctx) => {
    ensureCan(ctx.user, 'tutors.manage');
    return respond(ctx, {
      title: 'Add tutor',
      active: 'tutors',
      portal: 'admin',
      body: personFormPage({ ctx, kind: 'tutor', mode: 'create', subjects: listSubjects() }),
    });
  });

  router.post('/admin/tutors', (ctx) => {
    ensureCan(ctx.user, 'tutors.manage');
    const settings = getSettings();
    const values = {
      email: ctx.input('email', '').toLowerCase(),
      full_name: ctx.input('full_name', ''),
      preferred_name: ctx.input('preferred_name', ''),
      phone: ctx.input('phone', ''),
      qualifications: ctx.input('qualifications', ''),
      experience: ctx.input('experience', ''),
      notes: ctx.input('notes', ''),
      max_students: ctx.input('max_students', String(settings.tutor_capacity_default || 12)),
      session_frequency: ctx.input('session_frequency', ''),
      preferred_session_times: ctx.input('preferred_session_times', ''),
      subjects: ctx.list('subjects').map(Number).filter((id) => subjectById(id)),
    };
    const errors = {};
    if (!values.full_name) errors.full_name = 'Full name is required';
    if (!values.email) errors.email = 'Email address is required';
    else if (!isValidEmail(values.email)) errors.email = 'Enter a valid email address';
    else if (emailTaken(values.email)) errors.email = 'An account already exists with this email address';
    const capacity = Number.parseInt(values.max_students, 10);
    if (!Number.isFinite(capacity) || capacity < 1 || capacity > 100) errors.max_students = 'Capacity must be between 1 and 100';
    if (!values.subjects.length) errors.subjects = 'Select at least one subject this tutor teaches';
    if (Object.keys(errors).length) {
      return ctx.redirect('/admin/tutors/new', {
        flash: 'Please correct the highlighted fields.', type: 'danger', errors, values: { ...values, subjects: values.subjects.map(String) },
      });
    }
    const userId = createTutorRecord({ ...values, max_students: capacity }, { createdBy: ctx.user.id, status: ACCOUNT_STATUS.PENDING });
    let url = null;
    const invite = createInvitation({
      role: ROLES.TUTOR, email: normaliseEmail(values.email), fullName: values.full_name,
      subjectIds: values.subjects, note: 'Created by administrator',
    }, { id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role });
    url = invitationUrl(invite.token, ctx.baseOrigin);
    onInvitationCreated(invite.invitation, { label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.TUTOR_CREATED, {
      summary: `Created tutor ${values.full_name} (${values.email})`, entityType: 'user', entityId: userId, ip: ctx.ip,
      details: { subjects: values.subjects },
    });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.INVITATION_CREATED, {
      summary: `Invitation created for ${values.email}`, entityType: 'invitation', entityId: invite.invitation.id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/tutors/${userId}`, {
      flash: 'Tutor record created. Send the secure invitation link below so they can set their own password.',
      type: 'success',
      values: { invitation_link: url },
    });
  });

  router.get('/admin/tutors/:id', (ctx) => {
    ensureCan(ctx.user, 'tutors.view');
    const data = tutorDetailData(ctx, Number(ctx.params.id));
    if (!data) throw new HttpError(404, 'That tutor record could not be found.');
    return respond(ctx, {
      title: data.person.full_name || data.person.email,
      active: 'tutors',
      portal: 'admin',
      body: personDetailPage({
        ctx, kind: 'tutor', ...data,
        sessionsParams: {},
        resetLink: ctx.flash?.values?.reset_link || null,
        invitationLink: ctx.flash?.values?.invitation_link || null,
      }),
    });
  });

  router.get('/admin/tutors/:id/edit', (ctx) => {
    ensureCan(ctx.user, 'tutors.manage');
    const person = tutorRow(Number(ctx.params.id));
    if (!person) throw new HttpError(404, 'That tutor record could not be found.');
    return respond(ctx, {
      title: `Edit ${person.full_name || person.email}`,
      active: 'tutors',
      portal: 'admin',
      body: personFormPage({
        ctx, kind: 'tutor', mode: 'edit', person: { ...person, subjects: subjectsForUser(person.id, 'teach') },
        subjects: listSubjects(),
      }),
    });
  });

  router.post('/admin/tutors/:id', (ctx) => {
    ensureCan(ctx.user, 'tutors.manage');
    const id = Number(ctx.params.id);
    const person = tutorRow(id);
    if (!person) throw new HttpError(404, 'That tutor record could not be found.');
    const values = {
      full_name: ctx.input('full_name', ''), preferred_name: ctx.input('preferred_name', ''),
      phone: ctx.input('phone', ''), qualifications: ctx.input('qualifications', ''),
      experience: ctx.input('experience', ''), notes: ctx.input('notes', ''),
      max_students: ctx.input('max_students', person.max_students),
      session_frequency: ctx.input('session_frequency', ''), preferred_session_times: ctx.input('preferred_session_times', ''),
      subjects: ctx.list('subjects').map(Number).filter((sid) => subjectById(sid)),
    };
    const errors = {};
    if (!values.full_name) errors.full_name = 'Full name is required';
    const capacity = Number.parseInt(values.max_students, 10);
    if (!Number.isFinite(capacity) || capacity < 1 || capacity > 100) errors.max_students = 'Capacity must be between 1 and 100';
    if (!values.subjects.length) errors.subjects = 'Select at least one subject this tutor teaches';
    if (Object.keys(errors).length) {
      return ctx.redirect(`/admin/tutors/${id}/edit`, {
        flash: 'Please correct the highlighted fields.', type: 'danger', errors, values: { ...values, subjects: values.subjects.map(String) },
      });
    }
    updateTutorProfile(id, { ...values, max_students: capacity });
    setUserSubjects(id, 'teach', values.subjects);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.TUTOR_EDITED, {
      summary: `Updated tutor ${values.full_name}`, entityType: 'user', entityId: id, ip: ctx.ip,
      details: { subjects: values.subjects },
    });
    return ctx.redirect(`/admin/tutors/${id}`, { flash: 'Tutor record updated.', type: 'success' });
  });

  const setPersonStatus = (ctx, role, action) => {
    const id = Number(ctx.params.id);
    const status = ctx.input('status', '');
    if (![ACCOUNT_STATUS.ACTIVE, ACCOUNT_STATUS.PENDING, ACCOUNT_STATUS.DISABLED].includes(status)) {
      throw new HttpError(400, 'Choose a valid account status.');
    }
    const reason = ctx.input('reason', '').slice(0, 300);
    setUserStatus(id, status, reason || null);
    if (status !== ACCOUNT_STATUS.ACTIVE) revokeAllSessions(id);
    const person = role === ROLES.TUTOR ? tutorRow(id) : tuteeRow(id);
    const label = person?.full_name || person?.email || `#${id}`;
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, status === ACCOUNT_STATUS.DISABLED ? AUDIT_ACTIONS.ACCOUNT_DISABLED : action, {
      summary: `${status === ACCOUNT_STATUS.DISABLED ? 'Disabled' : 'Enabled'} ${role} account ${label}`,
      entityType: 'user', entityId: id, ip: ctx.ip, details: { status, reason },
    });
    return ctx.redirect(`/admin/${role === ROLES.TUTOR ? 'tutors' : 'tutees'}/${id}`, {
      flash: status === ACCOUNT_STATUS.DISABLED ? 'Account disabled and all sessions revoked.' : 'Account status updated.',
      type: 'success',
    });
  };

  router.post('/admin/tutors/:id/status', (ctx) => {
    ensureCan(ctx.user, 'tutors.manage');
    return setPersonStatus(ctx, ROLES.TUTOR, AUDIT_ACTIONS.TUTOR_STATUS_CHANGED);
  });

  router.post('/admin/tutors/:id/reset-password', (ctx) => {
    ensureCan(ctx.user, 'tutors.manage');
    const id = Number(ctx.params.id);
    const reset = createPasswordReset(id, { id: ctx.user.id, label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.PASSWORD_RESET, {
      summary: `Generated password reset link for tutor #${id}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/tutors/${id}`, {
      flash: 'Password reset link generated (single use, expires in 24 hours).',
      type: 'success',
      values: { reset_link: reset.url },
    });
  });

  /* -------------------------------- tutees ------------------------------- */

  router.get('/admin/tutees', (ctx) => {
    ensureCan(ctx.user, 'tutees.view');
    const f = filters(ctx, { search: '', subject: 'all', status: 'all', day: 'all', assigned: 'all', hasAvailability: 'all', sort: 'name', dir: 'asc', page: '1', perPage: String(perPage(ctx)) });
    const per = perPage(ctx);
    const { total, rows } = listTutees({
      search: f.search, subjectId: f.subject, status: f.status,
      availabilityDay: f.day === 'all' ? null : f.day, assigned: f.assigned, hasAvailability: f.hasAvailability,
      sort: f.sort, dir: f.dir, limit: per, offset: (Math.max(1, Number(f.page)) - 1) * per,
    });
    return respond(ctx, {
      title: 'Tutees',
      active: 'tutees',
      portal: 'admin',
      body: peopleListPage({ ctx, kind: 'tutee', rows, subjects: listSubjects(), filters: f, pageInfo: paginate(total, f.page, per) }),
    });
  });

  router.get('/admin/tutees/new', (ctx) => {
    ensureCan(ctx.user, 'tutees.manage');
    return respond(ctx, {
      title: 'Add tutee',
      active: 'tutees',
      portal: 'admin',
      body: personFormPage({ ctx, kind: 'tutee', mode: 'create', subjects: listSubjects() }),
    });
  });

  router.post('/admin/tutees', (ctx) => {
    ensureCan(ctx.user, 'tutees.manage');
    const values = {
      email: ctx.input('email', '').toLowerCase(),
      full_name: ctx.input('full_name', ''),
      preferred_name: ctx.input('preferred_name', ''),
      phone: ctx.input('phone', ''),
      year_level: ctx.input('year_level', ''),
      guardian_name: ctx.input('guardian_name', ''),
      guardian_contact: ctx.input('guardian_contact', ''),
      notes: ctx.input('notes', ''),
      sessions_per_week: ctx.input('sessions_per_week', '1'),
      preferred_session_times: ctx.input('preferred_session_times', ''),
      subjects: ctx.list('subjects').map(Number).filter((id) => subjectById(id)),
    };
    const errors = {};
    if (!values.full_name) errors.full_name = 'Full name is required';
    if (!values.email) errors.email = 'Email address is required';
    else if (!isValidEmail(values.email)) errors.email = 'Enter a valid email address';
    else if (emailTaken(values.email)) errors.email = 'An account already exists with this email address';
    if (!values.subjects.length) errors.subjects = 'Select at least one subject this tutee needs';
    if (Object.keys(errors).length) {
      return ctx.redirect('/admin/tutees/new', {
        flash: 'Please correct the highlighted fields.', type: 'danger', errors, values: { ...values, subjects: values.subjects.map(String) },
      });
    }
    const userId = createTuteeRecord(values, { createdBy: ctx.user.id, status: ACCOUNT_STATUS.PENDING });
    const invite = createInvitation({
      role: ROLES.TUTEE, email: normaliseEmail(values.email), fullName: values.full_name,
      subjectIds: values.subjects, note: 'Created by administrator',
    }, { id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role });
    onInvitationCreated(invite.invitation, { label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.TUTEE_CREATED, {
      summary: `Created tutee ${values.full_name} (${values.email})`, entityType: 'user', entityId: userId, ip: ctx.ip,
      details: { subjects: values.subjects },
    });
    return ctx.redirect(`/admin/tutees/${userId}`, {
      flash: 'Tutee record created. Send the secure invitation link below so they can set their own password.',
      type: 'success',
      values: { invitation_link: invitationUrl(invite.token, ctx.baseOrigin) },
    });
  });

  router.get('/admin/tutees/:id', (ctx) => {
    ensureCan(ctx.user, 'tutees.view');
    const data = tuteeDetailData(ctx, Number(ctx.params.id));
    if (!data) throw new HttpError(404, 'That tutee record could not be found.');
    return respond(ctx, {
      title: data.person.full_name || data.person.email,
      active: 'tutees',
      portal: 'admin',
      body: personDetailPage({
        ctx, kind: 'tutee', ...data, sessionsParams: {},
        resetLink: ctx.flash?.values?.reset_link || null,
        invitationLink: ctx.flash?.values?.invitation_link || null,
      }),
    });
  });

  router.get('/admin/tutees/:id/edit', (ctx) => {
    ensureCan(ctx.user, 'tutees.manage');
    const person = tuteeRow(Number(ctx.params.id));
    if (!person) throw new HttpError(404, 'That tutee record could not be found.');
    return respond(ctx, {
      title: `Edit ${person.full_name || person.email}`,
      active: 'tutees',
      portal: 'admin',
      body: personFormPage({
        ctx, kind: 'tutee', mode: 'edit', person: { ...person, subjects: subjectsForUser(person.id, 'need') },
        subjects: listSubjects(),
      }),
    });
  });

  router.post('/admin/tutees/:id', (ctx) => {
    ensureCan(ctx.user, 'tutees.manage');
    const id = Number(ctx.params.id);
    const person = tuteeRow(id);
    if (!person) throw new HttpError(404, 'That tutee record could not be found.');
    const values = {
      full_name: ctx.input('full_name', ''), preferred_name: ctx.input('preferred_name', ''),
      phone: ctx.input('phone', ''), year_level: ctx.input('year_level', ''),
      guardian_name: ctx.input('guardian_name', ''), guardian_contact: ctx.input('guardian_contact', ''),
      notes: ctx.input('notes', ''), sessions_per_week: ctx.input('sessions_per_week', person.sessions_per_week),
      preferred_session_times: ctx.input('preferred_session_times', ''),
      subjects: ctx.list('subjects').map(Number).filter((sid) => subjectById(sid)),
    };
    const errors = {};
    if (!values.full_name) errors.full_name = 'Full name is required';
    if (!values.subjects.length) errors.subjects = 'Select at least one subject this tutee needs';
    if (Object.keys(errors).length) {
      return ctx.redirect(`/admin/tutees/${id}/edit`, {
        flash: 'Please correct the highlighted fields.', type: 'danger', errors, values: { ...values, subjects: values.subjects.map(String) },
      });
    }
    updateTuteeProfile(id, values);
    setUserSubjects(id, 'need', values.subjects);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.TUTEE_EDITED, {
      summary: `Updated tutee ${values.full_name}`, entityType: 'user', entityId: id, ip: ctx.ip,
      details: { subjects: values.subjects },
    });
    return ctx.redirect(`/admin/tutees/${id}`, { flash: 'Tutee record updated.', type: 'success' });
  });

  router.post('/admin/tutees/:id/status', (ctx) => {
    ensureCan(ctx.user, 'tutees.manage');
    return setPersonStatus(ctx, ROLES.TUTEE, AUDIT_ACTIONS.TUTEE_STATUS_CHANGED);
  });

  router.post('/admin/tutees/:id/reset-password', (ctx) => {
    ensureCan(ctx.user, 'tutees.manage');
    const id = Number(ctx.params.id);
    const reset = createPasswordReset(id, { id: ctx.user.id, label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.PASSWORD_RESET, {
      summary: `Generated password reset link for tutee #${id}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/tutees/${id}`, {
      flash: 'Password reset link generated (single use, expires in 24 hours).',
      type: 'success',
      values: { reset_link: reset.url },
    });
  });

  /* ------------------------------- subjects ------------------------------ */

  router.get('/admin/subjects', (ctx) => {
    ensureCan(ctx.user, 'subjects.view');
    return respond(ctx, {
      title: 'Subjects', active: 'subjects', portal: 'admin',
      body: subjectsPage({ ctx, subjects: subjectUsage() }),
    });
  });

  router.post('/admin/subjects', (ctx) => {
    ensureCan(ctx.user, 'subjects.manage');
    const name = ctx.input('name', '');
    const errors = {};
    if (!name) errors.name = 'A subject name is required';
    else if (name.length > 60) errors.name = 'Keep the name under 60 characters';
    else if (get('SELECT id FROM subjects WHERE name = ? COLLATE NOCASE', [name])) errors.name = 'That subject already exists';
    if (Object.keys(errors).length) {
      return ctx.redirect('/admin/subjects', { flash: 'Subject not added.', type: 'danger', errors, values: { name, colour: ctx.input('colour', '#2563eb'), description: ctx.input('description', '') } });
    }
    const subject = createSubject({ name, colour: ctx.input('colour', '#2563eb'), description: ctx.input('description', '') });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SUBJECT_CREATED, {
      summary: `Added subject ${subject.name}`, entityType: 'subject', entityId: subject.id, ip: ctx.ip,
    });
    return ctx.redirect('/admin/subjects', { flash: `Subject “${subject.name}” added.`, type: 'success' });
  });

  router.post('/admin/subjects/:id', (ctx) => {
    ensureCan(ctx.user, 'subjects.manage');
    const id = Number(ctx.params.id);
    const subject = subjectById(id);
    if (!subject) throw new HttpError(404, 'That subject could not be found.');
    const name = ctx.input('name', subject.name);
    const clash = get('SELECT id FROM subjects WHERE name = ? COLLATE NOCASE AND id <> ?', [name, id]);
    if (!name || clash) {
      return ctx.redirect('/admin/subjects', {
        flash: clash ? 'Another subject already uses that name.' : 'A subject name is required.',
        type: 'danger',
      });
    }
    const updated = updateSubject(id, {
      name,
      colour: ctx.input('colour', subject.colour),
      description: ctx.input('description', subject.description || ''),
      active: ctx.bool('active'),
      sort_order: ctx.int('sort_order', subject.sort_order),
    });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SUBJECT_EDITED, {
      summary: `Updated subject ${updated.name} (${updated.active ? 'enabled' : 'disabled'})`, entityType: 'subject', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect('/admin/subjects', { flash: 'Subject updated.', type: 'success' });
  });

  router.post('/admin/subjects/:id/delete', (ctx) => {
    ensureCan(ctx.user, 'subjects.manage');
    const id = Number(ctx.params.id);
    const subject = subjectById(id);
    if (!subject) throw new HttpError(404, 'That subject could not be found.');
    try {
      deleteSubject(id);
    } catch (error) {
      return ctx.redirect('/admin/subjects', { flash: error.message, type: 'danger' });
    }
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SUBJECT_DELETED, {
      summary: `Deleted subject ${subject.name}`, entityType: 'subject', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect('/admin/subjects', { flash: `Subject “${subject.name}” deleted.`, type: 'success' });
  });

  /* ------------------------------ availability --------------------------- */

  router.get('/admin/availability', (ctx) => {
    ensureCan(ctx.user, 'availability.view');
    const f = filters(ctx, { search: '', role: 'all', day: 'all', has: 'all' });
    const weekday = f.day === 'all' ? null : Number(f.day);
    let rows = availabilityOverviewRows({ weekday });
    if (f.role !== 'all') rows = rows.filter((r) => r.kind === f.role);
    if (f.search) {
      const needle = f.search.toLowerCase();
      rows = rows.filter((r) => `${r.full_name || ''} ${r.email || ''}`.toLowerCase().includes(needle));
    }
    if (f.has === 'yes') rows = rows.filter((r) => r.slots > 0);
    if (f.has === 'no') rows = rows.filter((r) => !r.slots);
    const weekdayStats = Object.fromEntries(WEEKDAYS.map((d) => {
      const dayRows = availabilityOverviewRows({ weekday: d.n });
      return [d.n, {
        tutors: dayRows.filter((r) => r.kind === 'tutor' && r.slots > 0).length,
        tutees: dayRows.filter((r) => r.kind === 'tutee' && r.slots > 0).length,
      }];
    }));
    return respond(ctx, {
      title: 'Availability', active: 'availability', portal: 'admin',
      body: availabilityOverviewPage({ ctx, rows, filters: f, weekdayStats }),
    });
  });

  router.get('/admin/availability/:id', (ctx) => {
    ensureCan(ctx.user, 'availability.view');
    const id = Number(ctx.params.id);
    const person = get(
      `SELECT u.id, u.role, u.email, u.status, COALESCE(tp.full_name, ep.full_name, u.email) AS full_name
         FROM users u LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
         LEFT JOIN tutee_profiles ep ON ep.user_id = u.id WHERE u.id = ?`,
      [id],
    );
    if (!person) throw new HttpError(404, 'That person could not be found.');
    const grid = weeklyGrid(id);
    const dated = listAvailability(id).filter((r) => r.kind === AVAILABILITY_KIND.DATE && r.date >= todayISO());
    return respond(ctx, {
      title: `Availability — ${person.full_name}`,
      active: 'availability',
      portal: 'admin',
      body: availabilityDetailPage({
        ctx, person, days: grid.days, extraDateRows: dated,
        canManage: can(ctx.user, 'availability.manage'),
      }),
    });
  });

  const requireAvailabilityManage = (ctx) => ensureCan(ctx.user, 'availability.manage');
  const ensurePerson = (id) => {
    const person = get('SELECT id, role FROM users WHERE id = ?', [id]);
    if (!person) throw new HttpError(404, 'That person could not be found.');
    return person;
  };

  router.post('/admin/availability/:id/weekly', (ctx) => {
    requireAvailabilityManage(ctx);
    const id = Number(ctx.params.id);
    const person = ensurePerson(id);
    const weekday = ctx.int('weekday', null);
    const start = hhmmToMinutes(ctx.input('start', ''));
    const end = hhmmToMinutes(ctx.input('end', ''));
    const errors = {};
    if (!weekday || weekday < 1 || weekday > 7) errors.weekday = 'Choose a day';
    if (start === null) errors.start = 'Choose a start time';
    if (end === null) errors.end = 'Choose an end time';
    if (start !== null && end !== null && end <= start) errors.end = 'End time must be after the start time';
    const from = ctx.input('effective_from', '');
    const to = ctx.input('effective_to', '');
    if (from && !isISODate(from)) errors.effective_from = 'Enter a valid date';
    if (to && !isISODate(to)) errors.effective_to = 'Enter a valid date';
    if (from && to && to < from) errors.effective_to = 'End date must be on or after the start date';
    if (Object.keys(errors).length) {
      return ctx.redirect(`/admin/availability/${id}`, { flash: 'Availability not added.', type: 'danger', errors });
    }
    createAvailability({
      userId: id,
      kind: AVAILABILITY_KIND.WEEKLY,
      weekday,
      start_min: start,
      end_min: end,
      state: ctx.input('state', AVAILABILITY_STATE.AVAILABLE),
      effective_from: from || null,
      effective_to: to || null,
      note: ctx.input('note', '').slice(0, 200) || null,
      createdBy: ctx.user.id,
    });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.AVAILABILITY_UPDATED, {
      summary: `Added weekly availability for ${person.role} #${id} (${WEEKDAYS.find((d) => d.n === weekday)?.name} ${minutesToHHMM(start)}–${minutesToHHMM(end)})`,
      entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/availability/${id}`, { flash: 'Availability added.', type: 'success' });
  });

  router.post('/admin/availability/:id/date', (ctx) => {
    requireAvailabilityManage(ctx);
    const id = Number(ctx.params.id);
    const person = ensurePerson(id);
    const date = ctx.input('date', '');
    const start = hhmmToMinutes(ctx.input('start', ''));
    const end = hhmmToMinutes(ctx.input('end', ''));
    const errors = {};
    if (!isISODate(date)) errors.date = 'Choose a valid date';
    if (start === null) errors.start = 'Choose a start time';
    if (end === null) errors.end = 'Choose an end time';
    if (start !== null && end !== null && end <= start) errors.end = 'End time must be after the start time';
    if (Object.keys(errors).length) {
      return ctx.redirect(`/admin/availability/${id}`, { flash: 'Availability not added.', type: 'danger', errors });
    }
    createAvailability({
      userId: id,
      kind: AVAILABILITY_KIND.DATE,
      date,
      start_min: start,
      end_min: end,
      state: ctx.input('state', AVAILABILITY_STATE.AVAILABLE),
      note: ctx.input('note', '').slice(0, 200) || null,
      createdBy: ctx.user.id,
    });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.AVAILABILITY_UPDATED, {
      summary: `Added date-specific availability for ${person.role} #${id} on ${date}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/availability/${id}`, { flash: 'Date-specific availability added.', type: 'success' });
  });

  router.post('/admin/availability/:id/:slotId/delete', (ctx) => {
    requireAvailabilityManage(ctx);
    const id = Number(ctx.params.id);
    const slot = availabilityRow(Number(ctx.params.slotId));
    if (!slot || Number(slot.user_id) !== id) throw new HttpError(404, 'That availability slot could not be found.');
    deleteAvailability(slot.id);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.AVAILABILITY_UPDATED, {
      summary: `Removed availability row #${slot.id} for user #${id}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/availability/${id}`, { flash: 'Availability removed.', type: 'success' });
  });

  /* -------------------------------- matches ------------------------------ */

  router.get('/admin/matches', (ctx) => {
    ensureCan(ctx.user, 'matches.view');
    const tuteeId = ctx.qInt('tutee', null);
    const tutorId = ctx.qInt('tutor', null);
    const subjectId = ctx.qInt('subject', null);
    const days = Math.min(28, Math.max(7, ctx.qInt('days', 14)));
    const waiting = listTutees({ assigned: 'unassigned', status: ACCOUNT_STATUS.ACTIVE, limit: 100 }).rows;
    const tutors = activeTutors();
    const tutees = activeTutees();
    let result = null;
    let mode = 'tutor';
    if (tutorId && !tuteeId) {
      mode = 'tutee';
      result = matchTuteesForTutor(tutorId, { days, subjectId });
    } else if (tuteeId) {
      result = matchTutorsForTutee(tuteeId, { days, subjectId });
    }
    return respond(ctx, {
      title: 'Matching', active: 'matches', portal: 'admin',
      body: matchesPage({
        ctx, tutees, tutors, waiting,
        selectedTutee: tuteeId ? tuteeRow(tuteeId) : null,
        selectedTutor: tutorId ? tutorRow(tutorId) : null,
        result, mode, subjectId, days,
      }),
    });
  });

  /* ------------------------------ assignments ---------------------------- */

  router.get('/admin/assignments', (ctx) => {
    ensureCan(ctx.user, 'assignments.manage');
    const f = filters(ctx, { search: '', status: 'all', subject: 'all', page: '1' });
    const per = perPage(ctx);
    const list = listAssignments({
      search: f.search, status: f.status, subjectId: f.subject,
      limit: per, offset: (Math.max(1, Number(f.page)) - 1) * per,
    });
    return respond(ctx, {
      title: 'Assignments', active: 'assignments', portal: 'admin',
      body: assignmentsPage({
        ctx, list, filters: f, pageInfo: paginate(list.total, f.page, per),
        tutors: activeTutors(), tutees: activeTutees(), subjects: listSubjects(),
      }),
    });
  });

  router.post('/admin/assignments', (ctx) => {
    ensureCan(ctx.user, 'assignments.manage');
    const tutorId = ctx.int('tutor_id', null);
    const tuteeId = ctx.int('tutee_id', null);
    const subjectId = ctx.int('subject_id', null);
    const redirectTo = ctx.input('redirect_to', '').startsWith('/') ? ctx.input('redirect_to', '') : '/admin/assignments';
    try {
      const assignment = createAssignment({ tutorId, tuteeId, subjectId, notes: ctx.input('notes', '') }, { id: ctx.user.id, label: displayName(ctx.user) });
      onAssignmentCreated(assignment, { label: displayName(ctx.user) });
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.ASSIGNMENT_CREATED, {
        summary: `Assigned ${assignment.tutor_name} to ${assignment.tutee_name} for ${assignment.subject_name}`,
        entityType: 'assignment', entityId: assignment.id, ip: ctx.ip,
      });
      return ctx.redirect(redirectTo.startsWith('/admin/assignments') ? '/admin/assignments' : redirectTo, {
        flash: `${assignment.tutor_name} assigned to ${assignment.tutee_name} for ${assignment.subject_name}.`,
        type: 'success',
      });
    } catch (error) {
      return ctx.redirect(redirectTo, { flash: error.message, type: 'danger' });
    }
  });

  router.post('/admin/assignments/:id/end', (ctx) => {
    ensureCan(ctx.user, 'assignments.manage');
    const id = Number(ctx.params.id);
    const reason = ctx.input('reason', '').slice(0, 300) || null;
    const assignment = endAssignment(id, { id: ctx.user.id }, reason);
    onAssignmentEnded(assignment, { label: displayName(ctx.user) }, reason);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.ASSIGNMENT_ENDED, {
      summary: `Ended assignment ${assignment.tutor_name} ↔ ${assignment.tutee_name} (${assignment.subject_name})`,
      entityType: 'assignment', entityId: id, ip: ctx.ip, details: { reason },
    });
    return ctx.redirect('/admin/assignments', { flash: 'Assignment ended. Session history is unchanged.', type: 'success' });
  });

  /* -------------------------------- sessions ----------------------------- */

  const sessionFilters = (ctx) => {
    const f = filters(ctx, {
      search: '', from: '', to: '', subject: 'all', tutor: 'all', tutee: 'all', status: 'all',
      mode: 'all', sort: 'date', dir: 'desc', page: '1',
    });
    const query = {
      search: f.search || null,
      from: isISODate(f.from) ? f.from : null,
      to: isISODate(f.to) ? f.to : null,
      subjectId: f.subject,
      tutorId: f.tutor === 'all' ? null : Number(f.tutor),
      tuteeId: f.tutee === 'all' ? null : Number(f.tutee),
      status: f.status,
      mode: f.mode,
      sort: f.sort,
      dir: f.dir,
    };
    return { f, query };
  };

  router.get('/admin/sessions', (ctx) => {
    ensureCan(ctx.user, 'sessions.view');
    const { f, query } = sessionFilters(ctx);
    const per = perPage(ctx);
    const { total, rows } = listSessions({ ...query, limit: per, offset: (Math.max(1, Number(f.page)) - 1) * per });
    return respond(ctx, {
      title: 'Sessions', active: 'sessions', portal: 'admin',
      body: sessionsListPage({
        ctx, rows, pageInfo: paginate(total, f.page, per), filters: f,
        subjects: listSubjects(), tutors: activeTutors(), tutees: activeTutees(),
      }),
    });
  });

  router.get('/admin/sessions/export', (ctx) => {
    ensureCan(ctx.user, 'sessions.view');
    const { query } = sessionFilters(ctx);
    const rows = listSessions({ ...query, limit: 1000 }).rows;
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.REPORT_EXPORTED, {
      summary: `Exported ${rows.length} sessions to CSV`, ip: ctx.ip,
    });
    return csvDownload(ctx, `sessions-${todayStamp()}.csv`, sessionsCSV(rows));
  });

  router.get('/admin/sessions/new', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const settings = getSettings();
    const prefill = {
      tutor_id: ctx.qInt('tutor', ''),
      tutee_id: ctx.qInt('tutee', ''),
      subject_id: ctx.qInt('subject', ''),
      date: isISODate(ctx.q('date', '')) ? ctx.q('date', '') : todayISO(),
      start: ctx.q('start', settings.availability_day_start),
      end: ctx.q('end', minutesToHHMM((hhmmToMinutes(ctx.q('start', settings.availability_day_start)) ?? 540) + Number(settings.session_duration_default || 60))),
    };
    return respond(ctx, {
      title: 'Schedule session', active: 'sessions', portal: 'admin',
      body: sessionFormPage({
        ctx, mode: 'create', subjects: listSubjects(), tutors: activeTutors(), tutees: activeTutees(),
        values: prefill, errors: {},
      }),
    });
  });

  const persistSession = (ctx, { mode, session = null }) => {
    const tutorId = ctx.int('tutor_id', null);
    const tuteeId = ctx.int('tutee_id', null);
    const subjectId = ctx.int('subject_id', null);
    const date = ctx.input('date', '');
    const start = hhmmToMinutes(ctx.input('start', ''));
    const end = hhmmToMinutes(ctx.input('end', ''));
    const force = ctx.bool('force');
    const errors = {};
    if (!tutorId) errors.tutor_id = 'Choose a tutor';
    else if (!tutorRow(tutorId)) errors.tutor_id = 'That tutor could not be found';
    if (!tuteeId) errors.tutee_id = 'Choose a tutee';
    else if (!tuteeRow(tuteeId)) errors.tutee_id = 'That tutee could not be found';
    if (!subjectId || !subjectById(subjectId)) errors.subject_id = 'Choose a subject';
    if (!isISODate(date)) errors.date = 'Choose a valid date';
    if (start === null) errors.start = 'Enter a valid start time';
    if (end === null) errors.end = 'Enter a valid end time';
    if (start !== null && end !== null && end <= start) errors.end = 'End time must be after the start time';

    const values = {
      tutor_id: tutorId, tutee_id: tuteeId, subject_id: subjectId, date,
      start: ctx.input('start', ''), end: ctx.input('end', ''), mode: ctx.input('mode', 'in_person'),
      location: ctx.input('location', ''), notes: ctx.input('notes', ''), repeat_weeks: ctx.input('repeat_weeks', '1'),
    };

    const conflicts = Object.keys(errors).length ? null : checkConflicts({
      tutorId, tuteeId, subjectId, date, startMin: start, endMin: end,
      excludeSessionId: mode === 'edit' ? session.id : null,
    });
    if (Object.keys(errors).length || (conflicts.errors.length && !force)) {
      // Surface the validation errors and typed values on the re-rendered form.
      setFormState(ctx, { errors, values });
      return respond(ctx, {
        title: mode === 'edit' ? `Edit session #${session.id}` : 'Schedule session',
        active: 'sessions',
        portal: 'admin',
        body: sessionFormPage({
          ctx, mode, subjects: listSubjects(), tutors: activeTutors(), tutees: activeTutees(),
          session, values, errors, conflicts,
        }),
      });
    }

    if (mode === 'create') {
      const result = createSession(
        {
          tutorId, tuteeId, subjectId, date, startMin: start, endMin: end,
          mode: values.mode, location: values.location, meetingLink: values.location,
          notes: values.notes,
        },
        { id: ctx.user.id, label: displayName(ctx.user) },
        { force, repeatWeeks: ctx.int('repeat_weeks', 1) },
      );
      if (!result.created.length) {
        return ctx.redirect('/admin/sessions/new', { flash: 'No sessions could be created because every occurrence clashed.', type: 'danger' });
      }
      for (const created of result.created) onSessionScheduled(created, { label: displayName(ctx.user) });
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_CREATED, {
        summary: `Scheduled ${result.created.length} ${result.created[0].subject_name} session(s) for ${result.created[0].tutor_name || ''} with ${result.created[0].tutee_name || ''}`,
        entityType: 'session', entityId: result.created[0].id, ip: ctx.ip,
        details: { dates: result.created.map((s) => s.date), warnings: result.warnings.map((w) => w.message) },
      });
      const extra = result.skipped.length ? ` ${result.skipped.length} occurrence(s) were skipped due to clashes.` : '';
      return ctx.redirect(`/admin/sessions/${result.created[0].id}`, {
        flash: `${result.created.length} session${result.created.length === 1 ? '' : 's'} scheduled.${extra}`,
        type: result.skipped.length ? 'warning' : 'success',
      });
    }

    const updated = updateSession(session.id, {
      tutorId, tuteeId, subjectId, date, startMin: start, endMin: end,
      mode: values.mode, location: values.location, meetingLink: values.location, notes: values.notes,
    }, { id: ctx.user.id, label: displayName(ctx.user) });
    onSessionChanged(updated.session, { label: displayName(ctx.user) }, ctx.input('change_reason', '').slice(0, 200) || 'Details updated.');
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_CHANGED, {
      summary: `Updated session #${session.id}`, entityType: 'session', entityId: session.id, ip: ctx.ip,
      details: { reason: ctx.input('change_reason', '') },
    });
    return ctx.redirect(`/admin/sessions/${session.id}`, { flash: 'Session updated and participants notified.', type: 'success' });
  };

  router.post('/admin/sessions', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    return persistSession(ctx, { mode: 'create' });
  });

  router.get('/admin/sessions/:id/edit', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const session = sessionRow(Number(ctx.params.id));
    if (!session) throw new HttpError(404, 'That session could not be found.');
    return respond(ctx, {
      title: `Edit session #${session.id}`, active: 'sessions', portal: 'admin',
      body: sessionFormPage({
        ctx, mode: 'edit', subjects: listSubjects(), tutors: activeTutors(), tutees: activeTutees(),
        session, values: {}, errors: {},
      }),
    });
  });

  router.post('/admin/sessions/:id', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const session = sessionRow(Number(ctx.params.id));
    if (!session) throw new HttpError(404, 'That session could not be found.');
    return persistSession(ctx, { mode: 'edit', session });
  });

  router.get('/admin/sessions/:id', (ctx) => {
    ensureCan(ctx.user, 'sessions.view');
    const detail = sessionDetail(Number(ctx.params.id));
    if (!detail) throw new HttpError(404, 'That session could not be found.');
    const warnings = detail.session.status === SESSION_STATUS.CANCELLED
      ? []
      : checkConflicts({
          tutorId: detail.session.tutor_id, tuteeId: detail.session.tutee_id, subjectId: detail.session.subject_id,
          date: detail.session.date, startMin: detail.session.start_min, endMin: detail.session.end_min,
          excludeSessionId: detail.session.id,
        }).warnings.map((w) => w.message);
    return respond(ctx, {
      title: `Session #${detail.session.id}`, active: 'sessions', portal: 'admin',
      body: sessionDetailPage({
        ctx, detail, portal: 'admin', actionBase: '/admin/sessions', backHref: '/admin/sessions',
        canManage: can(ctx.user, 'sessions.manage'), canStatus: true, canNote: can(ctx.user, 'sessions.manage'),
        warnings,
      }),
    });
  });

  router.post('/admin/sessions/:id/status', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const id = Number(ctx.params.id);
    const status = ctx.input('status', '');
    const reason = ctx.input('reason', '').slice(0, 300) || null;
    // Status transitions are guarded: an out-of-order change (for example
    // putting a completed session back to running) is refused unless a Super
    // Admin explicitly ticks the override box.
    const override = ctx.bool('override') && isSuperAdmin(ctx.user);
    try {
      const session = setSessionStatus(id, status, { id: ctx.user.id, label: displayName(ctx.user) }, { reason, canOverride: override });
      if (status === SESSION_STATUS.CANCELLED) onSessionCancelled(session, { label: displayName(ctx.user) }, reason);
      else onSessionChanged(session, { label: displayName(ctx.user) }, `Status changed to ${SESSION_STATUS_LABELS[status] || status}.`);
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, status === SESSION_STATUS.CANCELLED ? AUDIT_ACTIONS.SESSION_CANCELLED : AUDIT_ACTIONS.SESSION_STATUS_CHANGED, {
        summary: `Session #${id} marked ${SESSION_STATUS_LABELS[status] || status}`, entityType: 'session', entityId: id, ip: ctx.ip, details: { reason },
      });
      return ctx.redirect(`/admin/sessions/${id}`, { flash: `Session marked ${SESSION_STATUS_LABELS[status] || status}.`, type: 'success' });
    } catch (error) {
      return ctx.redirect(`/admin/sessions/${id}`, { flash: error.message, type: 'danger' });
    }
  });

  router.post('/admin/sessions/:id/cancel', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const id = Number(ctx.params.id);
    const reason = ctx.input('reason', '').slice(0, 300) || 'Cancelled by administrator';
    const session = setSessionStatus(id, SESSION_STATUS.CANCELLED, { id: ctx.user.id, label: displayName(ctx.user) }, { reason });
    onSessionCancelled(session, { label: displayName(ctx.user) }, reason);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_CANCELLED, {
      summary: `Cancelled session #${id}`, entityType: 'session', entityId: id, ip: ctx.ip, details: { reason },
    });
    return ctx.redirect(`/admin/sessions/${id}`, { flash: 'Session cancelled and participants notified.', type: 'success' });
  });

  router.post('/admin/sessions/:id/reschedule', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const id = Number(ctx.params.id);
    const date = ctx.input('date', '');
    const start = hhmmToMinutes(ctx.input('start', ''));
    const end = hhmmToMinutes(ctx.input('end', ''));
    const reason = ctx.input('reason', '').slice(0, 300) || null;
    if (!isISODate(date) || start === null || end === null || end <= start) {
      return ctx.redirect(`/admin/sessions/${id}`, { flash: 'Enter a valid new date and time window.', type: 'danger' });
    }
    try {
      const original = sessionRow(id);
      const { session } = rescheduleSession(id, { date, startMin: start, endMin: end, reason }, { id: ctx.user.id, label: displayName(ctx.user) });
      onSessionRescheduled(original, session, { label: displayName(ctx.user) }, reason);
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_RESCHEDULED, {
        summary: `Rescheduled session #${id} to ${date} ${minutesToHHMM(start)}–${minutesToHHMM(end)}`,
        entityType: 'session', entityId: id, ip: ctx.ip, details: { reason, newSession: session.id },
      });
      return ctx.redirect(`/admin/sessions/${session.id}`, { flash: 'Session rescheduled. The original remains in the history.', type: 'success' });
    } catch (error) {
      return ctx.redirect(`/admin/sessions/${id}`, { flash: error.message, type: 'danger' });
    }
  });

  router.post('/admin/sessions/:id/notes', (ctx) => {
    ensureCan(ctx.user, 'sessions.manage');
    const id = Number(ctx.params.id);
    const session = sessionRow(id);
    if (!session) throw new HttpError(404, 'That session could not be found.');
    const body = ctx.input('body', '').slice(0, 4000);
    if (!body) return ctx.redirect(`/admin/sessions/${id}`, { flash: 'Write something before saving the note.', type: 'danger' });
    addSessionNote(id, {
      category: ctx.input('category', 'general'),
      visibility: ctx.input('visibility', 'all'),
      body,
    }, { id: ctx.user.id });
    onSessionNoteAdded(session, { id: ctx.user.id, label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_NOTE_ADDED, {
      summary: `Added a ${ctx.input('category', 'general')} note to session #${id}`, entityType: 'session', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/sessions/${id}#add-note`, { flash: 'Session note saved.', type: 'success' });
  });

  /* ------------------------------- timetable ----------------------------- */

  const timetableFilters = (ctx) => filters(ctx, { subject: 'all', tutor: 'all', tutee: 'all', status: 'all' });

  const timetableSessions = (ctx, view, date) => {
    const f = timetableFilters(ctx);
    const from = view === 'month' ? addDaysISO(`${date.slice(0, 7)}-01`, -7) : view === 'week' ? weekStartISO(date) : date;
    const to = view === 'month' ? addDaysISO(`${date.slice(0, 7)}-01`, 45) : addDaysISO(from, view === 'week' ? 6 : view === 'month' ? 7 : 0);
    const { rows } = listSessions({
      from, to, limit: 500, sort: 'date',
      subjectId: f.subject, status: f.status,
      tutorId: f.tutor === 'all' ? null : Number(f.tutor),
      tuteeId: f.tutee === 'all' ? null : Number(f.tutee),
    });
    return { sessions: rows, filters: f };
  };

  router.get('/admin/timetable', (ctx) => {
    ensureCan(ctx.user, 'timetable.view');
    const view = ['day', 'week', 'month'].includes(ctx.q('view', 'week')) ? ctx.q('view', 'week') : 'week';
    const date = isISODate(ctx.q('date', '')) ? ctx.q('date', '') : todayISO();
    const { sessions, filters: f } = timetableSessions(ctx, view, date);
    if (ctx.q('export', '') === 'csv') {
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.REPORT_EXPORTED, {
        summary: `Exported timetable (${view}) to CSV`, ip: ctx.ip,
      });
      return csvDownload(ctx, `timetable-${date}.csv`, sessionsCSV(sessions));
    }
    return respond(ctx, {
      title: 'Timetable', active: 'timetable', portal: 'admin',
      body: timetablePage({
        ctx, view, date, sessions, filters: f,
        tutors: activeTutors(), tutees: activeTutees(), subjects: listSubjects(),
        counts: {
          total: sessions.length,
          upcoming: sessions.filter((s) => ['scheduled', 'confirmed'].includes(s.status)).length,
          running: sessions.filter((s) => s.status === 'running').length,
        },
      }),
    });
  });

  /* -------------------------------- weekly ------------------------------- */

  const weeklyStats = (ctx) => {
    const weekParam = ctx.q('week', '');
    const week = isISODate(weekParam) ? weekStartISO(weekParam) : weekStartISO();
    const stats = weekStats(week);
    return { week, stats };
  };

  router.get('/admin/weekly', (ctx) => {
    ensureCan(ctx.user, 'sessions.view');
    const { week, stats } = weeklyStats(ctx);
    return respond(ctx, {
      title: 'Weekly tracking', active: 'weekly', portal: 'admin',
      body: weeklyPage({ ctx, week, stats, filters: {} }),
    });
  });

  router.get('/admin/weekly/export', (ctx) => {
    ensureCan(ctx.user, 'sessions.view');
    const { week, stats } = weeklyStats(ctx);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.REPORT_EXPORTED, {
      summary: `Exported week of ${week} to CSV`, ip: ctx.ip,
    });
    return csvDownload(ctx, `week-${week}.csv`, sessionsCSV(stats.sessions));
  });

  /* ----------------------------- invitations ----------------------------- */

  router.get('/admin/invitations', (ctx) => {
    ensureCan(ctx.user, 'invitations.view');
    const f = filters(ctx, { status: 'all', role: 'all', search: '', page: '1' });
    const per = perPage(ctx);
    const list = listInvitations({
      status: f.status, role: f.role, search: f.search,
      limit: per, offset: (Math.max(1, Number(f.page)) - 1) * per,
    });
    return respond(ctx, {
      title: 'Invitations', active: 'invitations', portal: 'admin',
      body: invitationsPage({
        ctx, list, counts: invitationCounts(), filters: f,
        pageInfo: paginate(list.total, f.page, per), subjects: listSubjects(),
        newLink: null,
      }),
    });
  });

  router.get('/admin/invitations/new', (ctx) => {
    ensureCan(ctx.user, 'invitations.manage');
    const role = [ROLES.TUTOR, ROLES.TUTEE].includes(ctx.q('role', '')) ? ctx.q('role', '') : getSettings().default_invited_role;
    return respond(ctx, {
      title: 'Create invitation', active: 'invitations', portal: 'admin',
      body: invitationNewPage({ ctx, subjects: listSubjects(), defaults: { role } }),
    });
  });

  router.post('/admin/invitations', (ctx) => {
    ensureCan(ctx.user, 'invitations.manage');
    const values = {
      role: ctx.input('role', ROLES.TUTOR),
      email: ctx.input('email', '').toLowerCase(),
      full_name: ctx.input('full_name', ''),
      expires_hours: ctx.input('expires_hours', ''),
      note: ctx.input('note', ''),
      subjects: ctx.list('subjects').map(Number).filter((id) => subjectById(id)),
    };
    const errors = {};
    if (![ROLES.TUTOR, ROLES.TUTEE].includes(values.role)) errors.role = 'Choose tutor or tutee';
    if (!values.email) errors.email = 'An email address is required';
    else if (!isValidEmail(values.email)) errors.email = 'Enter a valid email address';
    if (Object.keys(errors).length) {
      return ctx.redirect('/admin/invitations/new', {
        flash: 'Invitation not created.', type: 'danger', errors, values: { ...values, subjects: values.subjects.map(String) },
      });
    }
    try {
      const { invitation, token, expiresAt } = createInvitation({
        role: values.role,
        email: values.email,
        fullName: values.full_name || null,
        subjectIds: values.subjects,
        note: values.note || null,
        expiresHours: values.expires_hours ? Number(values.expires_hours) : null,
      }, { id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role });
      onInvitationCreated(invitation, { label: displayName(ctx.user) });
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.INVITATION_CREATED, {
        summary: `Invitation created for ${invitation.email} (${invitation.role})`,
        entityType: 'invitation', entityId: invitation.id, ip: ctx.ip,
      });
      const url = invitationUrl(token, ctx.baseOrigin);
      return respond(ctx, {
        title: 'Invitation created', active: 'invitations', portal: 'admin',
        body: invitationsPage({
          ctx,
          list: listInvitations({ limit: 10 }),
          counts: invitationCounts(),
          filters: { status: 'all', role: 'all', search: '', page: '1' },
          pageInfo: paginate(10, 1, 10),
          subjects: listSubjects(),
          newLink: { email: invitation.email, url, expiresAt },
        }),
      });
    } catch (error) {
      return ctx.redirect('/admin/invitations/new', { flash: error.message, type: 'danger', values: { ...values, subjects: values.subjects.map(String) } });
    }
  });

  router.post('/admin/invitations/:id/revoke', (ctx) => {
    ensureCan(ctx.user, 'invitations.manage');
    const id = Number(ctx.params.id);
    const reason = ctx.input('reason', '').slice(0, 200) || null;
    try {
      const invitation = revokeInvitation(id, { id: ctx.user.id }, reason);
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.INVITATION_REVOKED, {
        summary: `Revoked invitation for ${invitation.email}`, entityType: 'invitation', entityId: id, ip: ctx.ip, details: { reason },
      });
      return ctx.redirect('/admin/invitations', { flash: 'Invitation revoked. The link no longer works.', type: 'success' });
    } catch (error) {
      return ctx.redirect('/admin/invitations', { flash: error.message, type: 'danger' });
    }
  });

  router.post('/admin/invitations/:id/resend', (ctx) => {
    ensureCan(ctx.user, 'invitations.manage');
    const id = Number(ctx.params.id);
    try {
      const { token, invitation } = resendInvitation(id, { id: ctx.user.id });
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.INVITATION_RESENT, {
        summary: `Resent invitation for ${invitation.email} (new token issued)`, entityType: 'invitation', entityId: id, ip: ctx.ip,
      });
      return respond(ctx, {
        title: 'Invitation resent', active: 'invitations', portal: 'admin',
        body: invitationsPage({
          ctx,
          list: listInvitations({ limit: 10 }),
          counts: invitationCounts(),
          filters: { status: 'all', role: 'all', search: '', page: '1' },
          pageInfo: paginate(10, 1, 10),
          subjects: listSubjects(),
          newLink: { email: invitation.email, url: invitationUrl(token, ctx.baseOrigin), expiresAt: invitation.expires_at },
        }),
      });
    } catch (error) {
      return ctx.redirect('/admin/invitations', { flash: error.message, type: 'danger' });
    }
  });

  /* ------------------------------ administrators -------------------------- */

  router.get('/admin/admins', (ctx) => {
    ensureCan(ctx.user, 'admins.view');
    return respond(ctx, {
      title: 'Administrators', active: 'admins', portal: 'admin',
      body: adminsPage({
        ctx, admins: staffUsers(), canManage: can(ctx.user, 'admins.manage'),
        activity: all(
          "SELECT a.* FROM audit_log a JOIN users u ON u.id = a.actor_id WHERE u.role IN ('super_admin','admin','scheduler','viewer') ORDER BY a.created_at DESC LIMIT 10",
        ),
      }),
    });
  });

  router.get('/admin/admins/new', (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can create administrators.');
    return respond(ctx, {
      title: 'Add administrator', active: 'admins', portal: 'admin',
      body: adminFormPage({ ctx, mode: 'create', canManage: true }),
    });
  });

  router.post('/admin/admins', async (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can create administrators.');
    const values = {
      username: ctx.input('username', '').toLowerCase(),
      email: ctx.input('email', '').toLowerCase(),
      role: ctx.input('role', ROLES.ADMIN),
      status: ctx.input('status', ACCOUNT_STATUS.ACTIVE),
    };
    const password = String(ctx.field('password', ''));
    const confirm = String(ctx.field('password_confirm', ''));
    const errors = {};
    if (!values.username) errors.username = 'A username is required';
    else if (values.username.length < 3) errors.username = 'Usernames need at least 3 characters';
    else if (usernameTaken(values.username)) errors.username = 'That username is already in use';
    if (!values.email) errors.email = 'An email address is required';
    else if (!isValidEmail(values.email)) errors.email = 'Enter a valid email address';
    else if (emailTaken(values.email)) errors.email = 'An account already exists with this email address';
    if (!STAFF_ROLES.includes(values.role)) errors.role = 'Choose a valid administrator role';
    const issues = passwordIssues(password, Number(getSettings().min_password_length || 10));
    if (issues.length) errors.password = issues.join('. ');
    if (password !== confirm) errors.password_confirm = 'The two passwords do not match';
    if (Object.keys(errors).length) {
      return ctx.redirect('/admin/admins/new', { flash: 'Administrator not created.', type: 'danger', errors, values });
    }
    const hash = await hashPassword(password);
    const id = lastId(run(
      `INSERT INTO users (role, username, email, password_hash, status, must_change_password, created_at, updated_at, password_changed_at)
       VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)`,
      [values.role, values.username, normaliseEmail(values.email), hash, values.status, nowSQL(), nowSQL(), nowSQL()],
    ));
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.ADMIN_CREATED, {
      summary: `Created ${values.role} account ${values.username}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/admins/${id}`, { flash: 'Administrator created. They must change the password at first sign-in.', type: 'success' });
  });

  router.get('/admin/admins/:id', (ctx) => {
    ensureCan(ctx.user, 'admins.view');
    const admin = get('SELECT * FROM users WHERE id = ? AND role IN (?, ?, ?, ?)', [Number(ctx.params.id), ...STAFF_ROLES]);
    if (!admin) throw new HttpError(404, 'That administrator could not be found.');
    const perms = [...permissionsFor(admin.role)];
    return respond(ctx, {
      title: admin.username || admin.email,
      active: 'admins',
      portal: 'admin',
      body: adminDetailPage({
        ctx, admin,
        permissionsList: perms,
        recentActivity: all('SELECT * FROM audit_log WHERE actor_id = ? ORDER BY created_at DESC LIMIT 15', [admin.id]),
        canManage: can(ctx.user, 'admins.manage'),
        resetLink: ctx.flash?.values?.reset_link || null,
      }),
    });
  });

  router.get('/admin/admins/:id/edit', (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can edit administrators.');
    const admin = get('SELECT * FROM users WHERE id = ?', [Number(ctx.params.id)]);
    if (!admin || !STAFF_ROLES.includes(admin.role)) throw new HttpError(404, 'That administrator could not be found.');
    return respond(ctx, {
      title: `Edit ${admin.username || admin.email}`, active: 'admins', portal: 'admin',
      body: adminFormPage({ ctx, mode: 'edit', admin, canManage: true, resetLink: ctx.flash?.values?.reset_link || null }),
    });
  });

  router.post('/admin/admins/:id', async (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can edit administrators.');
    const id = Number(ctx.params.id);
    const admin = get('SELECT * FROM users WHERE id = ?', [id]);
    if (!admin || !STAFF_ROLES.includes(admin.role)) throw new HttpError(404, 'That administrator could not be found.');
    const values = {
      username: ctx.input('username', admin.username || '').toLowerCase(),
      email: ctx.input('email', admin.email).toLowerCase(),
      role: ctx.input('role', admin.role),
      status: ctx.input('status', admin.status),
    };
    const password = String(ctx.field('password', ''));
    const confirm = String(ctx.field('password_confirm', ''));
    const errors = {};
    if (!values.username) errors.username = 'A username is required';
    else if (usernameTaken(values.username, id)) errors.username = 'That username is already in use';
    if (!isValidEmail(values.email)) errors.email = 'Enter a valid email address';
    else if (emailTaken(values.email, id)) errors.email = 'An email address is already in use';
    if (!STAFF_ROLES.includes(values.role)) errors.role = 'Choose a valid administrator role';
    if (permissionProtected(ctx, id, values)) errors.role = 'You cannot remove your own Super Admin role.';
    if (password) {
      const issues = passwordIssues(password, Number(getSettings().min_password_length || 10));
      if (issues.length) errors.password = issues.join('. ');
      if (password !== confirm) errors.password_confirm = 'The two passwords do not match';
    }
    if (Object.keys(errors).length) {
      return ctx.redirect(`/admin/admins/${id}/edit`, { flash: 'Changes not saved.', type: 'danger', errors, values });
    }
    run(
      `UPDATE users SET username = ?, email = ?, role = ?, status = ?, updated_at = ? WHERE id = ?`,
      [values.username, normaliseEmail(values.email), values.role, values.status, nowSQL(), id],
    );
    if (password) {
      run(
        'UPDATE users SET password_hash = ?, must_change_password = 1, password_changed_at = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?',
        [await hashPassword(password), nowSQL(), id],
      );
      revokeAllSessions(id);
    }
    if (values.status !== ACCOUNT_STATUS.ACTIVE) revokeAllSessions(id);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.ADMIN_EDITED, {
      summary: `Updated administrator ${values.username} (${values.role}, ${values.status})`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/admins/${id}`, { flash: 'Administrator updated.', type: 'success' });
  });

  router.post('/admin/admins/:id/status', (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can change administrator status.');
    const id = Number(ctx.params.id);
    if (id === Number(ctx.user.id)) throw new HttpError(400, 'You cannot disable your own account.');
    const status = ctx.input('status', '');
    if (![ACCOUNT_STATUS.ACTIVE, ACCOUNT_STATUS.DISABLED].includes(status)) throw new HttpError(400, 'Choose a valid status.');
    const target = get('SELECT * FROM users WHERE id = ?', [id]);
    if (!target) throw new HttpError(404, 'That administrator could not be found.');
    if (target.role === ROLES.SUPER_ADMIN && status === ACCOUNT_STATUS.DISABLED) {
      const remaining = Number(get("SELECT COUNT(*) AS c FROM users WHERE role = 'super_admin' AND status = 'active' AND id <> ?", [id])?.c || 0);
      if (!remaining) throw new HttpError(400, 'At least one active Super Admin must remain.');
    }
    setUserStatus(id, status, ctx.input('reason', '') || null);
    if (status === ACCOUNT_STATUS.DISABLED) revokeAllSessions(id);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, status === ACCOUNT_STATUS.DISABLED ? AUDIT_ACTIONS.ACCOUNT_DISABLED : AUDIT_ACTIONS.ACCOUNT_ENABLED, {
      summary: `${status === ACCOUNT_STATUS.DISABLED ? 'Disabled' : 'Enabled'} administrator ${target.username || target.email}`,
      entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/admins/${id}`, { flash: 'Administrator status updated.', type: 'success' });
  });

  router.post('/admin/admins/:id/reset-password', (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can reset administrator passwords.');
    const id = Number(ctx.params.id);
    const reset = createPasswordReset(id, { id: ctx.user.id, label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.PASSWORD_RESET, {
      summary: `Generated password reset link for administrator #${id}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/admins/${id}/edit`, {
      flash: 'Password reset link generated (single use, expires in 24 hours).',
      type: 'success',
      values: { reset_link: reset.url },
    });
  });

  router.post('/admin/admins/:id/sessions/revoke', (ctx) => {
    if (!isSuperAdmin(ctx.user)) throw new HttpError(403, 'Only a Super Admin can revoke administrator sessions.');
    const id = Number(ctx.params.id);
    revokeAllSessions(id);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.ADMIN_EDITED, {
      summary: `Revoked all sessions for administrator #${id}`, entityType: 'user', entityId: id, ip: ctx.ip,
    });
    return ctx.redirect(`/admin/admins/${id}`, { flash: 'All sessions for that administrator were revoked.', type: 'success' });
  });

  /* -------------------------------- reports ------------------------------ */

  const reportFilters = (ctx) => {
    const report = REPORTS.some((r) => r.key === ctx.q('report', '')) ? ctx.q('report', '') : 'sessions_per_week';
    const quick = ctx.q('quick', '');
    let from = isISODate(ctx.q('from', '')) ? ctx.q('from', '') : addDaysISO(todayISO(), -27);
    let to = isISODate(ctx.q('to', '')) ? ctx.q('to', '') : todayISO();
    if (quick === 'this_week') from = weekStartISO();
    if (quick === 'this_month') from = `${todayISO().slice(0, 7)}-01`;
    if (quick === 'this_term') from = addDaysISO(todayISO(), -89);
    return { report, from, to };
  };

  router.get('/admin/reports', (ctx) => {
    ensureCan(ctx.user, 'reports.view');
    const { report, from, to } = reportFilters(ctx);
    return respond(ctx, {
      title: 'Reports', active: 'reports', portal: 'admin',
      body: reportsPage({ ctx, report: buildReport(report, { from, to }), reports: REPORTS, from, to }),
    });
  });

  router.get('/admin/reports/export', (ctx) => {
    ensureCan(ctx.user, 'reports.view');
    const { report, from, to } = reportFilters(ctx);
    const built = buildReport(report, { from, to });
    const format = ctx.q('format', 'csv');
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.REPORT_EXPORTED, {
      summary: `Exported report ${built.title} as ${format.toUpperCase()} (${from} → ${to})`, ip: ctx.ip,
    });
    if (format === 'pdf') return pdfDownload(ctx, `${report}-${todayStamp()}.pdf`, reportToPDF(built));
    return csvDownload(ctx, `${report}-${todayStamp()}.csv`, reportToCSV(built));
  });

  /* --------------------------------- audit ------------------------------- */

  const auditFilters = (ctx) => filters(ctx, { search: '', action: 'all', actor: 'all', from: '', to: '', page: '1' });

  router.get('/admin/audit', (ctx) => {
    ensureCan(ctx.user, 'audit.view');
    const f = auditFilters(ctx);
    const per = perPage(ctx);
    const { total, rows } = auditList({
      search: f.search || null,
      action: f.action === 'all' ? null : f.action,
      actorId: f.actor === 'all' ? null : Number(f.actor),
      from: isISODate(f.from) ? f.from : null,
      to: isISODate(f.to) ? f.to : null,
      limit: per,
      offset: (Math.max(1, Number(f.page)) - 1) * per,
    });
    return respond(ctx, {
      title: 'Activity log', active: 'audit', portal: 'admin',
      body: auditPage({
        ctx, entries: rows, pageInfo: paginate(total, f.page, per), filters: f,
        actions: all('SELECT DISTINCT action FROM audit_log ORDER BY action').map((r) => r.action),
        actors: all("SELECT id, username, email FROM users WHERE role IN ('super_admin','admin','scheduler','viewer') ORDER BY username"),
      }),
    });
  });

  router.get('/admin/audit/export', (ctx) => {
    ensureCan(ctx.user, 'audit.view');
    const f = auditFilters(ctx);
    const { rows } = auditList({
      search: f.search || null, action: f.action === 'all' ? null : f.action,
      actorId: f.actor === 'all' ? null : Number(f.actor),
      from: isISODate(f.from) ? f.from : null, to: isISODate(f.to) ? f.to : null,
      limit: 5000, offset: 0,
    });
    return csvDownload(ctx, `audit-log-${todayStamp()}.csv`, toCSV(
      ['When', 'Action', 'Summary', 'Actor', 'Role', 'Record', 'IP'],
      rows.map((r) => [r.created_at, r.action, r.summary, r.actor_label, r.actor_role, `${r.entity_type || ''}${r.entity_id ? ` #${r.entity_id}` : ''}`, r.ip]),
    ));
  });

  /* -------------------------------- settings ----------------------------- */

  router.get('/admin/settings', (ctx) => {
    ensureCan(ctx.user, 'settings.view');
    const settings = getSettings();
    const counts = {
      users: Number(get('SELECT COUNT(*) AS c FROM users')?.c || 0),
      tutors: Number(get("SELECT COUNT(*) AS c FROM users WHERE role = 'tutor'")?.c || 0),
      tutees: Number(get("SELECT COUNT(*) AS c FROM users WHERE role = 'tutee'")?.c || 0),
      sessions: Number(get('SELECT COUNT(*) AS c FROM sessions')?.c || 0),
      audit: Number(get('SELECT COUNT(*) AS c FROM audit_log')?.c || 0),
    };
    let size = 'unknown';
    try {
      const stats = fs.statSync(config.databasePath);
      size = `${(stats.size / 1024 / 1024).toFixed(2)} MB`;
    } catch { /* ignore */ }
    return respond(ctx, {
      title: 'Settings', active: 'settings', portal: 'admin',
      body: settingsPage({
        ctx,
        settings,
        system: {
          env: config.env,
          nodeVersion: process.version,
          databasePath: config.databasePath,
          databaseSize: size,
          sessionTtlHours: config.sessionTtlHours,
          emailTransport: transportName(),
          uptime: `${Math.round(process.uptime() / 60)} minutes`,
          counts,
          baseUrl: config.baseUrl,
        },
        outbox: outboxList({ limit: 6 }).rows,
        canManage: can(ctx.user, 'settings.manage'),
      }),
    });
  });

  router.post('/admin/settings', (ctx) => {
    ensureCan(ctx.user, 'settings.manage');
    const settings = getSettings();
    const numeric = ['session_duration_default', 'availability_slot_minutes', 'invitation_expiry_hours', 'min_password_length', 'tutor_capacity_default', 'match_min_overlap_minutes', 'session_reminder_lead_minutes', 'invitation_expiry_warning_hours', 'availability_min_notice_hours'];
    const timeKeys = ['availability_day_start', 'availability_day_end'];
    const errors = {};
    const updates = {};
    const booleanKeys = SETTINGS_GROUPS.flatMap((g) => g.fields).filter((key) => !numeric.includes(key) && !timeKeys.includes(key) && !['organisation_name', 'organisation_email', 'timezone_label', 'session_duration_options', 'default_invited_role'].includes(key));
    for (const group of SETTINGS_GROUPS) {
      for (const key of group.fields) {
        const raw = ctx.input(key, settings[key] ?? '');
        if (booleanKeys.includes(key)) { updates[key] = ctx.bool(key) ? 'true' : 'false'; continue; }
        if (numeric.includes(key)) {
          const n = Number.parseInt(raw, 10);
          if (!Number.isFinite(n) || n < 0 || n > 100000) { errors[key] = 'Enter a number between 0 and 100000'; continue; }
          if (key === 'min_password_length' && n < 8) { errors[key] = 'Passwords must be at least 8 characters'; continue; }
          if (key === 'availability_slot_minutes' && ![15, 20, 30, 45, 60].includes(n)) { errors[key] = 'Use 15, 20, 30, 45 or 60 minutes'; continue; }
          updates[key] = String(n);
          continue;
        }
        if (timeKeys.includes(key)) {
          const minutes = hhmmToMinutes(raw);
          if (minutes === null) { errors[key] = 'Use the HH:MM format (24 hour)'; continue; }
          updates[key] = minutesToHHMM(minutes);
          continue;
        }
        if (key === 'session_duration_options') {
          const parsed = raw.split(',').map((v) => Number.parseInt(v.trim(), 10)).filter((n) => Number.isFinite(n) && n > 0 && n <= 480);
          if (!parsed.length) { errors[key] = 'Provide at least one duration in minutes'; continue; }
          updates[key] = parsed.join(',');
          continue;
        }
        if (key === 'default_invited_role') {
          if (![ROLES.TUTOR, ROLES.TUTEE].includes(raw)) { errors[key] = 'Choose tutor or tutee'; continue; }
          updates[key] = raw;
          continue;
        }
        if (!raw && ['organisation_name', 'organisation_email'].includes(key)) { errors[key] = 'This field is required'; continue; }
        if (key === 'organisation_email' && raw && !isValidEmail(raw)) { errors[key] = 'Enter a valid email address'; continue; }
        updates[key] = raw.slice(0, 500);
      }
    }
    const start = hhmmToMinutes(updates.availability_day_start || settings.availability_day_start);
    const end = hhmmToMinutes(updates.availability_day_end || settings.availability_day_end);
    if (start !== null && end !== null && end <= start) errors.availability_day_end = 'The day must end after it starts';
    if (Object.keys(errors).length) {
      return ctx.redirect('/admin/settings', { flash: 'Settings not saved — please review the highlighted values.', type: 'danger', errors });
    }
    const changed = [];
    for (const [key, value] of Object.entries(updates)) {
      if (String(settings[key]) !== String(value)) changed.push(key);
      setSetting(key, value, ctx.user.id);
    }
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SETTINGS_UPDATED, {
      summary: changed.length ? `Updated settings: ${changed.join(', ')}` : 'Saved settings (no changes)',
      entityType: 'settings', ip: ctx.ip, details: { changed },
    });
    return ctx.redirect('/admin/settings', { flash: changed.length ? 'Settings saved.' : 'No changes to save.', type: 'success' });
  });

  /* ------------------------------ notifications -------------------------- */

  router.get('/admin/notifications', (ctx) => {
    ensureCan(ctx.user, 'notifications.view');
    const filter = ctx.q('filter', 'all') === 'unread' ? 'unread' : 'all';
    const per = perPage(ctx);
    const page = Math.max(1, ctx.qInt('page', 1));
    const list = listNotifications(ctx.user.id, { unreadOnly: filter === 'unread', limit: per, offset: (page - 1) * per });
    return respond(ctx, {
      title: 'Notifications', active: null, portal: 'admin',
      body: notificationsPage({
        ctx, list, basePath: '/admin/notifications', filter,
        pageInfo: paginate(list.total, page, per), params: filter === 'unread' ? { filter } : {},
      }),
    });
  });

  router.post('/admin/notifications/read-all', (ctx) => {
    markAllRead(ctx.user.id);
    return ctx.redirect('/admin/notifications', { flash: 'All notifications marked as read.', type: 'success' });
  });

  router.post('/admin/notifications/:id/read', (ctx) => {
    markRead(Number(ctx.params.id), ctx.user.id);
    return ctx.redirect('/admin/notifications', { flash: 'Notification marked as read.', type: 'info' });
  });

  router.get('/admin/outbox', (ctx) => {
    ensureCan(ctx.user, 'settings.view');
    const per = perPage(ctx);
    const page = Math.max(1, ctx.qInt('page', 1));
    const list = outboxList({ limit: per, offset: (page - 1) * per });
    return respond(ctx, {
      title: 'Email outbox', active: 'settings', portal: 'admin',
      body: outboxPage({ ctx, list, pageInfo: paginate(list.total, page, per) }),
    });
  });

  router.get('/admin/outbox/flush', async (ctx) => {
    ensureCan(ctx.user, 'settings.manage');
    const result = await flushOutbox(50);
    return ctx.redirect('/admin/outbox', {
      flash: `Outbox processed: ${result.sent} sent, ${result.failed} failed of ${result.total} queued.`,
      type: result.failed ? 'warning' : 'success',
    });
  });
}

function permissionProtected(ctx, targetId, values) {
  return Number(ctx.user.id) === Number(targetId) && ctx.user.role === ROLES.SUPER_ADMIN && values.role !== ROLES.SUPER_ADMIN;
}
