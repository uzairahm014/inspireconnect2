/**
 * Public routes: sign in/out, invitation based registration, password change and
 * reset links. Nothing here allows open self-registration.
 */
import { config, ACCOUNT_STATUS, INVITATION_STATUS, ROLES, AVAILABILITY_KIND, AVAILABILITY_STATE, WEEKDAYS } from '../config.mjs';
import {
  AUDIT_ACTIONS, HttpError, audit, clearLoginAttempts, createSession, displayName, dummyVerify,
  failedAttemptsWithin, findUserByLogin, hashPassword, isLocked, landingPath, lockAccount,
  recordLoginAttempt, revokeAllSessions, revokeSession, verifyPassword,
} from '../auth.mjs';
import { verifyAnonCsrf } from '../http.mjs';
import { all, get, run, lastId, tx, getSettings, settingBool, setSetting } from '../db.mjs';
import {
  createAvailability, createTuteeRecord, createTutorRecord, emailTaken, listSubjects,
  setUserSubjects, subjectById, touchLastLogin,
} from '../people.mjs';
import {
  consumeReset, createPasswordReset, resetByToken, resetStatusMessage,
} from '../resets.mjs';
import { consumeInvitation, invitationByToken, invitationStatusMessage, invitationStatus, invitationSubjects } from '../invitations.mjs';
import { onInvitationUsed, onNewRegistration } from '../notify.mjs';
import { alert, html, icon } from '../html.mjs';
import { hhmmToMinutes, normaliseEmail, normalisePhone, nowSQL, passwordIssues } from '../util.mjs';
import { loginPage, passwordPage, registerBlockedPage, registerPage } from '../views/auth.mjs';
import { landingPage } from '../views/marketing.mjs';
import { respond, requireUser, text } from './helpers.mjs';
import { safeNext } from '../http.mjs';

const maxPasswordLength = 200;

function signIn(ctx, user, { next = null, remember = false } = {}) {
  const session = createSession(user.id, { ip: ctx.ip, userAgent: ctx.req.headers['user-agent'] });
  const ttlHours = remember ? config.sessionTtlHours * 4 : config.sessionTtlHours;
  ctx.setCookie(config.cookieName, session.token, {
    maxAge: ttlHours * 3600,
    httpOnly: true,
    sameSite: 'Lax',
    secure: config.cookieSecure,
  });
  return session;
}

export function registerPublicRoutes(router) {
  /* ------------------------------- landing ------------------------------- */

  router.get('/', (ctx) => {
    if (ctx.user) return ctx.redirect(landingPath(ctx.user.role));
    return respond(ctx, {
      title: 'Tutor management, connected',
      plain: true,
      indexable: true,
      body: landingPage(),
    });
  });

  router.get('/healthz', (ctx) => ctx.json({ status: 'ok', time: nowSQL(), environment: config.env }));

  /* --------------------------------- login ------------------------------- */

  router.get('/login', (ctx) => {
    if (ctx.user) return ctx.redirect(landingPath(ctx.user.role));
    const next = safeNext(ctx.q('next', ''), '');
    return respond(ctx, {
      title: 'Sign in',
      plain: true,
      body: loginPage({ ctx, next, notice: ctx.q('reason') === 'timeout' ? 'Your session expired. Please sign in again.' : null }),
    });
  });

  router.post('/login', async (ctx) => {
    if (!verifyAnonCsrf(ctx.cookies || {}, ctx.input('_csrf'))) {
      throw new HttpError(403, 'Your sign-in form expired. Please reload the page and try again.');
    }
    const identifier = text(ctx, 'identifier', 200);
    const password = String(ctx.field('password', ''));
    const next = safeNext(ctx.input('next', ''), '');
    const errors = {};
    if (!identifier) errors.identifier = 'Enter your username or email address';
    if (!password) errors.password = 'Enter your password';
    if (Object.keys(errors).length) {
      return respond(ctx, {
        title: 'Sign in',
        plain: true,
        body: loginPage({ ctx, next, error: 'Please correct the highlighted fields.', }),
      });
    }

    const attempts = failedAttemptsWithin(identifier, config.loginRateWindowMinutes, ctx.ip);
    if (attempts.byIdentifier >= config.maxLoginAttempts || attempts.byIp >= config.maxLoginAttempts * 3) {
      recordLoginAttempt(identifier, ctx.ip, false, 'rate_limited');
      audit({ label: identifier }, AUDIT_ACTIONS.LOGIN_FAILED, { summary: `Rate limited sign-in for ${identifier}`, ip: ctx.ip });
      return respond(ctx, {
        title: 'Sign in',
        plain: true,
        body: loginPage({ ctx, next, error: `Too many failed attempts. Please wait about ${config.loginRateWindowMinutes} minutes and try again.` }),
      });
    }

    const user = findUserByLogin(identifier);
    if (!user) {
      await dummyVerify(password);
      recordLoginAttempt(identifier, ctx.ip, false, 'unknown_account');
      audit({ label: identifier }, AUDIT_ACTIONS.LOGIN_FAILED, { summary: `Sign-in attempt for unknown account ${identifier}`, ip: ctx.ip });
      return respond(ctx, {
        title: 'Sign in',
        plain: true,
        body: loginPage({ ctx, next, error: 'Those credentials do not match our records.' }),
      });
    }

    if (isLocked(user)) {
      recordLoginAttempt(identifier, ctx.ip, false, 'locked');
      return respond(ctx, {
        title: 'Sign in',
        plain: true,
        body: loginPage({ ctx, next, error: `This account is temporarily locked until ${user.locked_until}. Contact an administrator if you need help.` }),
      });
    }

    const ok = await verifyPassword(password, user.password_hash);
    if (!ok) {
      const failed = Number(user.failed_attempts || 0) + 1;
      run('UPDATE users SET failed_attempts = ?, updated_at = ? WHERE id = ?', [failed, nowSQL(), user.id]);
      if (failed >= config.maxLoginAttempts) {
        lockAccount(user.id, config.lockoutMinutes);
        audit({ id: user.id, label: displayName(user), role: user.role }, AUDIT_ACTIONS.LOGIN_FAILED, {
          summary: `Account locked after ${failed} failed attempts`, entityType: 'user', entityId: user.id, ip: ctx.ip,
        });
      } else {
        recordLoginAttempt(identifier, ctx.ip, false, 'bad_password');
        audit({ id: user.id, label: displayName(user), role: user.role }, AUDIT_ACTIONS.LOGIN_FAILED, {
          summary: `Failed sign-in (attempt ${failed})`, entityType: 'user', entityId: user.id, ip: ctx.ip,
        });
      }
      return respond(ctx, {
        title: 'Sign in',
        plain: true,
        body: loginPage({ ctx, next, error: 'Those credentials do not match our records.' }),
      });
    }

    if (user.status === ACCOUNT_STATUS.DISABLED) {
      recordLoginAttempt(identifier, ctx.ip, false, 'disabled');
      return respond(ctx, {
        title: 'Sign in',
        plain: true,
        body: loginPage({ ctx, next, error: 'This account has been disabled. Please contact an administrator.' }),
      });
    }

    clearLoginAttempts(identifier);
    run('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?', [user.id]);
    touchLastLogin(user.id);
    signIn(ctx, user, { next, remember: ctx.bool('remember') });
    audit({ id: user.id, label: displayName(user), role: user.role }, user.role === ROLES.TUTOR || user.role === ROLES.TUTEE ? AUDIT_ACTIONS.LOGIN : AUDIT_ACTIONS.ADMIN_LOGIN, {
      summary: `${displayName(user)} signed in`, entityType: 'user', entityId: user.id, ip: ctx.ip,
    });
    const home = landingPath(user.role);
    return ctx.redirect(next || home, {
      flash: `Welcome back, ${displayName(user)}.`,
      type: 'success',
    });
  });

  router.post('/logout', (ctx) => {
    const token = ctx.cookies?.[config.cookieName];
    if (token) revokeSession(token);
    if (ctx.user) {
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.LOGOUT, {
        summary: `${displayName(ctx.user)} signed out`, entityType: 'user', entityId: ctx.user.id, ip: ctx.ip,
      });
    }
    ctx.setCookie(config.cookieName, '', { maxAge: 0 });
    return ctx.redirect('/login', { flash: 'You have been signed out.', type: 'info' });
  });

  /* ------------------------------ registration ---------------------------- */

  const invitationScreen = (ctx, token, status, message) => respond(ctx, {
    title: 'Registration unavailable',
    plain: true,
    body: registerBlockedPage({ ctx, status, message, token }),
  });

  router.get('/register/:token', (ctx) => {
    const invitation = invitationByToken(ctx.params.token);
    if (!invitation) {
      return invitationScreen(ctx, ctx.params.token, 'invalid', invitationStatusMessage('invalid'));
    }
    const status = invitationStatus(invitation);
    if (status !== INVITATION_STATUS.PENDING) {
      audit({ label: 'system' }, AUDIT_ACTIONS.REGISTRATION_BLOCKED, {
        summary: `Blocked registration attempt with a ${status} invitation for ${invitation.email}`,
        entityType: 'invitation', entityId: invitation.id, ip: ctx.ip,
      });
      return invitationScreen(ctx, ctx.params.token, status, invitationStatusMessage(status));
    }
    const subjects = listSubjects();
    const preselected = invitationSubjects(invitation);
    return respond(ctx, {
      title: 'Create your account',
      plain: true,
      body: registerPage({
        ctx,
        invitation,
        token: ctx.params.token,
        subjects,
        values: preselected.length ? { subjects: preselected.map(String) } : {},
      }),
    });
  });

  router.post('/register/:token', async (ctx) => {
    if (!verifyAnonCsrf(ctx.cookies || {}, ctx.input('_csrf'))) {
      throw new HttpError(403, 'Your registration form expired. Please open the invitation link again.');
    }
    const invitation = invitationByToken(ctx.params.token);
    if (!invitation) return invitationScreen(ctx, ctx.params.token, 'invalid', invitationStatusMessage('invalid'));
    const status = invitationStatus(invitation);
    if (status !== INVITATION_STATUS.PENDING) {
      return invitationScreen(ctx, ctx.params.token, status, invitationStatusMessage(status));
    }

    const values = {
      full_name: text(ctx, 'full_name', 120),
      preferred_name: text(ctx, 'preferred_name', 120),
      phone: text(ctx, 'phone', 40),
      qualifications: text(ctx, 'qualifications', 400),
      experience: text(ctx, 'experience', 1000),
      year_level: text(ctx, 'year_level', 60),
      guardian_name: text(ctx, 'guardian_name', 120),
      subjects: ctx.list('subjects'),
      notes: text(ctx, 'notes', 1000),
    };
    for (let i = 0; i < 3; i += 1) {
      values[`avail_day_${i}`] = ctx.input(`avail_day_${i}`, '');
      values[`avail_from_${i}`] = ctx.input(`avail_from_${i}`, '');
      values[`avail_to_${i}`] = ctx.input(`avail_to_${i}`, '');
    }

    const errors = {};
    const password = String(ctx.field('password', ''));
    const confirm = String(ctx.field('password_confirm', ''));
    if (!values.full_name) errors.full_name = 'Your full name is required';
    if (values.full_name && values.full_name.length < 2) errors.full_name = 'Enter your full name';
    const issues = passwordIssues(password, Number(getSettings().min_password_length || config.minPasswordLength));
    if (issues.length) errors.password = issues.join('. ');
    if (password !== confirm) errors.password_confirm = 'The two passwords do not match';
    const chosen = values.subjects.map(Number).filter((n) => subjectById(n));
    if (!chosen.length) errors.subjects = invitation.role === ROLES.TUTOR ? 'Select at least one subject you teach' : 'Select at least one subject you need help with';
    if (emailTaken(invitation.email)) errors.email = 'An account already exists for this email address. Try signing in instead.';
    const availability = [];
    for (let i = 0; i < 3; i += 1) {
      const day = values[`avail_day_${i}`];
      const from = hhmmToMinutes(values[`avail_from_${i}`]);
      const to = hhmmToMinutes(values[`avail_to_${i}`]);
      if (!day && !values[`avail_from_${i}`] && !values[`avail_to_${i}`]) continue;
      if (!day || from === null || to === null) {
        errors[`avail_day_${i}`] = 'Choose a day, start and end time';
        continue;
      }
      if (to <= from) {
        errors[`avail_to_${i}`] = 'End time must be after the start time';
        continue;
      }
      availability.push({ weekday: Number(day), start: from, end: to });
    }

    if (Object.keys(errors).length) {
      return respond(ctx, {
        title: 'Create your account',
        plain: true,
        body: registerPage({
          ctx,
          invitation,
          token: ctx.params.token,
          subjects: listSubjects(),
          error: 'Some details need attention before your account can be created.',
          errors,
          values,
        }),
      });
    }

    const settings = getSettings();
    const requiresApproval = settingBool('registration_requires_approval', false);
    const passwordHash = await hashPassword(password);

    const userId = tx(() => {
      const now = nowSQL();
      const id = lastId(run(
        `INSERT INTO users (role, email, password_hash, status, must_change_password, created_at, updated_at, password_changed_at, invitation_id)
         VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?)`,
        [
          invitation.role, normaliseEmail(invitation.email), passwordHash,
          requiresApproval ? ACCOUNT_STATUS.PENDING : ACCOUNT_STATUS.ACTIVE,
          now, now, now, invitation.id,
        ],
      ));
      if (invitation.role === ROLES.TUTOR) {
        run(
          `INSERT INTO tutor_profiles (user_id, full_name, preferred_name, phone, qualifications, experience, notes, max_students, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            id, values.full_name, values.preferred_name || null, normalisePhone(values.phone) || null,
            values.qualifications || null, values.experience || null, values.notes || null,
            Number(settings.tutor_capacity_default || 12), now,
          ],
        );
      } else {
        run(
          `INSERT INTO tutee_profiles (user_id, full_name, preferred_name, phone, year_level, guardian_name, notes, sessions_per_week, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)`,
          [
            id, values.full_name, values.preferred_name || null, normalisePhone(values.phone) || null,
            values.year_level || null, values.guardian_name || null, values.notes || null, now,
          ],
        );
      }
      return id;
    });

    setUserSubjects(userId, invitation.role === ROLES.TUTOR ? 'teach' : 'need', chosen);
    for (const slot of availability) {
      createAvailability({
        userId,
        kind: AVAILABILITY_KIND.WEEKLY,
        weekday: slot.weekday,
        start_min: slot.start,
        end_min: slot.end,
        state: AVAILABILITY_STATE.AVAILABLE,
        createdBy: userId,
      });
    }
    consumeInvitation(invitation.id, userId);

    const user = get('SELECT * FROM users WHERE id = ?', [userId]);
    const actor = { id: userId, label: displayName(user), role: user.role };
    audit(actor, AUDIT_ACTIONS.INVITATION_ACCEPTED, {
      summary: `${displayName(user)} registered using invitation #${invitation.id}`,
      entityType: 'user', entityId: userId, ip: ctx.ip,
    });
    audit(actor, AUDIT_ACTIONS.REGISTRATION_SUBMITTED, {
      summary: `New ${user.role} account created for ${user.email}`,
      entityType: 'user', entityId: userId, ip: ctx.ip, details: { invitation: invitation.id },
    });
    onNewRegistration(user, invitation);
    onInvitationUsed(invitation, user);

    signIn(ctx, user);
    return ctx.redirect(landingPath(user.role), {
      flash: 'Your account is ready. Add your availability so we can match you quickly.',
      type: 'success',
    });
  });

  /* --------------------------- password management ------------------------ */

  router.form('/account/password', async (ctx) => {
    const user = requireUser(ctx);
    if (ctx.method === 'GET') {
      return respond(ctx, { title: 'Change password', plain: true, body: passwordPage({ ctx, currentUser: user }) });
    }
    const current = String(ctx.field('current_password', ''));
    const next = String(ctx.field('password', ''));
    const confirm = String(ctx.field('password_confirm', ''));
    let error = null;
    if (!(await verifyPassword(current, user.password_hash))) {
      error = 'Your current password is not correct.';
    } else if (next !== confirm) {
      error = 'The two new passwords do not match.';
    } else {
      const issues = passwordIssues(next, Number(getSettings().min_password_length || config.minPasswordLength));
      if (issues.length) error = issues.join('. ');
      else if (await verifyPassword(next, user.password_hash)) error = 'Choose a password you have not used before.';
    }
    if (error) {
      audit({ id: user.id, label: displayName(user), role: user.role }, AUDIT_ACTIONS.PASSWORD_CHANGED, {
        summary: `Failed password change for ${user.email}`, entityType: 'user', entityId: user.id, ip: ctx.ip,
      });
      return respond(ctx, { title: 'Change password', plain: true, body: passwordPage({ ctx, error, currentUser: user }) });
    }
    run(
      'UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = ?, updated_at = ? WHERE id = ?',
      [await hashPassword(next), nowSQL(), nowSQL(), user.id],
    );
    revokeAllSessions(user.id, ctx.cookies?.[config.cookieName] || null);
    audit({ id: user.id, label: displayName(user), role: user.role }, AUDIT_ACTIONS.PASSWORD_CHANGED, {
      summary: `${displayName(user)} changed their password`, entityType: 'user', entityId: user.id, ip: ctx.ip,
    });
    return ctx.redirect('/', { flash: 'Your password has been updated.', type: 'success' });
  });

  router.form('/reset/:token', async (ctx) => {
    const reset = resetByToken(ctx.params.token);
    if (!reset || reset.status !== 'pending') {
      const status = reset?.status || 'invalid';
      return respond(ctx, {
        title: 'Password reset unavailable',
        plain: true,
        body: html`<div class="auth-card">
          <h1 class="auth-title">Password reset unavailable</h1>
          ${alert(resetStatusMessage(status), 'warning', { title: 'This link cannot be used' })}
          <div class="auth-actions"><a class="btn btn--primary" href="/login">Back to sign in</a></div>
        </div>`,
      });
    }
    if (ctx.method === 'GET') {
      return respond(ctx, {
        title: 'Set a new password',
        plain: true,
        body: html`<div class="auth-card">
          <h1 class="auth-title">Set a new password</h1>
          <p class="auth-subtitle">Choose a strong password for your account.</p>
          <form method="post" action="/reset/${ctx.params.token}" class="form">
            <input type="hidden" name="_csrf" value="${ctx.csrfToken}" />
            <div class="field">
              <label class="field__label" for="reset-password">New password</label>
              <input class="input" id="reset-password" type="password" name="password" required autocomplete="new-password" minlength="${Number(getSettings().min_password_length || config.minPasswordLength)}" />
              <p class="field__hint">At least ${Number(getSettings().min_password_length || config.minPasswordLength)} characters with a letter and a number.</p>
            </div>
            <div class="field">
              <label class="field__label" for="reset-confirm">Confirm new password</label>
              <input class="input" id="reset-confirm" type="password" name="password_confirm" required autocomplete="new-password" />
            </div>
            <div class="form-actions">
              <button class="btn btn--primary" type="submit">Save new password</button>
            </div>
          </form>
        </div>`,
      });
    }
    const password = String(ctx.field('password', ''));
    const confirm = String(ctx.field('password_confirm', ''));
    const issues = passwordIssues(password, Number(getSettings().min_password_length || config.minPasswordLength));
    if (issues.length || password !== confirm) {
      return ctx.redirect(`/reset/${ctx.params.token}`, {
        flash: issues.length ? issues.join('. ') : 'The two passwords do not match.',
        type: 'danger',
      });
    }
    const user = get('SELECT * FROM users WHERE id = ?', [reset.user_id]);
    if (!user) throw new HttpError(404, 'That account no longer exists.');
    run('UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = ?, failed_attempts = 0, locked_until = NULL, status = CASE WHEN status = ? THEN ? ELSE status END, updated_at = ? WHERE id = ?', [
      await hashPassword(password), nowSQL(), ACCOUNT_STATUS.LOCKED, ACCOUNT_STATUS.ACTIVE, nowSQL(), user.id,
    ]);
    revokeAllSessions(user.id);
    consumeReset(reset.id);
    audit({ id: user.id, label: displayName(user), role: user.role }, AUDIT_ACTIONS.PASSWORD_RESET, {
      summary: `${displayName(user)} used a password reset link`, entityType: 'user', entityId: user.id, ip: ctx.ip,
    });
    return ctx.redirect('/login', { flash: 'Your password has been reset. Please sign in.', type: 'success' });
  });
}
