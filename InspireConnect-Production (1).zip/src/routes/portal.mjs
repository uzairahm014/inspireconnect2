/**
 * Tutor and tutee portal routes. Every route is scoped to the signed-in user's
 * own records; staff never pass through here.
 */
import {
  AVAILABILITY_KIND, AVAILABILITY_STATE, ROLES, SESSION_STATUS_LABELS, NOTE_VISIBILITY, WEEKDAYS,
} from '../config.mjs';
import { AUDIT_ACTIONS, audit, displayName, HttpError } from '../auth.mjs';
import { get, getSettings } from '../db.mjs';
import {
  availabilityRow, createAvailability, deleteAvailability, freeIntervalsForDate, listSubjects,
  setUserSubjects, subjectById, subjectsForUser, updateTuteeProfile, updateTutorProfile,
  weeklyGrid, listAvailability,
} from '../people.mjs';
import {
  addSessionNote, listSessions, sessionDetail, sessionRow, setSessionStatus,
  tutorAssignments, tuteeAssignments, weekStats,
} from '../sessions.mjs';
import { addDaysISO, hhmmToMinutes, isISODate, paginate, todayISO, weekStartISO, addWeeksISO } from '../util.mjs';
import { listNotifications, markAllRead, markRead, onSessionChanged, onSessionNoteAdded } from '../notify.mjs';
import { respond, text } from './helpers.mjs';
import { portalDashboard, portalAvailabilityPage, portalSessionsPage, portalTimetablePage, profilePage, studentsPage } from '../views/portal.mjs';
import { notificationsPage, sessionDetailPage } from '../views/shared.mjs';

/** Shared implementation used for both /tutor/* and /student/*. */
function registerPortal(router, role) {
  const isTutor = role === ROLES.TUTOR;
  const base = isTutor ? '/tutor' : '/student';
  const portal = isTutor ? 'tutor' : 'tutee';
  const kind = isTutor ? 'teach' : 'need';

  const profile = (userId) => get(
    `SELECT u.id, u.role, u.email, u.status, u.created_at, u.last_login_at, u.must_change_password,
            ${isTutor ? 'tp' : 'ep'}.full_name, ${isTutor ? 'tp' : 'ep'}.preferred_name, ${isTutor ? 'tp' : 'ep'}.phone,
            ${isTutor ? 'tp' : 'ep'}.photo, ${isTutor ? 'tp' : 'ep'}.notes,
            ${isTutor ? 'tp.max_students' : 'ep.year_level'} AS extra_role_field,
            ${isTutor ? 'tp.qualifications, tp.experience, tp.session_frequency' : 'ep.guardian_name, ep.guardian_contact, ep.sessions_per_week'},
            ${isTutor ? 'tp' : 'ep'}.preferred_session_times
       FROM users u LEFT JOIN ${isTutor ? 'tutor_profiles tp' : 'tutee_profiles ep'} ON ${isTutor ? 'tp' : 'ep'}.user_id = u.id
      WHERE u.id = ?`,
    [userId],
  );

  const availabilityDays = (userId) => weeklyGrid(userId).days;

  const sessionScope = (userId, extra = {}) => ({ [isTutor ? 'tutorId' : 'tuteeId']: userId, ...extra });

  const requireOwnSession = (ctx, sessionId) => {
    const session = sessionRow(sessionId);
    if (!session) throw new HttpError(404, 'That session could not be found.');
    const owns = isTutor ? Number(session.tutor_id) === Number(ctx.user.id) : Number(session.tutee_id) === Number(ctx.user.id);
    if (!owns) throw new HttpError(403, 'You can only open sessions you are part of.');
    return session;
  };

  /* ------------------------------- dashboard ----------------------------- */

  router.get(base, (ctx) => {
    const person = profile(ctx.user.id);
    if (!person) throw new HttpError(404, 'Your profile could not be loaded. Please contact an administrator.');
    const userSessions = listSessions(sessionScope(ctx.user.id, { limit: 300 })).rows;
    const week = weekStats(weekStartISO());
    const myWeek = userSessions.filter((s) => s.date >= week.weekStart && s.date <= addDaysISO(week.weekStart, 6));
    const counted = (status) => userSessions.filter((s) => s.status === status).length;
    const upcoming = userSessions
      .filter((s) => ['scheduled', 'confirmed', 'running'].includes(s.status) && s.date >= todayISO())
      .sort((a, b) => a.date.localeCompare(b.date) || a.start_min - b.start_min)
      .slice(0, 8);
    const notifications = listNotifications(ctx.user.id, { limit: 5 });
    return respond(ctx, {
      title: 'Dashboard',
      active: 'dashboard',
      portal,
      body: portalDashboard({
        ctx,
        role,
        person,
        subjects: subjectsForUser(ctx.user.id, kind),
        stats: {
          today: userSessions.filter((s) => s.date === todayISO()).length,
          thisWeek: myWeek.length,
          weekMinutes: myWeek.reduce((sum, s) => sum + (s.end_min - s.start_min), 0),
          upcoming: userSessions.filter((s) => ['scheduled', 'confirmed'].includes(s.status) && s.date >= todayISO()).length,
          completed: counted('completed'),
          availabilitySlots: listAvailability(ctx.user.id).filter((r) => r.state === AVAILABILITY_STATE.AVAILABLE).length,
        },
        upcoming,
        todayAgenda: userSessions.filter((s) => s.date === todayISO()).sort((a, b) => a.start_min - b.start_min),
        assignments: isTutor ? tutorAssignments(ctx.user.id) : tuteeAssignments(ctx.user.id),
        availabilityDays: availabilityDays(ctx.user.id),
        notifications,
      }),
    });
  });

  /* -------------------------------- profile ------------------------------ */

  router.form(`${base}/profile`, async (ctx) => {
    const person = profile(ctx.user.id);
    const mine = subjectsForUser(ctx.user.id, kind);
    if (ctx.method === 'GET') {
      return respond(ctx, {
        title: 'My profile',
        active: 'profile',
        portal,
        body: profilePage({
          ctx, role, person, subjects: mine, allSubjects: listSubjects(),
          upcoming: listSessions(sessionScope(ctx.user.id, { from: todayISO(), limit: 6, sort: 'date' })).rows
            .filter((s) => ['scheduled', 'confirmed', 'running'].includes(s.status)),
          history: listSessions(sessionScope(ctx.user.id, { limit: 8, sort: 'date', dir: 'desc' })).rows,
          assignments: isTutor ? tutorAssignments(ctx.user.id) : tuteeAssignments(ctx.user.id),
          stats: { availabilitySlots: listAvailability(ctx.user.id).filter((r) => r.state === AVAILABILITY_STATE.AVAILABLE).length, completed: listSessions(sessionScope(ctx.user.id, { status: 'completed', limit: 500 })).total },
        }),
      });
    }

    const values = {
      full_name: text(ctx, 'full_name', 120),
      preferred_name: text(ctx, 'preferred_name', 120),
      phone: text(ctx, 'phone', 40),
      notes: text(ctx, 'notes', 1000),
      preferred_session_times: text(ctx, 'preferred_session_times', 200),
      ...(isTutor
        ? { qualifications: text(ctx, 'qualifications', 400), experience: text(ctx, 'experience', 1000), session_frequency: text(ctx, 'session_frequency', 60) }
        : { year_level: text(ctx, 'year_level', 60), guardian_name: text(ctx, 'guardian_name', 120), guardian_contact: text(ctx, 'guardian_contact', 120) }),
    };
    if (!values.full_name) {
      return ctx.redirect(`${base}/profile`, { flash: 'Your full name is required.', type: 'danger', errors: { full_name: 'Full name is required' }, values });
    }

    // Profile photo: validated data URL (PNG/JPEG/WebP, max 1 MB).
    const file = ctx.file('photo');
    let photo = undefined;
    if (file && file.filename && file.data?.length) {
      const allowed = ['image/png', 'image/jpeg', 'image/webp'];
      if (!allowed.includes(file.contentType)) {
        return ctx.redirect(`${base}/profile`, { flash: 'Profile photos must be PNG, JPEG or WebP.', type: 'danger', values });
      }
      if (file.data.length > 1024 * 1024) {
        return ctx.redirect(`${base}/profile`, { flash: 'Profile photos must be 1 MB or smaller.', type: 'danger', values });
      }
      photo = `data:${file.contentType};base64,${file.data.toString('base64')}`;
    }

    if (isTutor) updateTutorProfile(ctx.user.id, { ...values, photo }, { adminFields: false });
    else updateTuteeProfile(ctx.user.id, { ...values, photo }, { adminFields: false });

    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, isTutor ? AUDIT_ACTIONS.TUTOR_EDITED : AUDIT_ACTIONS.TUTEE_EDITED, {
      summary: `${displayName(ctx.user)} updated their own profile`, entityType: 'user', entityId: ctx.user.id, ip: ctx.ip,
    });
    return ctx.redirect(`${base}/profile`, { flash: 'Profile updated.', type: 'success' });
  });

  router.post(`${base}/profile/subjects`, (ctx) => {
    const chosen = ctx.list('subjects').map(Number).filter((id) => subjectById(id) && subjectById(id).active);
    if (!chosen.length) {
      return ctx.redirect(`${base}/profile`, { flash: isTutor ? 'Select at least one subject you teach.' : 'Select at least one subject you need.', type: 'danger' });
    }
    setUserSubjects(ctx.user.id, kind, chosen);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, isTutor ? AUDIT_ACTIONS.TUTOR_EDITED : AUDIT_ACTIONS.TUTEE_EDITED, {
      summary: `${displayName(ctx.user)} updated their subjects`, entityType: 'user', entityId: ctx.user.id, ip: ctx.ip, details: { subjects: chosen },
    });
    return ctx.redirect(`${base}/profile`, { flash: 'Subjects updated — matching now uses these selections.', type: 'success' });
  });

  /* ----------------------------- availability ---------------------------- */

  router.get(`${base}/availability`, (ctx) => {
    const rows = listAvailability(ctx.user.id);
    const grid = weeklyGrid(ctx.user.id);
    const dated = rows.filter((r) => r.kind === AVAILABILITY_KIND.DATE && r.date >= todayISO());
    const weeksAhead = [];
    for (let w = 0; w < 4; w += 1) {
      const start = addWeeksISO(weekStartISO(), w);
      const days = [];
      for (let i = 0; i < 7; i += 1) {
        const date = addDaysISO(start, i);
        days.push({ date, weekday: i + 1, free: freeIntervalsForDate(rows, date) });
      }
      weeksAhead.push({ weekStart: start, days });
    }
    return respond(ctx, {
      title: 'My availability',
      active: 'availability',
      portal,
      body: portalAvailabilityPage({
        ctx, role,
        canEdit: true,
        days: grid.days,
        extraDateRows: dated,
        weeksAhead,
      }),
    });
  });

  const checkSlot = (ctx) => {
    const start = hhmmToMinutes(ctx.input('start', ''));
    const end = hhmmToMinutes(ctx.input('end', ''));
    if (start === null || end === null || end <= start) return { error: 'Choose a start and end time — the end must be after the start.' };
    const settings = getSettings();
    const dayStart = hhmmToMinutes(settings.availability_day_start) ?? 0;
    const dayEnd = hhmmToMinutes(settings.availability_day_end) ?? 1440;
    if (start < dayStart || end > dayEnd) {
      return { error: `Availability must fall between ${settings.availability_day_start} and ${settings.availability_day_end}.` };
    }
    return { start, end };
  };

  router.post(`${base}/availability/weekly`, (ctx) => {
    const parsed = checkSlot(ctx);
    if (parsed.error) return ctx.redirect(`${base}/availability`, { flash: parsed.error, type: 'danger' });
    const weekday = ctx.int('weekday', null);
    if (!weekday || weekday < 1 || weekday > 7) return ctx.redirect(`${base}/availability`, { flash: 'Choose a day of the week.', type: 'danger' });
    const from = ctx.input('effective_from', '');
    const to = ctx.input('effective_to', '');
    if ((from && !isISODate(from)) || (to && !isISODate(to))) {
      return ctx.redirect(`${base}/availability`, { flash: 'Enter valid effective dates.', type: 'danger' });
    }
    if (from && to && to < from) return ctx.redirect(`${base}/availability`, { flash: 'The end date must be on or after the start date.', type: 'danger' });
    createAvailability({
      userId: ctx.user.id,
      kind: AVAILABILITY_KIND.WEEKLY,
      weekday,
      start_min: parsed.start,
      end_min: parsed.end,
      state: ctx.input('state', AVAILABILITY_STATE.AVAILABLE),
      effective_from: from || null,
      effective_to: to || null,
      note: text(ctx, 'note', 200) || null,
      createdBy: ctx.user.id,
    });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.AVAILABILITY_UPDATED, {
      summary: `${displayName(ctx.user)} added weekly availability (${WEEKDAYS.find((d) => d.n === weekday)?.name})`,
      entityType: 'user', entityId: ctx.user.id, ip: ctx.ip,
    });
    return ctx.redirect(`${base}/availability`, { flash: 'Availability added.', type: 'success' });
  });

  router.post(`${base}/availability/date`, (ctx) => {
    const parsed = checkSlot(ctx);
    if (parsed.error) return ctx.redirect(`${base}/availability`, { flash: parsed.error, type: 'danger' });
    const date = ctx.input('date', '');
    if (!isISODate(date)) return ctx.redirect(`${base}/availability`, { flash: 'Choose a valid date.', type: 'danger' });
    createAvailability({
      userId: ctx.user.id,
      kind: AVAILABILITY_KIND.DATE,
      date,
      start_min: parsed.start,
      end_min: parsed.end,
      state: ctx.input('state', AVAILABILITY_STATE.AVAILABLE),
      note: text(ctx, 'note', 200) || null,
      createdBy: ctx.user.id,
    });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.AVAILABILITY_UPDATED, {
      summary: `${displayName(ctx.user)} added date-specific availability on ${date}`,
      entityType: 'user', entityId: ctx.user.id, ip: ctx.ip,
    });
    return ctx.redirect(`${base}/availability`, { flash: 'Date-specific availability added.', type: 'success' });
  });

  router.post(`${base}/availability/:slotId/delete`, (ctx) => {
    const slot = availabilityRow(Number(ctx.params.slotId));
    if (!slot || Number(slot.user_id) !== Number(ctx.user.id)) throw new HttpError(404, 'That availability slot could not be found.');
    deleteAvailability(slot.id);
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.AVAILABILITY_UPDATED, {
      summary: `${displayName(ctx.user)} removed an availability slot`, entityType: 'user', entityId: ctx.user.id, ip: ctx.ip,
    });
    return ctx.redirect(`${base}/availability`, { flash: 'Availability removed.', type: 'success' });
  });

  /* --------------------------- students / tutors ------------------------- */

  router.get(isTutor ? '/tutor/students' : '/student/tutor', (ctx) => {
    const assignments = isTutor ? tutorAssignments(ctx.user.id) : tuteeAssignments(ctx.user.id);
    const sessionsByTutee = {};
    for (const a of assignments) {
      const key = isTutor ? a.tutee_id : a.tutor_id;
      sessionsByTutee[key] = listSessions({
        [isTutor ? 'tuteeId' : 'tutorId']: key, [isTutor ? 'tutorId' : 'tuteeId']: ctx.user.id,
        limit: 5, sort: 'date', dir: 'desc',
      }).rows;
    }
    return respond(ctx, {
      title: isTutor ? 'My students' : 'My tutor',
      active: isTutor ? 'students' : 'tutor',
      portal,
      body: studentsPage({ ctx, role, assignments, sessionsByTutee }),
    });
  });

  /* -------------------------------- sessions ----------------------------- */

  router.get(`${base}/sessions`, (ctx) => {
    const per = Math.min(100, Math.max(5, ctx.qInt('perPage', 20)));
    const page = Math.max(1, ctx.qInt('page', 1));
    const scope = ctx.q('scope', '') === 'upcoming' ? 'upcoming' : 'all';
    const status = ctx.q('status', 'all');
    const from = isISODate(ctx.q('from', '')) ? ctx.q('from', '') : null;
    const to = isISODate(ctx.q('to', '')) ? ctx.q('to', '') : null;
    const subject = ctx.q('subject', 'all');
    const query = {
      ...sessionScope(ctx.user.id),
      from, to, subjectId: subject,
      status: scope === 'upcoming' ? ['scheduled', 'confirmed', 'running'] : status,
      upcoming: false,
      limit: per,
      offset: (page - 1) * per,
      sort: 'date',
      dir: status === 'all' && scope !== 'upcoming' ? 'desc' : 'asc',
    };
    const { total, rows } = listSessions(query);
    return respond(ctx, {
      title: 'My sessions',
      active: 'sessions',
      portal,
      body: portalSessionsPage({
        ctx, role, rows,
        pageInfo: paginate(total, page, per),
        filters: {
          from: from || '', to: to || '', subject, status, scope,
          tutee: ctx.q('tutee', 'all'), tutor: ctx.q('tutor', 'all'),
        },
        subjects: listSubjects(),
        tuteesList: isTutor ? tutorAssignments(ctx.user.id).map((a) => ({ id: a.tutee_id, full_name: a.tutee_name })) : [],
        tutorsList: !isTutor ? tuteeAssignments(ctx.user.id).map((a) => ({ id: a.tutor_id, full_name: a.tutor_name })) : [],
      }),
    });
  });

  router.get(`${base}/sessions/:id`, (ctx) => {
    const session = requireOwnSession(ctx, Number(ctx.params.id));
    const detail = sessionDetail(session.id);
    const settings = getSettings();
    const canStatus = isTutor ? settings.allow_tutor_status_updates !== 'false' : false;
    // Tutors never see administrator-only notes; tutees only see notes shared with everyone.
    const visible = isTutor
      ? detail.notes.filter((n) => n.visibility !== NOTE_VISIBILITY.PRIVATE)
      : detail.notes.filter((n) => n.visibility === NOTE_VISIBILITY.ALL || n.author_id === ctx.user.id);
    return respond(ctx, {
      title: `Session #${session.id}`,
      active: 'sessions',
      portal,
      body: sessionDetailPage({
        ctx,
        detail: { ...detail, notes: visible },
        portal,
        actionBase: `${base}/sessions`,
        backHref: `${base}/sessions`,
        canManage: false,
        canStatus,
        canNote: isTutor ? settings.allow_tutor_notes !== 'false' : settings.allow_tutee_notes === 'true',
        warnings: [],
      }),
    });
  });

  router.post(`${base}/sessions/:id/status`, (ctx) => {
    const session = requireOwnSession(ctx, Number(ctx.params.id));
    const settings = getSettings();
    if (!isTutor || settings.allow_tutor_status_updates === 'false') {
      throw new HttpError(403, 'Only administrators can change session status for your account.');
    }
    const status = ctx.input('status', '');
    const allowed = ['running', 'completed', 'cancelled'];
    if (!allowed.includes(status)) throw new HttpError(400, 'That status change is not permitted.');
    try {
      const updated = setSessionStatus(session.id, status, { id: ctx.user.id, label: displayName(ctx.user) }, {
        reason: text(ctx, 'reason', 300) || null,
        canOverride: false,
      });
      onSessionChanged(updated, { label: displayName(ctx.user) }, `Status changed to ${SESSION_STATUS_LABELS[status] || status} by the tutor.`);
      audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_STATUS_CHANGED, {
        summary: `Tutor marked session #${session.id} as ${SESSION_STATUS_LABELS[status] || status}`,
        entityType: 'session', entityId: session.id, ip: ctx.ip,
      });
      return ctx.redirect(`${base}/sessions/${session.id}`, { flash: `Session marked ${SESSION_STATUS_LABELS[status] || status}.`, type: 'success' });
    } catch (error) {
      return ctx.redirect(`${base}/sessions/${session.id}`, { flash: error.message, type: 'danger' });
    }
  });

  router.post(`${base}/sessions/:id/notes`, (ctx) => {
    const session = requireOwnSession(ctx, Number(ctx.params.id));
    const settings = getSettings();
    const allowed = isTutor ? settings.allow_tutor_notes !== 'false' : settings.allow_tutee_notes === 'true';
    if (!allowed) throw new HttpError(403, 'Note taking is disabled for your account.');
    const body = text(ctx, 'body', 4000);
    if (!body) return ctx.redirect(`${base}/sessions/${session.id}`, { flash: 'Write something before saving the note.', type: 'danger' });
    const visibility = isTutor
      ? (ctx.input('visibility', NOTE_VISIBILITY.ALL) === NOTE_VISIBILITY.STAFF_TUTOR ? NOTE_VISIBILITY.STAFF_TUTOR : NOTE_VISIBILITY.ALL)
      : (ctx.input('visibility', NOTE_VISIBILITY.ALL) === NOTE_VISIBILITY.STAFF_TUTOR ? NOTE_VISIBILITY.STAFF_TUTOR : NOTE_VISIBILITY.ALL);
    addSessionNote(session.id, { category: ctx.input('category', 'general'), visibility, body }, { id: ctx.user.id });
    onSessionNoteAdded(session, { id: ctx.user.id, label: displayName(ctx.user) });
    audit({ id: ctx.user.id, label: displayName(ctx.user), role: ctx.user.role }, AUDIT_ACTIONS.SESSION_NOTE_ADDED, {
      summary: `${displayName(ctx.user)} added a session note to #${session.id}`, entityType: 'session', entityId: session.id, ip: ctx.ip,
    });
    return ctx.redirect(`${base}/sessions/${session.id}#add-note`, { flash: 'Session note saved.', type: 'success' });
  });

  /* ------------------------------- timetable ----------------------------- */

  router.get(`${base}/timetable`, (ctx) => {
    const view = ['day', 'week', 'month'].includes(ctx.q('view', 'week')) ? ctx.q('view', 'week') : 'week';
    const date = isISODate(ctx.q('date', '')) ? ctx.q('date', '') : todayISO();
    const subject = ctx.q('subject', 'all');
    const status = ctx.q('status', 'all');
    const from = view === 'month' ? addDaysISO(`${date.slice(0, 7)}-01`, -7) : view === 'week' ? weekStartISO(date) : date;
    const to = addDaysISO(from, view === 'week' ? 6 : view === 'month' ? 45 : 0);
    const { rows } = listSessions({ ...sessionScope(ctx.user.id), from, to, subjectId: subject, status, limit: 400, sort: 'date' });
    return respond(ctx, {
      title: 'My timetable',
      active: 'timetable',
      portal,
      body: portalTimetablePage({
        ctx, role, view, date, sessions: rows,
        filters: { subject, status },
        subjects: listSubjects(),
      }),
    });
  });

  /* ----------------------------- notifications --------------------------- */

  router.get(`${base}/notifications`, (ctx) => {
    const filter = ctx.q('filter', 'all') === 'unread' ? 'unread' : 'all';
    const per = Math.min(50, Math.max(5, ctx.qInt('perPage', 20)));
    const page = Math.max(1, ctx.qInt('page', 1));
    const list = listNotifications(ctx.user.id, { unreadOnly: filter === 'unread', limit: per, offset: (page - 1) * per });
    return respond(ctx, {
      title: 'Notifications',
      active: null,
      portal,
      body: notificationsPage({
        ctx, list, basePath: `${base}/notifications`, filter,
        pageInfo: paginate(list.total, page, per), params: filter === 'unread' ? { filter } : {},
      }),
    });
  });

  router.post(`${base}/notifications/read-all`, (ctx) => {
    markAllRead(ctx.user.id);
    return ctx.redirect(`${base}/notifications`, { flash: 'All notifications marked as read.', type: 'success' });
  });

  router.post(`${base}/notifications/:id/read`, (ctx) => {
    markRead(Number(ctx.params.id), ctx.user.id);
    return ctx.redirect(`${base}/notifications`, { flash: 'Notification marked as read.', type: 'info' });
  });
}

export function registerPortalRoutes(router) {
  registerPortal(router, ROLES.TUTOR);
  registerPortal(router, ROLES.TUTEE);
}
