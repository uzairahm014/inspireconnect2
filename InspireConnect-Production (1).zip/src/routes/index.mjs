/**
 * Router assembly: public routes first (so /login and /register win), then the
 * administrator routes, then the tutor/tutee portals.
 */
import { Router } from '../http.mjs';
import { registerPublicRoutes } from './public.mjs';
import { registerAdminRoutes } from './admin.mjs';
import { registerPortalRoutes } from './portal.mjs';

export function buildRouter() {
  const router = new Router();
  registerPublicRoutes(router);
  registerAdminRoutes(router);
  registerPortalRoutes(router);
  return router;
}

export const ROUTE_GUARDS = [
  { prefix: '/admin', guard: 'staff' },
  { prefix: '/tutor', guard: 'tutor' },
  { prefix: '/student', guard: 'tutee' },
];
