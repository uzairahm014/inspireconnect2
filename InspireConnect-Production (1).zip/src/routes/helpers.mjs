/**
 * Shared helpers used by the route modules.
 */
import { ROLES, ROLE_PERMISSIONS } from '../config.mjs';
import { can, HttpError, portalFor, permissionsFor } from '../auth.mjs';
import { all, get } from '../db.mjs';
import { renderDocument } from '../views/layout.mjs';

/** Render a page inside the application shell. */
export function respond(ctx, { title, body, portal = null, active = null, plain = false, indexable = false }) {
  return ctx.htmlDocument(renderDocument({ ctx, title, body, portal: portal || portalFor(ctx.user?.role) || null, active, plain, indexable }));
}

/**
 * Make field-level validation errors and the submitted values available to the
 * form helpers (`errorFor` / `valueFor`), which read them from `ctx.flash`.
 *
 * Call this *before* rendering the view: the view is built eagerly, so patching
 * the context afterwards would be too late.
 */
export function setFormState(ctx, { errors = null, values = null } = {}) {
  ctx.flash = {
    ...(ctx.flash || {}),
    errors: errors ? { ...(ctx.flash?.errors || {}), ...errors } : (ctx.flash?.errors || {}),
    values: values ? { ...(ctx.flash?.values || {}), ...values } : (ctx.flash?.values || {}),
  };
  return ctx;
}

export function requireUser(ctx) {
  if (!ctx.user) {
    throw new HttpError(401, 'Please sign in to continue.', { redirectTo: `/login?next=${encodeURIComponent(ctx.path)}` });
  }
  return ctx.user;
}

export function requireRole(ctx, ...roles) {
  const user = requireUser(ctx);
  if (!roles.includes(user.role)) throw new HttpError(403, 'This area is not available for your account type.');
  return user;
}

export function requireStaff(ctx) {
  const user = requireUser(ctx);
  if (![ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.SCHEDULER, ROLES.VIEWER].includes(user.role)) {
    throw new HttpError(403, 'This area is for administrators only.');
  }
  return user;
}

export function permissionList(user) {
  return [...permissionsFor(user?.role)];
}

/** Trim and length-limit a value from a form field. */
export const text = (ctx, name, max = 500) => String(ctx.input(name, '')).slice(0, max);

/** Build a filter object from query parameters with defaults. */
export function filters(ctx, spec) {
  const out = {};
  for (const [key, def] of Object.entries(spec)) {
    const value = ctx.q(key, def);
    out[key] = typeof value === 'string' ? value : String(value);
  }
  return out;
}

export function listParams(obj) {
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value === undefined || value === null || value === '' || value === 'all' && key !== 'status') continue;
    out[key] = value;
  }
  return out;
}

export function csvDownload(ctx, filename, content) {
  return ctx.download(filename, content, 'text/csv; charset=utf-8');
}

export function pdfDownload(ctx, filename, buffer) {
  return ctx.download(filename, buffer, 'application/pdf');
}

export function todayStamp() {
  return new Date().toISOString().slice(0, 10);
}

/** Profile row for a tutor/tutee user id. */
export function profileFor(userId, role) {
  if (role === ROLES.TUTOR) return get('SELECT * FROM tutor_profiles WHERE user_id = ?', [userId]);
  if (role === ROLES.TUTEE) return get('SELECT * FROM tutee_profiles WHERE user_id = ?', [userId]);
  return null;
}

export function assignmentCountFor(userId, role) {
  const column = role === ROLES.TUTOR ? 'tutor_id' : 'tutee_id';
  return Number(get(`SELECT COUNT(*) AS c FROM assignments WHERE ${column} = ? AND status = 'active'`, [userId])?.c || 0);
}

/** Guard for a session: staff always allowed, tutors/tutees only for their own. */
export function assertSessionAccess(user, session) {
  if (!session) throw new HttpError(404, 'That session could not be found.');
  const isStaff = [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.SCHEDULER, ROLES.VIEWER].includes(user.role);
  if (isStaff) return true;
  if (user.role === ROLES.TUTOR && Number(session.tutor_id) === Number(user.id)) return true;
  if (user.role === ROLES.TUTEE && Number(session.tutee_id) === Number(user.id)) return true;
  throw new HttpError(403, 'You can only view sessions you are part of.');
}

export function ensureCan(user, permission, message = 'You do not have permission to do that.') {
  if (!can(user, permission)) throw new HttpError(403, message);
  return true;
}

/**
 * Resolve the shape of a tutor/tutee list request: filters, pagination, sorting.
 */
export function peopleListQuery(ctx, { subjects }) {
  const f = filters(ctx, {
    search: '', subject: 'all', status: 'all', day: 'all', assigned: 'all',
    hasAvailability: 'all', sort: 'name', dir: 'asc', page: '1', perPage: '20',
  });
  return {
    filters: f,
    query: {
      search: f.search,
      subjectId: f.subject,
      status: f.status,
      availabilityDay: f.day === 'all' ? null : f.day,
      assigned: f.assigned,
      hasAvailability: f.hasAvailability,
      sort: f.sort,
      dir: f.dir,
    },
  };
}

export function permissionMatrix(role) {
  return ROLE_PERMISSIONS[role] || [];
}

export { can, all, get, ROLE_PERMISSIONS };
