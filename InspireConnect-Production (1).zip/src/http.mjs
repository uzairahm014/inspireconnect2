/**
 * HTTP plumbing: router, request context, cookie/flash handling, body parsing
 * (urlencoded, multipart and JSON), CSRF protection, static assets, security
 * headers and typed response helpers.
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { config, PUBLIC_DIR, ROLES, ROLE_LABELS } from './config.mjs';
import { HttpError, parseCookies, serializeCookie, permissionsFor, portalFor } from './auth.mjs';
import { esc, isISODate, toISODate } from './util.mjs';

const MAX_BODY_BYTES = 64 * 1024;
const MAX_MULTIPART_BYTES = config.maxUploadBytes + 128 * 1024;
const FLASH_COOKIE = 'il_flash';
export const ANON_CSRF_COOKIE = 'il_csrf';
export const FLASH_COOKIE_NAME = FLASH_COOKIE;

/* -------------------------------------------------------------------------- */
/* Signing helpers                                                            */
/* -------------------------------------------------------------------------- */

const hmac = (value) => crypto.createHmac('sha256', config.sessionSecret).update(value).digest('base64url');

export function signValue(value) {
  const payload = Buffer.from(String(value), 'utf8').toString('base64url');
  return `${payload}.${hmac(payload)}`;
}

export function unsignValue(signed) {
  if (!signed || typeof signed !== 'string') return null;
  const idx = signed.lastIndexOf('.');
  if (idx === -1) return null;
  const payload = signed.slice(0, idx);
  const signature = signed.slice(idx + 1);
  const expected = hmac(payload);
  if (signature.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  try {
    return Buffer.from(payload, 'base64url').toString('utf8');
  } catch {
    return null;
  }
}

/** Double-submit CSRF token for unauthenticated forms (login, registration). */
export function issueAnonCsrf() {
  return signValue(crypto.randomBytes(18).toString('base64url'));
}

export function verifyAnonCsrf(cookies, submitted) {
  if (!submitted) return false;
  const stored = cookies[ANON_CSRF_COOKIE];
  if (!stored) return false;
  const a = Buffer.from(String(stored));
  const b = Buffer.from(String(submitted));
  if (a.length !== b.length) return false;
  if (!crypto.timingSafeEqual(a, b)) return false;
  return Boolean(unsignValue(submitted));
}

/* -------------------------------------------------------------------------- */
/* Cookies / flash                                                            */
/* -------------------------------------------------------------------------- */

function readFlash(cookies, res) {
  const value = unsignValue(cookies[FLASH_COOKIE]);
  if (!value) return { messages: [] };
  // Single-use: the cookie is cleared as soon as it is read.
  res.setHeader('Set-Cookie', serializeCookie(FLASH_COOKIE, '', { maxAge: 0 }));
  try {
    const parsed = JSON.parse(value);
    return { messages: Array.isArray(parsed.messages) ? parsed.messages : [], errors: parsed.errors || {}, values: parsed.values || {} };
  } catch {
    return { messages: [] };
  }
}

/* -------------------------------------------------------------------------- */
/* Body parsing                                                               */
/* -------------------------------------------------------------------------- */

function readRaw(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new HttpError(413, 'That request was too large.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function parseUrlEncoded(buffer) {
  const params = new URLSearchParams(buffer.toString('utf8'));
  const out = {};
  for (const [key, value] of params.entries()) {
    if (key in out) {
      out[key] = Array.isArray(out[key]) ? [...out[key], value] : [out[key], value];
    } else {
      out[key] = value;
    }
  }
  return out;
}

/** Minimal multipart/form-data parser (fields + small file uploads). */
function parseMultipart(buffer, boundary) {
  const delimiter = Buffer.from(`--${boundary}`);
  const fields = {};
  const files = {};
  let index = buffer.indexOf(delimiter);
  while (index !== -1) {
    let start = index + delimiter.length;
    if (buffer.slice(start, start + 2).toString() === '--') break;
    if (buffer.slice(start, start + 2).toString() === '\r\n') start += 2;
    const headerEnd = buffer.indexOf('\r\n\r\n', start);
    if (headerEnd === -1) break;
    const headersRaw = buffer.slice(start, headerEnd).toString('utf8');
    const bodyStart = headerEnd + 4;
    const next = buffer.indexOf(delimiter, bodyStart);
    const bodyEnd = next === -1 ? buffer.length : next - 2;
    const content = buffer.slice(bodyStart, bodyEnd);

    const nameMatch = /name="([^"]*)"/i.exec(headersRaw);
    const fileMatch = /filename="([^"]*)"/i.exec(headersRaw);
    const typeMatch = /Content-Type:\s*([^\r\n]+)/i.exec(headersRaw);
    if (nameMatch) {
      const name = nameMatch[1];
      if (fileMatch && fileMatch[1]) {
        files[name] = { filename: fileMatch[1], contentType: (typeMatch?.[1] || '').trim(), data: content };
      } else {
        const value = content.toString('utf8');
        fields[name] = name in fields ? (Array.isArray(fields[name]) ? [...fields[name], value] : [fields[name], value]) : value;
      }
    }
    index = next;
  }
  return { fields, files };
}

export async function parseBody(req) {
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  if (!['post', 'put', 'patch', 'delete'].includes(String(req.method).toLowerCase())) return { fields: {}, files: {} };
  if (type === 'multipart/form-data') {
    const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(String(req.headers['content-type']));
    if (!boundaryMatch) return { fields: {}, files: {} };
    const buffer = await readRaw(req, MAX_MULTIPART_BYTES);
    return parseMultipart(buffer, (boundaryMatch[1] || boundaryMatch[2]).trim());
  }
  if (type === 'application/json') {
    const buffer = await readRaw(req, MAX_BODY_BYTES);
    if (!buffer.length) return { fields: {}, files: {} };
    try {
      const parsed = JSON.parse(buffer.toString('utf8'));
      return { fields: parsed && typeof parsed === 'object' ? parsed : {}, files: {} };
    } catch {
      throw new HttpError(400, 'The request body was not valid JSON.');
    }
  }
  const buffer = await readRaw(req, MAX_BODY_BYTES);
  return { fields: parseUrlEncoded(buffer), files: {} };
}

/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const patternToRegex = (pattern) => {
  const names = [];
  const regexSource = pattern
    .split('/')
    .map((segment) => {
      if (segment.startsWith(':')) {
        names.push(segment.slice(1));
        return '([^/]+)';
      }
      return segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');
  return { regex: new RegExp(`^${regexSource}/?$`), names };
};

export class Router {
  constructor() {
    this.routes = [];
  }

  add(method, pattern, handler, options = {}) {
    const { regex, names } = patternToRegex(pattern);
    this.routes.push({ method, pattern, regex, names, handler, options });
    return this;
  }

  get(pattern, handler, options) { return this.add('GET', pattern, handler, options); }

  post(pattern, handler, options) { return this.add('POST', pattern, handler, options); }

  /** GET + POST convenience for form pages. */
  form(pattern, handler, options) {
    this.add('GET', pattern, handler, options);
    this.add('POST', pattern, handler, options);
    return this;
  }

  match(method, pathname) {
    let pathMatched = false;
    for (const route of this.routes) {
      const match = route.regex.exec(pathname);
      if (!match) continue;
      pathMatched = true;
      if (route.method !== method) continue;
      const params = {};
      route.names.forEach((name, i) => { params[name] = decodeURIComponent(match[i + 1]); });
      return { route, params };
    }
    return pathMatched ? { methodNotAllowed: true } : null;
  }
}

/* -------------------------------------------------------------------------- */
/* Static files                                                               */
/* -------------------------------------------------------------------------- */

const MIME = {
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
};

export function serveStatic(req, res, urlPath) {
  const relative = urlPath.replace(/^\/assets\/?/, '');
  const target = path.resolve(PUBLIC_DIR, relative);
  if (!target.startsWith(PUBLIC_DIR)) return false;
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return false;
  const stat = fs.statSync(target);
  const etag = `W/"${stat.size}-${Math.floor(stat.mtimeMs)}"`;
  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304).end();
    return true;
  }
  const ext = path.extname(target).toLowerCase();
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': stat.size,
    ETag: etag,
    'Cache-Control': config.isProduction ? 'public, max-age=86400' : 'no-cache',
  });
  fs.createReadStream(target).pipe(res);
  return true;
}

/* -------------------------------------------------------------------------- */
/* Request context                                                            */
/* -------------------------------------------------------------------------- */

export class Context {
  constructor({ req, res, url, params, session, user, flash, anonCsrf, cookies = {} }) {
    this.req = req;
    this.res = res;
    this.url = url;
    this.path = url.pathname;
    this.method = req.method;
    this.params = params || {};
    this.session = session;
    this.user = user;
    this.flash = flash || { messages: [] };
    this.anonCsrf = anonCsrf;
    this.cookies = cookies;
    this.body = { fields: {}, files: {} };
    this.responded = false;
    this.query = Context.parseQuery(url.searchParams);
    this.ip = headers_ip(req);
    this.startedAt = Date.now();
  }

  static parseQuery(searchParams) {
    const out = {};
    for (const [key, value] of searchParams.entries()) {
      if (key in out) out[key] = Array.isArray(out[key]) ? [...out[key], value] : [out[key], value];
      else out[key] = value;
    }
    return out;
  }

  get csrfToken() {
    return this.session ? this.session.csrf_token : this.anonCsrf;
  }

  field(name, fallback = '') {
    const value = this.body.fields?.[name];
    if (value === undefined) return fallback;
    if (Array.isArray(value)) return value;
    return typeof value === 'string' ? value : String(value);
  }

  /** Trimmed string field. */
  input(name, fallback = '') {
    const value = this.field(name, fallback);
    return Array.isArray(value) ? value : value.trim();
  }

  list(name) {
    const value = this.body.fields?.[name];
    if (value === undefined) return [];
    return Array.isArray(value) ? value.map(String) : [String(value)];
  }

  int(name, fallback = null) {
    const raw = this.input(name);
    const n = Number.parseInt(raw, 10);
    return Number.isFinite(n) ? n : fallback;
  }

  bool(name) {
    const value = this.input(name);
    return value === '1' || value === 'true' || value === 'on' || value === 'yes';
  }

  q(name, fallback = '') {
    const value = this.query[name];
    if (value === undefined || value === null) return fallback;
    return Array.isArray(value) ? value : String(value);
  }

  qInt(name, fallback = null) {
    const n = Number.parseInt(this.q(name, ''), 10);
    return Number.isFinite(n) ? n : fallback;
  }

  qDate(name, fallback = null) {
    const value = this.q(name, '');
    return isISODate(value) ? value : fallback;
  }

  file(name) {
    return this.body.files?.[name] || null;
  }

  /* ----------------------------- responses ------------------------------- */

  setHeader(name, value) {
    this.res.setHeader(name, value);
    return this;
  }

  setCookie(name, value, options = {}) {
    const header = serializeCookie(name, value, options);
    const existing = this.res.getHeader('Set-Cookie');
    const list = existing ? (Array.isArray(existing) ? [...existing, header] : [existing, header]) : [header];
    this.res.setHeader('Set-Cookie', list);
    return this;
  }

  /** Store a one-shot message (and optionally validation errors/values). */
  setFlash(type, message, { errors = null, values = null } = {}) {
    const payload = { messages: [], errors: {}, values: {} };
    const existing = unsignValue(this.req.headers.cookie ? parseCookies(this.req.headers.cookie)[FLASH_COOKIE] : '');
    if (existing) {
      try {
        const parsed = JSON.parse(existing);
        Object.assign(payload, { messages: parsed.messages || [], errors: parsed.errors || {}, values: parsed.values || {} });
      } catch { /* ignore */ }
    }
    payload.messages = [...payload.messages, { type, message: String(message) }].slice(-6);
    if (errors) payload.errors = { ...payload.errors, ...errors };
    if (values) {
      const safeValues = {};
      for (const [key, value] of Object.entries(values)) {
        const text = Array.isArray(value) ? value.map(String).map((v) => v.slice(0, 500)) : String(value ?? '').slice(0, 2000);
        safeValues[key] = text;
      }
      payload.values = { ...payload.values, ...safeValues };
    }
    let encoded = signValue(JSON.stringify(payload));
    if (encoded.length > 3500) {
      payload.values = {};
      encoded = signValue(JSON.stringify(payload));
    }
    this.setCookie(FLASH_COOKIE, encoded, { maxAge: 120, httpOnly: true, sameSite: 'Lax', secure: config.cookieSecure });
    return this;
  }

  redirect(location, { flash = null, type = 'success', errors = null, values = null, status = 303 } = {}) {
    if (flash) this.setFlash(type, flash, { errors, values });
    this.responded = true;
    this.res.writeHead(status, { Location: location }).end();
    return this;
  }

  json(data, status = 200) {
    this.responded = true;
    const body = JSON.stringify(data ?? null);
    this.res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
    this.res.end(body);
    return this;
  }

  text(body, status = 200, type = 'text/plain; charset=utf-8') {
    this.responded = true;
    this.res.writeHead(status, { 'Content-Type': type, 'Content-Length': Buffer.byteLength(body) });
    this.res.end(body);
    return this;
  }

  download(filename, content, contentType) {
    this.responded = true;
    const body = Buffer.isBuffer(content) ? content : Buffer.from(String(content), 'utf8');
    this.res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': body.length,
      'Content-Disposition': `attachment; filename="${filename.replace(/[^\w.-]+/g, '_')}"`,
      'Cache-Control': 'no-store',
    });
    this.res.end(body);
    return this;
  }

  htmlDocument(document, status = 200) {
    this.responded = true;
    const body = String(document);
    this.res.writeHead(status, {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
      'Cache-Control': 'no-store',
    });
    this.res.end(body);
    return this;
  }
}

export function headers_ip(req) {
  if (config.trustProxy) {
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (forwarded) return forwarded;
  }
  return (req.socket?.remoteAddress || '').replace(/^::ffff:/, '') || null;
}

export function securityHeaders(res) {
  res.setHeader('Content-Security-Policy', config.csp);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  res.setHeader('Origin-Agent-Cluster', '?1');
  if (config.isProduction) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.removeHeader('X-Powered-By');
}

export function verifyCsrf(ctx) {
  const method = String(ctx.method).toLowerCase();
  if (!['post', 'put', 'patch', 'delete'].includes(method)) return true;
  const submitted = ctx.input('_csrf');
  if (!submitted) throw new HttpError(403, 'Your session expired. Please reload the page and try again.');
  const expected = ctx.csrfToken;
  if (!expected) throw new HttpError(403, 'Your session expired. Please sign in again.');
  const a = Buffer.from(String(submitted));
  const b = Buffer.from(String(expected));
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    throw new HttpError(403, 'Security check failed. Please reload the page and try again.');
  }
  return true;
}

/** Best-effort "safe next" redirect target (prevents open redirects). */
export function safeNext(value, fallback = '/') {
  const next = String(value || '').trim();
  if (!next.startsWith('/') || next.startsWith('//') || next.includes('\\') || next.includes('\n')) return fallback;
  return next;
}

export { HttpError, ROLES, ROLE_LABELS, portalFor, permissionsFor, esc, toISODate };
