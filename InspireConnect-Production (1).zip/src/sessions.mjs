/**
 * Sessions: scheduling, conflict detection, rescheduling, status lifecycle,
 * session notes, tutor/tutee assignments and weekly tracking statistics.
 */
import {
  BLOCKING_STATUSES, SESSION_STATUS, SESSION_STATUSES, NOTE_VISIBILITY,
} from './config.mjs';
import { all, get, run, lastId, tx, getSettings, settingInt } from './db.mjs';
import {
  addDaysISO, isoWeekday, minutesToHHMM, nowSQL, overlapMinutes, randomToken,
  rangesOverlap, todayISO, weekDays, weekStartISO, fmtTime, fmtDate, toCSV,
} from './util.mjs';
import { freeIntervalsForDate, listAvailability, subjectById, tutorRow, tuteeRow, emailTaken } from './people.mjs';

export const STATUS_LABEL = {
  scheduled: 'Scheduled',
  confirmed: 'Confirmed',
  running: 'Running',
  completed: 'Completed',
  cancelled: 'Cancelled',
  missed: 'Missed',
  rescheduled: 'Rescheduled',
};

const SESSION_SELECT = `
  SELECT s.*,
         tp.full_name AS tutor_name, tp.photo AS tutor_photo, tu.email AS tutor_email,
         ep.full_name AS tutee_name, ep.photo AS tutee_photo, eu.email AS tutee_email,
         sub.name AS subject_name, sub.colour AS subject_colour,
         s.end_min - s.start_min AS duration_min,
         (SELECT COUNT(*) FROM session_notes n WHERE n.session_id = s.id) AS note_count
    FROM sessions s
    JOIN users tu ON tu.id = s.tutor_id
    LEFT JOIN tutor_profiles tp ON tp.user_id = s.tutor_id
    JOIN users eu ON eu.id = s.tutee_id
    LEFT JOIN tutee_profiles ep ON ep.user_id = s.tutee_id
    JOIN subjects sub ON sub.id = s.subject_id`;

export const sessionRow = (id) => get(`${SESSION_SELECT} WHERE s.id = ?`, [id]);

export function sessionDetail(id) {
  const session = sessionRow(id);
  if (!session) return null;
  return {
    session,
    notes: all(
      `SELECT n.*, COALESCE(tp.full_name, ep.full_name, u.email) AS author_name, u.role AS author_role
         FROM session_notes n
         LEFT JOIN users u ON u.id = n.author_id
         LEFT JOIN tutor_profiles tp ON tp.user_id = n.author_id
         LEFT JOIN tutee_profiles ep ON ep.user_id = n.author_id
        WHERE n.session_id = ? ORDER BY n.created_at DESC`,
      [id],
    ),
    history: all(
      `SELECT * FROM session_status_history WHERE session_id = ? ORDER BY created_at DESC, id DESC`,
      [id],
    ),
    rescheduledFrom: session.rescheduled_from_id ? sessionRow(session.rescheduled_from_id) : null,
    rescheduledTo: get(`${SESSION_SELECT} WHERE s.rescheduled_from_id = ? ORDER BY s.date, s.start_min`, [id]) || null,
  };
}

/* -------------------------------------------------------------------------- */
/* Conflict detection                                                         */
/* -------------------------------------------------------------------------- */

/**
 * @returns {{
 *   errors: {code:string, message:string}[], warnings: {code:string, message:string}[],
 *   tutorConflicts: object[], tuteeConflicts: object[],
 *   availability: {tutor:object, tutee:object}
 * }}
 */
export function checkConflicts({ tutorId, tuteeId, subjectId, date, startMin, endMin, excludeSessionId = null }) {
  const errors = [];
  const warnings = [];
  const start = Number(startMin);
  const end = Number(endMin);

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(String(date))) errors.push({ code: 'invalid_date', message: 'Choose a valid session date.' });
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end > 1440) {
    errors.push({ code: 'invalid_times', message: 'Enter valid session times.' });
  } else if (end <= start) {
    errors.push({ code: 'invalid_range', message: 'The end time must be after the start time.' });
  }

  // Sessions overlap when an existing session starts before the new one ends
  // and ends after the new one starts. The query below compares
  // `start_min < ?` against the new session's END and `end_min > ?` against
  // its START, so the parameters must be [date, end, start, ...statuses].
  const blocking = BLOCKING_STATUSES.map(() => '?').join(',');
  const baseParams = [date, end, start, ...BLOCKING_STATUSES];
  const exclude = excludeSessionId ? ' AND s.id <> ?' : '';
  const withExclude = (params) => (excludeSessionId ? [...params, excludeSessionId] : params);

  const tutorConflicts = tutorId
    ? all(
      `${SESSION_SELECT} WHERE s.date = ? AND s.start_min < ? AND s.end_min > ? AND s.status IN (${blocking}) AND s.tutor_id = ?${exclude}`,
      withExclude([...baseParams, tutorId]),
    )
    : [];
  const tuteeConflicts = tuteeId
    ? all(
      `${SESSION_SELECT} WHERE s.date = ? AND s.start_min < ? AND s.end_min > ? AND s.status IN (${blocking}) AND s.tutee_id = ?${exclude}`,
      withExclude([...baseParams, tuteeId]),
    )
    : [];

  for (const c of tutorConflicts) {
    errors.push({
      code: 'tutor_double_booking',
      message: `Tutor is already booked ${fmtDate(c.date, 'day')} ${fmtTime(c.start_min)}–${fmtTime(c.end_min)} (${c.subject_name} with ${c.tutee_name}).`,
      sessionId: c.id,
    });
  }
  for (const c of tuteeConflicts) {
    errors.push({
      code: 'tutee_double_booking',
      message: `Tutee is already booked ${fmtDate(c.date, 'day')} ${fmtTime(c.start_min)}–${fmtTime(c.end_min)} (${c.subject_name} with ${c.tutor_name}).`,
      sessionId: c.id,
    });
  }

  const availability = { tutor: null, tutee: null };
  const checkAvailability = (userId, label) => {
    if (!userId || !date) return null;
    const rows = listAvailability(userId);
    const free = freeIntervalsForDate(rows, date);
    const fullyInside = free.some((iv) => start >= iv.start && end <= iv.end);
    const partial = free.some((iv) => rangesOverlap(start, end, iv.start, iv.end));
    const info = { free, fullyInside, partial };
    if (!rows.length) {
      warnings.push({ code: `${label}_no_availability`, message: `No availability has been recorded for the ${label}.` });
    } else if (!free.length) {
      warnings.push({ code: `${label}_unavailable_day`, message: `The ${label} has no available time on ${fmtDate(date, 'day')}.` });
    } else if (!fullyInside) {
      const windows = free.map((iv) => `${fmtTime(iv.start)}–${fmtTime(iv.end)}`).join(', ');
      warnings.push({
        code: `${label}_outside_availability`,
        message: partial
          ? `Partially outside the ${label}'s availability (available ${windows}).`
          : `Outside the ${label}'s stated availability (available ${windows}).`,
      });
    }
    return info;
  };
  availability.tutor = checkAvailability(tutorId, 'tutor');
  availability.tutee = checkAvailability(tuteeId, 'tutee');

  if (subjectId && tutorId) {
    const teaches = get(
      `SELECT 1 AS ok FROM user_subjects WHERE user_id = ? AND subject_id = ? AND kind = 'teach'`,
      [tutorId, subjectId],
    );
    if (!teaches) warnings.push({ code: 'tutor_subject_mismatch', message: 'The tutor has not listed this subject as one they teach.' });
  }
  if (subjectId && tuteeId) {
    const needs = get(
      `SELECT 1 AS ok FROM user_subjects WHERE user_id = ? AND subject_id = ? AND kind = 'need'`,
      [tuteeId, subjectId],
    );
    if (!needs) warnings.push({ code: 'tutee_subject_mismatch', message: 'The tutee has not listed this subject as one they need.' });
  }
  if (tutorId && tuteeId) {
    const assigned = get(
      `SELECT 1 AS ok FROM assignments WHERE tutor_id = ? AND tutee_id = ? AND status = 'active' AND (? IS NULL OR subject_id = ?)`,
      [tutorId, tuteeId, subjectId || null, subjectId || null],
    );
    if (!assigned) warnings.push({ code: 'no_assignment', message: 'There is no active tutor assignment for this pairing and subject yet.' });
  }

  if (tutorId) {
    const tutor = tutorRow(tutorId);
    if (tutor?.max_students) {
      const current = Number(get(
        `SELECT COUNT(DISTINCT tutee_id) AS c FROM assignments WHERE tutor_id = ? AND status = 'active'`,
        [tutorId],
      )?.c || 0);
      if (current >= Number(tutor.max_students)) {
        warnings.push({ code: 'tutor_capacity', message: `${tutor.full_name || 'Tutor'} is at capacity (${current}/${tutor.max_students} tutees).` });
      }
    }
  }

  if (date && date < todayISO()) {
    warnings.push({ code: 'past_date', message: 'This session is in the past — it will be recorded as history.' });
  }
  if (durationIsUnusual(end - start)) {
    warnings.push({ code: 'unusual_duration', message: `Unusual session length (${end - start} minutes).` });
  }

  return { errors, warnings, tutorConflicts, tuteeConflicts, availability };
}

const durationIsUnusual = (minutes) => !Number.isFinite(minutes) || minutes < 15 || minutes > 240;

/* -------------------------------------------------------------------------- */
/* Create / update / reschedule                                               */
/* -------------------------------------------------------------------------- */

export function createSession(data, actor, { force = false, repeatWeeks = 1 } = {}) {
  const { tutorId, tuteeId, subjectId, date, startMin, endMin, mode, location, meetingLink, notes } = data;
  const weeks = Math.max(1, Math.min(26, Number(repeatWeeks) || 1));
  const seriesId = weeks > 1 ? randomToken(9) : null;
  const created = [];
  const skipped = [];
  const allWarnings = [];

  for (let i = 0; i < weeks; i += 1) {
    const sessionDate = addDaysISO(date, i * 7);
    const check = checkConflicts({ tutorId, tuteeId, subjectId, date: sessionDate, startMin, endMin });
    if (check.errors.length && !force) {
      if (weeks === 1) {
        const error = new Error(check.errors.map((e) => e.message).join(' '));
        error.errors = check.errors;
        error.warnings = check.warnings;
        throw error;
      }
      skipped.push({ date: sessionDate, reasons: check.errors.map((e) => e.message) });
      continue;
    }
    const id = lastId(run(
      `INSERT INTO sessions (tutor_id, tutee_id, subject_id, date, start_min, end_min, mode, location, meeting_link,
        notes, status, series_id, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        tutorId, tuteeId, subjectId, sessionDate, Number(startMin), Number(endMin),
        mode || 'in_person', location || null, meetingLink || null, notes || null,
        SESSION_STATUS.SCHEDULED, seriesId, actor?.id ?? null, nowSQL(), nowSQL(),
      ],
    ));
    run(
      `INSERT INTO session_status_history (session_id, from_status, to_status, note, actor_id, actor_label, created_at)
       VALUES (?, NULL, ?, 'Session created', ?, ?, ?)`,
      [id, SESSION_STATUS.SCHEDULED, actor?.id ?? null, actor?.label ?? null, nowSQL()],
    );
    created.push(sessionRow(id));
    allWarnings.push(...check.warnings.map((w) => ({ ...w, date: sessionDate })));
  }

  return { created, skipped, warnings: allWarnings, seriesId };
}

export function updateSession(id, data, actor) {
  const current = sessionRow(id);
  if (!current) throw new Error('Session not found.');
  const next = {
    tutorId: data.tutorId ?? current.tutor_id,
    tuteeId: data.tuteeId ?? current.tutee_id,
    subjectId: data.subjectId ?? current.subject_id,
    date: data.date ?? current.date,
    startMin: data.startMin ?? current.start_min,
    endMin: data.endMin ?? current.end_min,
  };
  const check = checkConflicts({ ...next, excludeSessionId: id });
  if (check.errors.length) {
    const error = new Error(check.errors.map((e) => e.message).join(' '));
    error.errors = check.errors;
    error.warnings = check.warnings;
    throw error;
  }
  run(
    `UPDATE sessions SET tutor_id = ?, tutee_id = ?, subject_id = ?, date = ?, start_min = ?, end_min = ?,
       mode = ?, location = ?, meeting_link = ?, notes = ?, updated_at = ? WHERE id = ?`,
    [
      next.tutorId, next.tuteeId, next.subjectId, next.date, Number(next.startMin), Number(next.endMin),
      data.mode ?? current.mode, data.location ?? current.location, data.meetingLink ?? current.meeting_link,
      data.notes ?? current.notes, nowSQL(), id,
    ],
  );
  return { session: sessionRow(id), warnings: check.warnings };
}

/** Reschedule: the original session is closed as `rescheduled` and a new linked session is created. */
export function rescheduleSession(id, { date, startMin, endMin, reason, tutorId, tuteeId, subjectId }, actor) {
  const original = sessionRow(id);
  if (!original) throw new Error('Session not found.');
  const next = {
    tutorId: tutorId ?? original.tutor_id,
    tuteeId: tuteeId ?? original.tutee_id,
    subjectId: subjectId ?? original.subject_id,
  };
  const check = checkConflicts({ ...next, date, startMin, endMin });
  if (check.errors.length) {
    const error = new Error(check.errors.map((e) => e.message).join(' '));
    error.errors = check.errors;
    throw error;
  }
  return tx(() => {
    run(
      `UPDATE sessions SET status = ?, cancel_reason = ?, updated_at = ? WHERE id = ?`,
      [SESSION_STATUS.RESCHEDULED, reason || `Rescheduled to ${date} ${minutesToHHMM(startMin)}`, nowSQL(), id],
    );
    run(
      `INSERT INTO session_status_history (session_id, from_status, to_status, note, actor_id, actor_label, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, original.status, SESSION_STATUS.RESCHEDULED, reason || null, actor?.id ?? null, actor?.label ?? null, nowSQL()],
    );
    const newId = lastId(run(
      `INSERT INTO sessions (tutor_id, tutee_id, subject_id, date, start_min, end_min, mode, location, meeting_link, notes,
         status, series_id, rescheduled_from_id, created_by, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        next.tutorId, next.tuteeId, next.subjectId, date, Number(startMin), Number(endMin),
        original.mode, original.location, original.meeting_link, original.notes,
        SESSION_STATUS.SCHEDULED, original.series_id, id, actor?.id ?? null, nowSQL(), nowSQL(),
      ],
    ));
    run(
      `INSERT INTO session_status_history (session_id, from_status, to_status, note, actor_id, actor_label, created_at)
       VALUES (?, NULL, ?, ?, ?, ?, ?)`,
      [newId, SESSION_STATUS.SCHEDULED, `Rescheduled from session #${id}`, actor?.id ?? null, actor?.label ?? null, nowSQL()],
    );
    return { originalId: id, session: sessionRow(newId), warnings: check.warnings };
  });
}

export const ALLOWED_TRANSITIONS = {
  scheduled: ['confirmed', 'running', 'completed', 'cancelled', 'missed', 'rescheduled'],
  confirmed: ['running', 'completed', 'cancelled', 'missed', 'scheduled', 'rescheduled'],
  running: ['completed', 'cancelled', 'missed'],
  completed: ['confirmed'],
  cancelled: ['scheduled'],
  missed: ['scheduled', 'completed'],
  rescheduled: [],
};

export function setSessionStatus(id, status, actor, { note = null, reason = null, canOverride = true } = {}) {
  if (!SESSION_STATUSES.includes(status)) throw new Error('Unknown session status.');
  const session = sessionRow(id);
  if (!session) throw new Error('Session not found.');
  const allowed = ALLOWED_TRANSITIONS[session.status] || [];
  if (!allowed.includes(status)) {
    if (!canOverride) throw new Error(`A ${STATUS_LABEL[session.status]} session cannot be marked ${STATUS_LABEL[status]}.`);
  }
  return tx(() => {
    run(
      `UPDATE sessions SET status = ?, cancel_reason = ?, completed_at = ?, updated_at = ? WHERE id = ?`,
      [
        status,
        status === SESSION_STATUS.CANCELLED ? (reason || session.cancel_reason) : session.cancel_reason,
        status === SESSION_STATUS.COMPLETED ? nowSQL() : session.completed_at,
        nowSQL(),
        id,
      ],
    );
    run(
      `INSERT INTO session_status_history (session_id, from_status, to_status, note, actor_id, actor_label, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id, session.status, status, reason || note || null, actor?.id ?? null, actor?.label ?? null, nowSQL()],
    );
    return sessionRow(id);
  });
}

/** Promote sessions to `running`/`missed` based on the clock. Idempotent. */
export function refreshSessionStates(now = new Date()) {
  const today = todayISO(now);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const running = run(
    `UPDATE sessions SET status = 'running', updated_at = ?
      WHERE date = ? AND start_min <= ? AND end_min > ? AND status IN ('scheduled','confirmed')`,
    [nowSQL(), today, nowMin, nowMin],
  );
  const missedHours = 12;
  const missed = run(
    `UPDATE sessions SET status = 'missed', updated_at = ?
      WHERE status IN ('scheduled','confirmed','running')
        AND datetime(date || ' ' || printf('%02d:%02d', end_min / 60, end_min % 60)) < datetime('now', ?)`,
    [nowSQL(), `-${missedHours} hours`],
  );
  return { running: Number(running.changes), missed: Number(missed.changes) };
}

/* -------------------------------------------------------------------------- */
/* Session notes                                                              */
/* -------------------------------------------------------------------------- */

export function addSessionNote(sessionId, { category, visibility, body }, author) {
  const id = lastId(run(
    `INSERT INTO session_notes (session_id, author_id, category, visibility, body, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [sessionId, author?.id ?? null, category || 'general', visibility || NOTE_VISIBILITY.ALL, String(body).trim(), nowSQL()],
  ));
  return get('SELECT * FROM session_notes WHERE id = ?', [id]);
}

export function visibleNotes(session, notes, viewer) {
  if (!viewer) return [];
  if (viewer.role !== 'tutor' && viewer.role !== 'tutee') return notes;
  return notes.filter((n) => {
    if (viewer.role === 'tutor') return n.visibility !== NOTE_VISIBILITY.PRIVATE;
    return n.visibility === NOTE_VISIBILITY.ALL;
  });
}

/* -------------------------------------------------------------------------- */
/* Queries / filters                                                          */
/* -------------------------------------------------------------------------- */

function buildSessionFilter(filters = {}) {
  const where = [];
  const params = [];
  const {
    from, to, date, tutorId, tuteeId, subjectId, status, mode, search,
    weekStart, upcoming, dayOfWeek,
  } = filters;

  if (date) { where.push('s.date = ?'); params.push(date); }
  if (from) { where.push('s.date >= ?'); params.push(from); }
  if (to) { where.push('s.date <= ?'); params.push(to); }
  if (weekStart) { where.push('s.date >= ? AND s.date <= ?'); params.push(weekStart, addDaysISO(weekStart, 6)); }
  if (tutorId) { where.push('s.tutor_id = ?'); params.push(Number(tutorId)); }
  if (tuteeId) { where.push('s.tutee_id = ?'); params.push(Number(tuteeId)); }
  if (subjectId && subjectId !== 'all') { where.push('s.subject_id = ?'); params.push(Number(subjectId)); }
  if (mode && mode !== 'all') { where.push('s.mode = ?'); params.push(mode); }
  if (status && status !== 'all') {
    if (Array.isArray(status)) {
      where.push(`s.status IN (${status.map(() => '?').join(',')})`);
      params.push(...status);
    } else {
      where.push('s.status = ?'); params.push(status);
    }
  }
  if (dayOfWeek) { where.push("CAST(strftime('%w', s.date) AS INTEGER) = ?"); params.push(Number(dayOfWeek) % 7); }
  if (upcoming) {
    where.push("(s.date > ? OR (s.date = ? AND s.end_min >= ?))");
    const now = new Date();
    params.push(todayISO(now), todayISO(now), now.getHours() * 60 + now.getMinutes());
  }
  if (search) {
    const like = `%${String(search).trim()}%`;
    where.push(`(EXISTS (SELECT 1 FROM tutor_profiles x WHERE x.user_id = s.tutor_id AND (x.full_name LIKE ? OR x.preferred_name LIKE ?))
      OR EXISTS (SELECT 1 FROM tutee_profiles y WHERE y.user_id = s.tutee_id AND (y.full_name LIKE ? OR y.preferred_name LIKE ?))
      OR EXISTS (SELECT 1 FROM subjects z WHERE z.id = s.subject_id AND z.name LIKE ?)
      OR s.location LIKE ? OR s.notes LIKE ?)`);
    params.push(like, like, like, like, like, like, like);
  }
  return { clause: where.length ? `WHERE ${where.join(' AND ')}` : '', params };
}

export function listSessions(filters = {}) {
  const { clause, params } = buildSessionFilter(filters);
  const limit = Math.max(1, Math.min(500, Number(filters.limit) || 25));
  const offset = Math.max(0, Number(filters.offset) || 0);
  const sortable = {
    date: 's.date', time: 's.start_min', tutor: 'tp.full_name', tutee: 'ep.full_name',
    subject: 'sub.name', status: 's.status', created: 's.created_at',
  };
  const orderBy = sortable[filters.sort] || 's.date';
  const direction = String(filters.dir).toLowerCase() === 'desc' ? 'DESC' : 'ASC';
  const total = Number(get(
    `SELECT COUNT(*) AS c FROM sessions s
       JOIN users tu ON tu.id = s.tutor_id LEFT JOIN tutor_profiles tp ON tp.user_id = s.tutor_id
       JOIN users eu ON eu.id = s.tutee_id LEFT JOIN tutee_profiles ep ON ep.user_id = s.tutee_id
       JOIN subjects sub ON sub.id = s.subject_id ${clause}`,
    params,
  )?.c || 0);
  const rows = all(
    `${SESSION_SELECT} ${clause} ORDER BY ${orderBy} ${direction}, s.start_min ASC LIMIT ? OFFSET ?`,
    [...params, limit, offset],
  );
  return { total, rows };
}

export const sessionsInRange = (from, to, extra = {}) =>
  listSessions({ from, to, limit: 500, ...extra }).rows;

export function sessionsForUser(userId, role, filters = {}) {
  return listSessions({
    ...filters,
    [role === 'tutor' ? 'tutorId' : 'tuteeId']: userId,
  });
}

/* -------------------------------------------------------------------------- */
/* Weekly tracking                                                            */
/* -------------------------------------------------------------------------- */

export function weekStats(weekStart = weekStartISO()) {
  const from = weekStart;
  const to = addDaysISO(weekStart, 6);
  const rows = sessionsInRange(from, to);
  const counts = Object.fromEntries(SESSION_STATUSES.map((s) => [s, 0]));
  for (const row of rows) counts[row.status] = (counts[row.status] || 0) + 1;

  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const today = todayISO(now);
  const upcoming = rows.filter((r) =>
    BLOCKING_STATUSES.includes(r.status) && (r.date > today || (r.date === today && r.end_min >= nowMin))).length;
  const todayRows = rows.filter((r) => r.date === today);

  const group = (keyFn) => {
    const map = new Map();
    for (const row of rows) {
      const key = keyFn(row);
      if (!map.has(key)) map.set(key, { key, total: 0, completed: 0, cancelled: 0, missed: 0, minutes: 0 });
      const bucket = map.get(key);
      bucket.total += 1;
      bucket.minutes += row.duration_min || (row.end_min - row.start_min);
      if (row.status === 'completed') bucket.completed += 1;
      if (row.status === 'cancelled') bucket.cancelled += 1;
      if (row.status === 'missed') bucket.missed += 1;
    }
    return [...map.values()];
  };

  const byDay = weekDays(weekStart).map((d) => {
    const daySessions = rows.filter((r) => r.date === d.date);
    return {
      ...d,
      total: daySessions.length,
      completed: daySessions.filter((r) => r.status === 'completed').length,
      cancelled: daySessions.filter((r) => r.status === 'cancelled').length,
      missed: daySessions.filter((r) => r.status === 'missed').length,
    };
  });

  return {
    weekStart: from,
    weekEnd: to,
    sessions: rows,
    total: rows.length,
    counts,
    upcoming,
    todayTotal: todayRows.length,
    todayRows,
    running: rows.filter((r) => r.status === 'running'),
    totalMinutes: rows.reduce((sum, r) => sum + (r.duration_min || (r.end_min - r.start_min)), 0),
    bySubject: group((r) => `${r.subject_id}|${r.subject_name}`).map((g) => ({ ...g, label: g.key.split('|')[1] })),
    byTutor: group((r) => `${r.tutor_id}|${r.tutor_name || r.tutor_email}`).map((g) => ({ ...g, label: g.key.split('|')[1] })),
    byTutee: group((r) => `${r.tutee_id}|${r.tutee_name || r.tutee_email}`).map((g) => ({ ...g, label: g.key.split('|')[1] })),
    byDay,
  };
}

export function dashboardCounts() {
  const today = todayISO();
  const weekStart = weekStartISO(today);
  const week = weekStats(weekStart);
  const count = (sql, params = []) => Number(get(sql, params)?.c || 0);
  return {
    totalTutors: count("SELECT COUNT(*) AS c FROM users WHERE role = 'tutor'"),
    totalTutees: count("SELECT COUNT(*) AS c FROM users WHERE role = 'tutee'"),
    activeTutors: count("SELECT COUNT(*) AS c FROM users WHERE role = 'tutor' AND status = 'active'"),
    activeTutees: count("SELECT COUNT(*) AS c FROM users WHERE role = 'tutee' AND status = 'active'"),
    pendingTutors: count("SELECT COUNT(*) AS c FROM users WHERE role = 'tutor' AND status = 'pending'"),
    pendingTutees: count("SELECT COUNT(*) AS c FROM users WHERE role = 'tutee' AND status = 'pending'"),
    availableTutors: count("SELECT COUNT(DISTINCT user_id) AS c FROM availability a JOIN users u ON u.id = a.user_id WHERE u.role = 'tutor' AND a.state = 'available'"),
    availableTutees: count("SELECT COUNT(DISTINCT user_id) AS c FROM availability a JOIN users u ON u.id = a.user_id WHERE u.role = 'tutee' AND a.state = 'available'"),
    unassignedTutees: count("SELECT COUNT(*) AS c FROM users u WHERE u.role = 'tutee' AND NOT EXISTS (SELECT 1 FROM assignments a WHERE a.tutee_id = u.id AND a.status = 'active')"),
    unassignedTutors: count("SELECT COUNT(*) AS c FROM users u WHERE u.role = 'tutor' AND NOT EXISTS (SELECT 1 FROM assignments a WHERE a.tutor_id = u.id AND a.status = 'active')"),
    sessionsThisWeek: week.total,
    sessionsToday: week.todayTotal,
    upcomingSessions: week.upcoming,
    runningSessions: week.counts.running || 0,
    completedThisWeek: week.counts.completed || 0,
    cancelledThisWeek: week.counts.cancelled || 0,
    missedThisWeek: week.counts.missed || 0,
    pendingInvitations: count("SELECT COUNT(*) AS c FROM invitations WHERE used_at IS NULL AND revoked_at IS NULL AND expires_at > datetime('now')"),
    expiringInvitations: count(
      `SELECT COUNT(*) AS c FROM invitations
        WHERE used_at IS NULL AND revoked_at IS NULL
          AND expires_at > datetime('now')
          AND expires_at <= datetime('now', ?)`,
      [`+${settingInt('invitation_expiry_warning_hours', 24)} hours`],
    ),
    usedInvitations: count('SELECT COUNT(*) AS c FROM invitations WHERE used_at IS NOT NULL'),
    totalAdmins: count("SELECT COUNT(*) AS c FROM users WHERE role IN ('super_admin','admin','scheduler','viewer')"),
    totalSubjects: count("SELECT COUNT(*) AS c FROM subjects WHERE active = 1"),
    activeAssignments: count("SELECT COUNT(*) AS c FROM assignments WHERE status = 'active'"),
    conflictCount: count(
      `SELECT COUNT(*) AS c FROM sessions s1 JOIN sessions s2
         ON s1.id < s2.id AND s1.date = s2.date AND s1.status IN ('scheduled','confirmed','running')
        AND s2.status IN ('scheduled','confirmed','running')
        AND (s1.tutor_id = s2.tutor_id OR s1.tutee_id = s2.tutee_id)
        AND s1.start_min < s2.end_min AND s1.end_min > s2.start_min
        WHERE s1.date >= ? AND s1.date <= ?`,
      [weekStart, addDaysISO(weekStart, 6)],
    ),
    week,
  };
}

/** Agenda for a single date (optionally for one person). */
export function agendaForDate(date, { tutorId = null, tuteeId = null } = {}) {
  return listSessions({ date, tutorId, tuteeId, limit: 200, sort: 'time', dir: 'asc' }).rows;
}

export function upcomingForUser(userId, role, limit = 8) {
  const rows = listSessions({
    [role === 'tutor' ? 'tutorId' : 'tuteeId']: userId,
    from: todayISO(),
    limit,
    sort: 'date',
    dir: 'asc',
  }).rows;
  return rows.filter((r) => BLOCKING_STATUSES.includes(r.status));
}

/* -------------------------------------------------------------------------- */
/* Assignments                                                               */
/* -------------------------------------------------------------------------- */

export const assignmentRow = (id) => get(
  `SELECT a.*, tp.full_name AS tutor_name, ep.full_name AS tutee_name, s.name AS subject_name, s.colour AS subject_colour
     FROM assignments a
     LEFT JOIN tutor_profiles tp ON tp.user_id = a.tutor_id
     LEFT JOIN tutee_profiles ep ON ep.user_id = a.tutee_id
     JOIN subjects s ON s.id = a.subject_id WHERE a.id = ?`,
  [id],
);

export function listAssignments(filters = {}) {
  const where = [];
  const params = [];
  if (filters.tutorId) { where.push('a.tutor_id = ?'); params.push(Number(filters.tutorId)); }
  if (filters.tuteeId) { where.push('a.tutee_id = ?'); params.push(Number(filters.tuteeId)); }
  if (filters.subjectId && filters.subjectId !== 'all') { where.push('a.subject_id = ?'); params.push(Number(filters.subjectId)); }
  if (filters.status && filters.status !== 'all') { where.push('a.status = ?'); params.push(filters.status); }
  if (filters.search) {
    const like = `%${filters.search}%`;
    where.push('(tp.full_name LIKE ? OR ep.full_name LIKE ?)');
    params.push(like, like);
  }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = Number(get(`SELECT COUNT(*) AS c FROM assignments a
      LEFT JOIN tutor_profiles tp ON tp.user_id = a.tutor_id
      LEFT JOIN tutee_profiles ep ON ep.user_id = a.tutee_id ${clause}`, params)?.c || 0);
  const rows = all(
    `SELECT a.*, tp.full_name AS tutor_name, ep.full_name AS tutee_name, s.name AS subject_name, s.colour AS subject_colour,
            (SELECT COUNT(*) FROM sessions se WHERE se.tutor_id = a.tutor_id AND se.tutee_id = a.tutee_id AND se.subject_id = a.subject_id) AS session_count
       FROM assignments a
       LEFT JOIN tutor_profiles tp ON tp.user_id = a.tutor_id
       LEFT JOIN tutee_profiles ep ON ep.user_id = a.tutee_id
       JOIN subjects s ON s.id = a.subject_id
       ${clause} ORDER BY a.started_at DESC LIMIT ? OFFSET ?`,
    [...params, Number(filters.limit) || 25, Number(filters.offset) || 0],
  );
  return { total, rows };
}

export function createAssignment({ tutorId, tuteeId, subjectId, notes }, actor) {
  if (Number(tutorId) === Number(tuteeId)) throw new Error('A tutor cannot be assigned to themselves.');
  const tutor = tutorRow(tutorId);
  const tutee = tuteeRow(tuteeId);
  if (!tutor) throw new Error('Choose a valid tutor.');
  if (!tutee) throw new Error('Choose a valid tutee.');
  if (!subjectById(subjectId)) throw new Error('Choose a valid subject.');
  const existing = get(
    `SELECT id FROM assignments WHERE tutor_id = ? AND tutee_id = ? AND subject_id = ? AND status = 'active'`,
    [tutorId, tuteeId, subjectId],
  );
  if (existing) throw new Error('This tutor is already assigned to that tutee for this subject.');
  const id = lastId(run(
    `INSERT INTO assignments (tutor_id, tutee_id, subject_id, status, started_at, notes, created_by)
     VALUES (?, ?, ?, 'active', ?, ?, ?)`,
    [tutorId, tuteeId, subjectId, nowSQL(), notes || null, actor?.id ?? null],
  ));
  return assignmentRow(id);
}

export function endAssignment(id, actor, reason = null) {
  const assignment = assignmentRow(id);
  if (!assignment) throw new Error('Assignment not found.');
  run(
    `UPDATE assignments SET status = 'ended', ended_at = ?, end_reason = ? WHERE id = ?`,
    [nowSQL(), reason || null, id],
  );
  return assignmentRow(id);
}

export function tutorAssignments(tutorId) {
  return all(
    `SELECT a.*, ep.full_name AS tutee_name, eu.email AS tutee_email, ep.phone AS tutee_phone,
            ep.year_level, s.name AS subject_name, s.colour AS subject_colour,
            (SELECT COUNT(*) FROM sessions se WHERE se.tutor_id = a.tutor_id AND se.tutee_id = a.tutee_id AND se.subject_id = a.subject_id AND se.status = 'completed') AS completed_sessions,
            (SELECT COUNT(*) FROM sessions se WHERE se.tutor_id = a.tutor_id AND se.tutee_id = a.tutee_id AND se.subject_id = a.subject_id) AS total_sessions
       FROM assignments a
       LEFT JOIN tutee_profiles ep ON ep.user_id = a.tutee_id
       LEFT JOIN users eu ON eu.id = a.tutee_id
       JOIN subjects s ON s.id = a.subject_id
      WHERE a.tutor_id = ? AND a.status = 'active'
      ORDER BY ep.full_name`,
    [tutorId],
  );
}

export function tuteeAssignments(tuteeId) {
  return all(
    `SELECT a.*, tp.full_name AS tutor_name, eu.email AS tutor_email, tp.phone AS tutor_phone,
            s.name AS subject_name, s.colour AS subject_colour,
            (SELECT COUNT(*) FROM sessions se WHERE se.tutor_id = a.tutor_id AND se.tutee_id = a.tutee_id AND se.subject_id = a.subject_id AND se.status = 'completed') AS completed_sessions
       FROM assignments a
       LEFT JOIN tutor_profiles tp ON tp.user_id = a.tutor_id
       LEFT JOIN users eu ON eu.id = a.tutor_id
       JOIN subjects s ON s.id = a.subject_id
      WHERE a.tutee_id = ? AND a.status = 'active'
      ORDER BY tp.full_name`,
    [tuteeId],
  );
}

/* -------------------------------------------------------------------------- */
/* Exports                                                                    */
/* -------------------------------------------------------------------------- */

export function sessionsCSV(rows) {
  const head = ['Date', 'Start', 'End', 'Duration (min)', 'Subject', 'Tutor', 'Tutee', 'Mode', 'Location', 'Status', 'Notes'];
  return toCSV(head, rows.map((s) => [
    s.date, minutesToHHMM(s.start_min), minutesToHHMM(s.end_min), s.duration_min || (s.end_min - s.start_min),
    s.subject_name, s.tutor_name || s.tutor_email, s.tutee_name || s.tutee_email,
    s.mode === 'online' ? 'Online' : 'In person', s.location || '', STATUS_LABEL[s.status] || s.status,
    (s.notes || '').replace(/\s+/g, ' '),
  ]));
}

export { emailTaken, isoWeekday, overlapMinutes, weekStartISO, todayISO, getSettings };
