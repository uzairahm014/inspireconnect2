/**
 * Bootstrap and demo seeding.
 *
 *   npm run seed            → subjects, settings and the initial admin account
 *   npm run seed -- --demo  → additionally creates realistic demo tutors,
 *                             tutees, availability, assignments and sessions
 *   npm run reset           → deletes the database file and rebuilds it
 *
 * Passwords for demo accounts are derived from the ADMIN_PASSWORD style env
 * value (DEMO_PASSWORD) and are hashed; nothing is written to the UI.
 */
import fs from 'node:fs';
import path from 'node:path';
import { config, ROLES, ACCOUNT_STATUS, AVAILABILITY_KIND, AVAILABILITY_STATE, SESSION_STATUS } from './config.mjs';
import { db, ensureInitialAdmin, ensureSettings, ensureSubjects, getSettings, get, run, lastId } from './db.mjs';
import { hashPassword } from './auth.mjs';
import {
  createAvailability, createTuteeRecord, createTutorRecord, setUserSubjects, listSubjects, subjectByName,
} from './people.mjs';
import { createAssignment, createSession, setSessionStatus } from './sessions.mjs';
import { createInvitation } from './invitations.mjs';
import { audit, AUDIT_ACTIONS } from './auth.mjs';
import { addDaysISO, nowSQL, todayISO, weekStartISO, isoWeekday } from './util.mjs';

const args = process.argv.slice(2);
const wantDemo = args.includes('--demo') || args.includes('--all');
const wantReset = args.includes('--reset');

if (wantReset) {
  for (const suffix of ['', '-wal', '-shm']) {
    const file = `${config.databasePath}${suffix}`;
    if (fs.existsSync(file)) fs.unlinkSync(file);
  }
  console.log(`Removed ${path.basename(config.databasePath)} — restart the app to recreate the schema.`);
  process.exit(0);
}

const DEMO_PASSWORD = process.env.DEMO_PASSWORD || 'InspireDemo2026!';
const actor = () => ({ id: null, label: 'seed', role: 'system' });

const weekdayOf = (iso) => isoWeekday(iso);

const TUTORS = [
  {
    full_name: 'Amara Okafor', preferred_name: 'Amara', email: 'amara.okafor@example.com', phone: '07700 900101',
    subjects: ['Maths', 'Science'], qualifications: 'BSc Mathematics, PGCE Secondary', experience: '8 years tutoring GCSE and A-level maths.',
    max_students: 10, availability: [[1, 16 * 60, 19 * 60], [3, 16 * 60, 20 * 60], [6, 9 * 60, 13 * 60]],
  },
  {
    full_name: 'Daniel Whitfield', preferred_name: 'Dan', email: 'daniel.whitfield@example.com', phone: '07700 900102',
    subjects: ['English', 'Science'], qualifications: 'BA English Literature, CELTA', experience: '6 years teaching English and science at KS3/KS4.',
    max_students: 8, availability: [[2, 15 * 60, 18 * 60], [4, 15 * 60, 19 * 60], [7, 10 * 60, 14 * 60]],
  },
  {
    full_name: 'Priya Raman', preferred_name: 'Priya', email: 'priya.raman@example.com', phone: '07700 900103',
    subjects: ['Maths'], qualifications: 'MEng, QTS', experience: '4 years tutoring maths, specialising in exam technique.',
    max_students: 12, availability: [[1, 17 * 60, 20 * 60], [2, 17 * 60, 20 * 60], [5, 16 * 60, 19 * 60]],
  },
];

const TUTEES = [
  {
    full_name: 'John Smith', preferred_name: 'John', email: 'john.smith@example.com', phone: '07700 900201',
    subjects: ['Maths'], year_level: 'Year 10', guardian_name: 'Helen Smith', guardian_contact: '07700 900301',
    availability: [[2, 16 * 60, 18 * 60], [4, 16 * 60, 18 * 60]],
  },
  {
    full_name: 'Sofia Alvarez', preferred_name: 'Sofia', email: 'sofia.alvarez@example.com', phone: '07700 900202',
    subjects: ['English', 'Science'], year_level: 'Year 9', guardian_name: 'Marco Alvarez', guardian_contact: '07700 900302',
    availability: [[2, 16 * 60, 17 * 60 + 30], [6, 10 * 60, 12 * 60]],
  },
  {
    full_name: 'Ethan Chen', preferred_name: 'Ethan', email: 'ethan.chen@example.com', phone: '07700 900203',
    subjects: ['Maths', 'Science'], year_level: 'A-level Year 12', guardian_name: 'Wei Chen', guardian_contact: '07700 900303',
    availability: [[1, 17 * 60, 19 * 60], [3, 17 * 60, 20 * 60]],
  },
  {
    full_name: 'Mia Thompson', preferred_name: 'Mia', email: 'mia.thompson@example.com', phone: '07700 900204',
    subjects: ['Science'], year_level: 'Year 11', guardian_name: 'Rachel Thompson', guardian_contact: '07700 900304',
    availability: [[5, 16 * 60, 18 * 60]],
  },
];

async function seedDemo() {
  const subjects = listSubjects();
  const byName = (name) => subjects.find((s) => s.name.toLowerCase() === name.toLowerCase());
  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const created = { tutors: [], tutees: [] };

  for (const tutor of TUTORS) {
    if (get('SELECT id FROM users WHERE email = ?', [tutor.email])) continue;
    const userId = createTutorRecord({
      ...tutor,
      subjects: tutor.subjects.map((n) => byName(n)?.id).filter(Boolean),
    }, { status: ACCOUNT_STATUS.ACTIVE });
    run(
      `UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = ?, last_login_at = ? WHERE id = ?`,
      [passwordHash, nowSQL(), nowSQL(new Date(Date.now() - 86400000)), userId],
    );
    setUserSubjects(userId, 'teach', tutor.subjects.map((n) => byName(n)?.id).filter(Boolean));
    for (const [weekday, start, end] of tutor.availability) {
      createAvailability({
        userId, kind: AVAILABILITY_KIND.WEEKLY, weekday, start_min: start, end_min: end,
        state: AVAILABILITY_STATE.AVAILABLE, note: 'Term-time availability',
      });
    }
    created.tutors.push({ id: userId, ...tutor });
    audit(actor(), AUDIT_ACTIONS.TUTOR_CREATED, { summary: `Seeded tutor ${tutor.full_name}`, entityType: 'user', entityId: userId });
  }

  for (const tutee of TUTEES) {
    if (get('SELECT id FROM users WHERE email = ?', [tutee.email])) continue;
    const userId = createTuteeRecord({
      ...tutee,
      subjects: tutee.subjects.map((n) => byName(n)?.id).filter(Boolean),
    }, { status: ACCOUNT_STATUS.ACTIVE });
    run(
      `UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = ?, last_login_at = ? WHERE id = ?`,
      [passwordHash, nowSQL(), nowSQL(new Date(Date.now() - 2 * 86400000)), userId],
    );
    setUserSubjects(userId, 'need', tutee.subjects.map((n) => byName(n)?.id).filter(Boolean));
    for (const [weekday, start, end] of tutee.availability) {
      createAvailability({
        userId, kind: AVAILABILITY_KIND.WEEKLY, weekday, start_min: start, end_min: end,
        state: AVAILABILITY_STATE.AVAILABLE, note: 'After school',
      });
    }
    created.tutees.push({ id: userId, ...tutee });
    audit(actor(), AUDIT_ACTIONS.TUTEE_CREATED, { summary: `Seeded tutee ${tutee.full_name}`, entityType: 'user', entityId: userId });
  }

  // Assignments: John ↔ Priya (Maths), Sofia ↔ Daniel (English), Ethan ↔ Amara (Science)
  const weeklySession = (tutorId, tuteeId, subjectId, weekday, startMin, endMin, { completed = false, weeks = 4 } = {}) => {
    const thisMonday = weekStartISO();
    const offset = weekday - 1;
    for (let w = 0; w < weeks; w += 1) {
      const date = addDaysISO(thisMonday, offset + w * 7);
      try {
        const result = createSession(
          { tutorId, tuteeId, subjectId, date, startMin, endMin, mode: w % 2 === 0 ? 'in_person' : 'online', location: w % 2 === 0 ? 'Study room 2' : 'https://meet.example.com/inspirelink' },
          actor(),
          { force: true },
        );
        const session = result.created[0];
        if (completed && date < todayISO()) {
          setSessionStatus(session.id, SESSION_STATUS.COMPLETED, actor(), { note: 'Seeded as completed' });
        }
      } catch { /* ignore clashes while seeding */ }
    }
  };

  const findTutor = (name) => created.tutors.find((t) => t.full_name === name) || get('SELECT id FROM users WHERE email LIKE ?', [`%${name.split(' ')[0].toLowerCase()}%`]);
  const findTutee = (name) => created.tutees.find((t) => t.full_name === name);

  const pairs = [
    ['Priya Raman', 'John Smith', 'Maths', 2, 16 * 60, 17 * 60],
    ['Daniel Whitfield', 'Sofia Alvarez', 'English', 2, 16 * 60, 17 * 60],
    ['Amara Okafor', 'Ethan Chen', 'Science', 3, 17 * 60, 18 * 60],
  ];

  for (const [tutorName, tuteeName, subjectName, weekday, startMin, endMin] of pairs) {
    const tutor = findTutor(tutorName);
    const tutee = findTutee(tuteeName);
    const subject = byName(subjectName);
    if (!tutor?.id || !tutee?.id || !subject?.id) continue;
    try {
      createAssignment({ tutorId: tutor.id, tuteeId: tutee.id, subjectId: subject.id, notes: 'Seeded assignment' }, actor());
    } catch { /* already assigned */ }
    weeklySession(tutor.id, tutee.id, subject.id, weekday, startMin, endMin, { completed: true, weeks: 3 });
    weeklySession(tutor.id, tutee.id, subject.id, weekday, startMin, endMin, { completed: false, weeks: 1 });
  }

  // A pending invitation so Invitation management has something to show.
  if (!get("SELECT id FROM invitations WHERE email = 'new.tutor@example.com'")) {
    const { token, invitation } = createInvitation({
      role: ROLES.TUTOR, email: 'new.tutor@example.com', fullName: 'New Tutor', subjectIds: [byName('Maths')?.id].filter(Boolean),
      note: 'Seeded pending invitation',
    }, { id: null });
    console.log(`  Pending invitation token created (register URL path: /register/${token.slice(0, 8)}…)`);
    audit(actor(), AUDIT_ACTIONS.INVITATION_CREATED, { summary: 'Seeded pending invitation', entityType: 'invitation', entityId: invitation.id });
  }

  console.log(`  Demo data ready — ${created.tutors.length} tutors, ${created.tutees.length} tutees, sessions and assignments.`);
  console.log(`  Demo tutor/tutee password: ${DEMO_PASSWORD} (hashed in the database; change before real use).`);
}

async function main() {
  ensureSettings();
  ensureSubjects();
  const admin = await ensureInitialAdmin({ force: false });
  console.log(admin.created
    ? `Initial administrator "${config.initialAdmin.username}" created (must change password at first sign-in).`
    : `Administrator "${config.initialAdmin.username}" already exists — left unchanged.`);
  console.log(`Subjects ready: ${listSubjects().map((s) => s.name).join(', ')}`);
  console.log(`Settings: ${Object.keys(getSettings()).length} keys active.`);

  if (wantDemo) {
    await seedDemo();
  } else {
    console.log('Tip: run `npm run seed -- --demo` to add sample tutors, tutees, availability and sessions.');
  }
  try { db.close(); } catch { /* ignore */ }
}

await main();
