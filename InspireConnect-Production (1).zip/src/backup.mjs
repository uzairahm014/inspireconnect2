/**
 * Database backup utility.
 *
 *   npm run backup              # write data/backups/inspirelink-<timestamp>.db
 *   npm run backup -- --keep 30 # prune older snapshots, keeping the newest 30
 *
 * Uses SQLite's `VACUUM INTO`, which produces a consistent single-file copy of
 * the live database (including the WAL) without stopping the application.
 * No credentials or session secrets are copied into the snapshot beyond what the
 * database already stores as hashes.
 */
import fs from 'node:fs';
import path from 'node:path';

import { config } from './config.mjs';
import { db } from './db.mjs';

const args = process.argv.slice(2);
const keepIndex = args.indexOf('--keep');
const keep = keepIndex === -1 ? 30 : Math.max(1, Number(args[keepIndex + 1]) || 30);

const backupDir = path.join(config.dataDir, 'backups');
fs.mkdirSync(backupDir, { recursive: true });

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const target = path.join(backupDir, `inspirelink-${stamp}.db`);

// VACUUM INTO refuses to overwrite, so the unique timestamp guarantees safety.
db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);

const { size } = fs.statSync(target);
console.log(`Backup written: ${path.relative(process.cwd(), target)} (${(size / 1024).toFixed(1)} KB)`);

/* Prune old snapshots, newest first. */
const snapshots = fs.readdirSync(backupDir)
  .filter((name) => name.startsWith('inspirelink-') && name.endsWith('.db'))
  .sort()
  .reverse();

for (const stale of snapshots.slice(keep)) {
  fs.rmSync(path.join(backupDir, stale), { force: true });
  console.log(`Pruned old backup: ${stale}`);
}
