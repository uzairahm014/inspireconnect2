/**
 * Reporting: date-filtered operational reports with CSV and PDF export.
 * Every report returns the same shape ({ title, columns, rows, totals }) so the
 * table view, CSV and PDF all render from one definition.
 */
import { SESSION_STATUS, WEEKDAYS, ROLE_LABELS } from './config.mjs';
import { all, get, settingInt } from './db.mjs';
import {
  addDaysISO, buildPDF, durationLabel, fmtTime, fmtDate, groupBy, minutesToHHMM,
  todayISO, toCSV, weekStartISO, weekdayName,
} from './util.mjs';
import { listAvailability, freeIntervalsForDate } from './people.mjs';

const STATUS_ORDER = Object.values(SESSION_STATUS);

export const REPORTS = [
  { key: 'sessions_per_week', title: 'Sessions per week', description: 'Weekly session volume with completion, cancellation and missed counts.' },
  { key: 'sessions_per_tutor', title: 'Sessions per tutor', description: 'Tutor workload across the selected period.' },
  { key: 'sessions_per_student', title: 'Sessions per student', description: 'Session totals for each tutee.' },
  { key: 'sessions_per_subject', title: 'Sessions per subject', description: 'Demand by subject.' },
  { key: 'status_totals', title: 'Status summary', description: 'Totals for every session status.' },
  { key: 'tutor_workload', title: 'Tutor workload & capacity', description: 'Active tutees against each tutor\u2019s capacity.' },
  { key: 'student_utilisation', title: 'Student session totals', description: 'Completed, cancelled and missed sessions per student.' },
  { key: 'availability_overview', title: 'Availability overview', description: 'Recorded availability and weekly capacity per person.' },
];

const rangeWhere = (from, to) => ({ clause: 'AND s.date >= ? AND s.date <= ?', params: [from, to] });

function sessionRows(from, to) {
  return all(
    `SELECT s.*, sub.name AS subject_name,
            tp.full_name AS tutor_name, ep.full_name AS tutee_name
       FROM sessions s
       JOIN subjects sub ON sub.id = s.subject_id
       LEFT JOIN tutor_profiles tp ON tp.user_id = s.tutor_id
       LEFT JOIN tutee_profiles ep ON ep.user_id = s.tutee_id
      WHERE s.date >= ? AND s.date <= ?
      ORDER BY s.date, s.start_min`,
    [from, to],
  );
}

function summariseStatuses(rows) {
  const counts = Object.fromEntries(STATUS_ORDER.map((s) => [s, 0]));
  for (const row of rows) counts[row.status] = (counts[row.status] || 0) + 1;
  return counts;
}

/* -------------------------------------------------------------------------- */
/* Individual reports                                                         */
/* -------------------------------------------------------------------------- */

function sessionsPerWeek(from, to) {
  const rows = sessionRows(from, to);
  const buckets = groupBy(rows, (r) => weekStartISO(r.date));
  const list = [...buckets.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([week, items]) => {
      const counts = summariseStatuses(items);
      return {
        week,
        label: `${fmtDate(week, 'short')} – ${fmtDate(addDaysISO(week, 6), 'short')}`,
        total: items.length,
        completed: counts.completed,
        cancelled: counts.cancelled,
        missed: counts.missed,
        running: counts.running,
        scheduled: counts.scheduled + counts.confirmed,
        minutes: items.reduce((s, r) => s + (r.end_min - r.start_min), 0),
      };
    });
  return {
    key: 'sessions_per_week',
    title: 'Sessions per week',
    columns: [
      { key: 'label', label: 'Week', width: 3 },
      { key: 'total', label: 'Total', width: 1.2 },
      { key: 'scheduled', label: 'Scheduled/confirmed', width: 1.6 },
      { key: 'running', label: 'Running', width: 1.2 },
      { key: 'completed', label: 'Completed', width: 1.2 },
      { key: 'cancelled', label: 'Cancelled', width: 1.2 },
      { key: 'missed', label: 'Missed', width: 1.2 },
      { key: 'hours', label: 'Hours', width: 1 },
    ],
    rows: list.map((r) => ({ ...r, hours: (r.minutes / 60).toFixed(1) })),
    totals: {
      total: list.reduce((s, r) => s + r.total, 0),
      completed: list.reduce((s, r) => s + r.completed, 0),
      cancelled: list.reduce((s, r) => s + r.cancelled, 0),
      missed: list.reduce((s, r) => s + r.missed, 0),
      hours: (list.reduce((s, r) => s + r.minutes, 0) / 60).toFixed(1),
    },
  };
}

function sessionsPerTutor(from, to) {
  const rows = all(
    `SELECT s.tutor_id,
            COALESCE(tp.full_name, u.email) AS tutor_name,
            COUNT(*) AS total,
            SUM(CASE WHEN s.status = 'completed' THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN s.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
            SUM(CASE WHEN s.status = 'missed' THEN 1 ELSE 0 END) AS missed,
            SUM(s.end_min - s.start_min) AS minutes,
            COUNT(DISTINCT s.tutee_id) AS tutee_count
       FROM sessions s JOIN users u ON u.id = s.tutor_id
       LEFT JOIN tutor_profiles tp ON tp.user_id = s.tutor_id
      WHERE s.date >= ? AND s.date <= ?
      GROUP BY s.tutor_id ORDER BY total DESC`,
    [from, to],
  );
  return {
    key: 'sessions_per_tutor',
    title: 'Sessions per tutor',
    columns: [
      { key: 'tutor_name', label: 'Tutor', width: 3 },
      { key: 'tutee_count', label: 'Tutees', width: 1 },
      { key: 'total', label: 'Total', width: 1 },
      { key: 'completed', label: 'Completed', width: 1.2 },
      { key: 'cancelled', label: 'Cancelled', width: 1.2 },
      { key: 'missed', label: 'Missed', width: 1.2 },
      { key: 'hours', label: 'Hours', width: 1 },
    ],
    rows: rows.map((r) => ({ ...r, hours: (Number(r.minutes || 0) / 60).toFixed(1) })),
    totals: { total: rows.reduce((s, r) => s + Number(r.total), 0), hours: (rows.reduce((s, r) => s + Number(r.minutes || 0), 0) / 60).toFixed(1) },
  };
}

function sessionsPerStudent(from, to) {
  const rows = all(
    `SELECT s.tutee_id,
            COALESCE(ep.full_name, u.email) AS tutee_name,
            COUNT(*) AS total,
            SUM(CASE WHEN s.status = 'completed' THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN s.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
            SUM(CASE WHEN s.status = 'missed' THEN 1 ELSE 0 END) AS missed,
            SUM(s.end_min - s.start_min) AS minutes,
            COUNT(DISTINCT s.tutor_id) AS tutor_count
       FROM sessions s JOIN users u ON u.id = s.tutee_id
       LEFT JOIN tutee_profiles ep ON ep.user_id = s.tutee_id
      WHERE s.date >= ? AND s.date <= ?
      GROUP BY s.tutee_id ORDER BY total DESC`,
    [from, to],
  );
  return {
    key: 'sessions_per_student',
    title: 'Sessions per student',
    columns: [
      { key: 'tutee_name', label: 'Tutee', width: 3 },
      { key: 'tutor_count', label: 'Tutors', width: 1 },
      { key: 'total', label: 'Total', width: 1 },
      { key: 'completed', label: 'Completed', width: 1.2 },
      { key: 'cancelled', label: 'Cancelled', width: 1.2 },
      { key: 'missed', label: 'Missed', width: 1.2 },
      { key: 'hours', label: 'Hours', width: 1 },
    ],
    rows: rows.map((r) => ({ ...r, hours: (Number(r.minutes || 0) / 60).toFixed(1) })),
    totals: { total: rows.reduce((s, r) => s + Number(r.total), 0) },
  };
}

function sessionsPerSubject(from, to) {
  const rows = all(
    `SELECT sub.name AS subject_name, sub.colour,
            COUNT(*) AS total,
            SUM(CASE WHEN s.status = 'completed' THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN s.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
            SUM(CASE WHEN s.status = 'missed' THEN 1 ELSE 0 END) AS missed,
            SUM(s.end_min - s.start_min) AS minutes,
            COUNT(DISTINCT s.tutor_id) AS tutor_count,
            COUNT(DISTINCT s.tutee_id) AS tutee_count
       FROM sessions s JOIN subjects sub ON sub.id = s.subject_id
      WHERE s.date >= ? AND s.date <= ?
      GROUP BY s.subject_id ORDER BY total DESC`,
    [from, to],
  );
  return {
    key: 'sessions_per_subject',
    title: 'Sessions per subject',
    columns: [
      { key: 'subject_name', label: 'Subject', width: 2.4 },
      { key: 'total', label: 'Total', width: 1 },
      { key: 'completed', label: 'Completed', width: 1.2 },
      { key: 'cancelled', label: 'Cancelled', width: 1.2 },
      { key: 'missed', label: 'Missed', width: 1.2 },
      { key: 'tutor_count', label: 'Tutors', width: 1 },
      { key: 'tutee_count', label: 'Tutees', width: 1 },
      { key: 'hours', label: 'Hours', width: 1 },
    ],
    rows: rows.map((r) => ({ ...r, hours: (Number(r.minutes || 0) / 60).toFixed(1) })),
    totals: { total: rows.reduce((s, r) => s + Number(r.total), 0) },
  };
}

function statusTotals(from, to) {
  const rows = all(
    `SELECT s.status, COUNT(*) AS total, SUM(s.end_min - s.start_min) AS minutes
       FROM sessions s WHERE s.date >= ? AND s.date <= ? GROUP BY s.status`,
    [from, to],
  );
  const map = Object.fromEntries(rows.map((r) => [r.status, r]));
  const list = STATUS_ORDER.map((status) => ({
    status,
    label: status.charAt(0).toUpperCase() + status.slice(1),
    total: Number(map[status]?.total || 0),
    hours: (Number(map[status]?.minutes || 0) / 60).toFixed(1),
  }));
  return {
    key: 'status_totals',
    title: 'Status summary',
    columns: [
      { key: 'label', label: 'Status', width: 2 },
      { key: 'total', label: 'Sessions', width: 1 },
      { key: 'hours', label: 'Hours', width: 1 },
    ],
    rows: list,
    totals: { total: list.reduce((s, r) => s + r.total, 0) },
  };
}

function tutorWorkload() {
  const weekStart = weekStartISO();
  const rows = all(
    `SELECT u.id, COALESCE(tp.full_name, u.email) AS tutor_name, u.status, tp.max_students,
            (SELECT COUNT(DISTINCT a.tutee_id) FROM assignments a WHERE a.tutor_id = u.id AND a.status = 'active') AS tutees,
            (SELECT COUNT(*) FROM sessions s WHERE s.tutor_id = u.id AND s.date >= ? AND s.date <= ?) AS week_sessions,
            (SELECT COUNT(*) FROM sessions s WHERE s.tutor_id = u.id AND s.status = 'completed') AS completed_total,
            (SELECT COUNT(*) FROM availability av WHERE av.user_id = u.id AND av.state = 'available') AS slots
       FROM users u LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
      WHERE u.role = 'tutor' ORDER BY tutees DESC, tutor_name`,
    [weekStart, addDaysISO(weekStart, 6)],
  );
  return {
    key: 'tutor_workload',
    title: 'Tutor workload & capacity',
    columns: [
      { key: 'tutor_name', label: 'Tutor', width: 3 },
      { key: 'status', label: 'Status', width: 1 },
      { key: 'tutees', label: 'Active tutees', width: 1.2 },
      { key: 'capacity', label: 'Capacity', width: 1 },
      { key: 'utilisation', label: 'Utilisation', width: 1.2 },
      { key: 'week_sessions', label: 'Sessions this week', width: 1.4 },
      { key: 'slots', label: 'Availability slots', width: 1.4 },
    ],
    rows: rows.map((r) => ({
      ...r,
      capacity: r.max_students || settingInt('tutor_capacity_default', 12),
      utilisation: `${Math.round((Number(r.tutees) / Math.max(1, Number(r.max_students || 12))) * 100)}%`,
    })),
    totals: { tutees: rows.reduce((s, r) => s + Number(r.tutees), 0), week_sessions: rows.reduce((s, r) => s + Number(r.week_sessions), 0) },
  };
}

function studentUtilisation() {
  const rows = all(
    `SELECT u.id, COALESCE(ep.full_name, u.email) AS tutee_name, u.status,
            (SELECT COUNT(*) FROM sessions s WHERE s.tutee_id = u.id) AS total,
            (SELECT COUNT(*) FROM sessions s WHERE s.tutee_id = u.id AND s.status = 'completed') AS completed,
            (SELECT COUNT(*) FROM sessions s WHERE s.tutee_id = u.id AND s.status = 'cancelled') AS cancelled,
            (SELECT COUNT(*) FROM sessions s WHERE s.tutee_id = u.id AND s.status = 'missed') AS missed,
            (SELECT COUNT(*) FROM assignments a WHERE a.tutee_id = u.id AND a.status = 'active') AS tutors,
            (SELECT COUNT(*) FROM availability av WHERE av.user_id = u.id AND av.state = 'available') AS slots,
            (SELECT GROUP_CONCAT(sb.name, ', ') FROM user_subjects us JOIN subjects sb ON sb.id = us.subject_id
              WHERE us.user_id = u.id AND us.kind = 'need') AS subjects
       FROM users u LEFT JOIN tutee_profiles ep ON ep.user_id = u.id
      WHERE u.role = 'tutee' ORDER BY total DESC, tutee_name`,
  );
  return {
    key: 'student_utilisation',
    title: 'Student session totals',
    columns: [
      { key: 'tutee_name', label: 'Tutee', width: 2.6 },
      { key: 'subjects', label: 'Subjects needed', width: 2.4 },
      { key: 'tutors', label: 'Tutors', width: 0.9 },
      { key: 'total', label: 'Sessions', width: 1 },
      { key: 'completed', label: 'Completed', width: 1.1 },
      { key: 'cancelled', label: 'Cancelled', width: 1.1 },
      { key: 'missed', label: 'Missed', width: 1 },
      { key: 'slots', label: 'Slots', width: 0.9 },
    ],
    rows,
    totals: { total: rows.reduce((s, r) => s + Number(r.total), 0) },
  };
}

function availabilityOverview() {
  const weekStart = weekStartISO();
  const people = all(
    `SELECT u.id, u.role, u.status, COALESCE(tp.full_name, ep.full_name, u.email) AS person_name
       FROM users u
       LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
       LEFT JOIN tutee_profiles ep ON ep.user_id = u.id
      WHERE u.role IN ('tutor','tutee') ORDER BY u.role, person_name`,
  );
  const rows = people.map((person) => {
    const rowsFor = listAvailability(person.id);
    let weeklyMinutes = 0;
    const daysCovered = new Set();
    for (let i = 0; i < 7; i += 1) {
      const date = addDaysISO(weekStart, i);
      const free = freeIntervalsForDate(rowsFor, date);
      const minutes = free.reduce((sum, iv) => sum + (iv.end - iv.start), 0);
      if (minutes > 0) daysCovered.add(i + 1);
      weeklyMinutes += minutes;
    }
    return {
      person_name: person.person_name,
      role: ROLE_LABELS[person.role] || person.role,
      status: person.status,
      slots: rowsFor.filter((r) => r.state === 'available').length,
      days: daysCovered.size,
      day_labels: WEEKDAYS.filter((d) => daysCovered.has(d.n)).map((d) => d.short).join(' '),
      weekly_hours: (weeklyMinutes / 60).toFixed(1),
    };
  });
  return {
    key: 'availability_overview',
    title: 'Availability overview',
    columns: [
      { key: 'person_name', label: 'Person', width: 3 },
      { key: 'role', label: 'Type', width: 1 },
      { key: 'status', label: 'Status', width: 1 },
      { key: 'slots', label: 'Availability rows', width: 1.3 },
      { key: 'day_labels', label: 'Days', width: 2 },
      { key: 'weekly_hours', label: 'Weekly hours', width: 1.2 },
    ],
    rows,
    totals: { people: rows.length, weekly_hours: rows.reduce((s, r) => s + Number(r.weekly_hours), 0).toFixed(1) },
  };
}

const BUILDERS = {
  sessions_per_week: sessionsPerWeek,
  sessions_per_tutor: sessionsPerTutor,
  sessions_per_student: sessionsPerStudent,
  sessions_per_subject: sessionsPerSubject,
  status_totals: statusTotals,
  tutor_workload: tutorWorkload,
  student_utilisation: studentUtilisation,
  availability_overview: availabilityOverview,
};

export function buildReport(key, { from, to } = {}) {
  const builder = BUILDERS[key] || sessionsPerWeek;
  const safeFrom = /^\d{4}-\d{2}-\d{2}$/.test(String(from)) ? from : addDaysISO(todayISO(), -28);
  const safeTo = /^\d{4}-\d{2}-\d{2}$/.test(String(to)) ? to : todayISO();
  const report = builder(safeFrom, safeTo);
  return {
    ...report,
    from: safeFrom,
    to: safeTo,
    meta: [`Period: ${fmtDate(safeFrom)} to ${fmtDate(safeTo)}`, `Generated: ${new Date().toISOString().slice(0, 16).replace('T', ' ')}`],
    totals: report.totals || {},
  };
}

export function reportToCSV(report) {
  return toCSV(
    report.columns.map((c) => c.label),
    report.rows.map((row) => report.columns.map((c) => row[c.key])),
  );
}

export function reportToPDF(report) {
  return buildPDF({
    title: report.title,
    subtitle: `Period ${fmtDate(report.from)} – ${fmtDate(report.to)}`,
    meta: [
      `Rows: ${report.rows.length}`,
      ...Object.entries(report.totals || {}).map(([k, v]) => `${k.replace(/_/g, ' ')}: ${v}`),
    ],
    columns: report.columns.map((c) => ({ label: c.label, width: c.width || 1 })),
    rows: report.rows.map((row) => report.columns.map((c) => row[c.key])),
  });
}

/** Compact per-week agenda used on the admin timetable page. */
export function weekAgenda(from, to) {
  const rows = sessionRows(from, to);
  const byDay = groupBy(rows, (r) => r.date);
  return [...byDay.entries()].map(([date, items]) => ({
    date,
    label: fmtDate(date, 'day'),
    sessions: items.map((s) => ({
      ...s,
      timeLabel: `${fmtTime(s.start_min)} – ${fmtTime(s.end_min)}`,
      durationLabel: durationLabel(s.end_min - s.start_min),
      startHHMM: minutesToHHMM(s.start_min),
      endHHMM: minutesToHHMM(s.end_min),
    })),
  }));
}

export { weekdayName, rangeWhere };
