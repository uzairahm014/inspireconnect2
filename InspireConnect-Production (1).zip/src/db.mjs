/**
 * Database layer — SQLite via Node's built-in `node:sqlite` (no native deps).
 *
 * All access goes through parameterised prepared statements (see `get`, `all`,
 * `run`) so SQL injection is not possible. Schema is created/upgraded on boot.
 */
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { config, DEFAULT_SETTINGS, ROLES, ACCOUNT_STATUS, AVAILABILITY_KIND, AVAILABILITY_STATE, SESSION_STATUS, INVITATION_STATUS } from './config.mjs';
import { nowSQL, slugify, sha256 } from './util.mjs';

fs.mkdirSync(path.dirname(config.databasePath), { recursive: true });
fs.mkdirSync(config.uploadsDir, { recursive: true });

export const db = new DatabaseSync(config.databasePath);

db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA busy_timeout = 5000;');

/* -------------------------------------------------------------------------- */
/* Schema                                                                     */
/* -------------------------------------------------------------------------- */

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  role                   TEXT    NOT NULL,
  username               TEXT    UNIQUE,
  email                  TEXT    NOT NULL UNIQUE,
  password_hash          TEXT,
  status                 TEXT    NOT NULL DEFAULT 'active',
  must_change_password   INTEGER NOT NULL DEFAULT 0,
  failed_attempts        INTEGER NOT NULL DEFAULT 0,
  locked_until           TEXT,
  last_login_at          TEXT,
  password_changed_at    TEXT,
  created_at             TEXT    NOT NULL,
  updated_at             TEXT    NOT NULL,
  created_by             INTEGER REFERENCES users(id) ON DELETE SET NULL,
  invitation_id          INTEGER,
  disabled_at            TEXT,
  disabled_reason        TEXT
);

CREATE TABLE IF NOT EXISTS tutor_profiles (
  user_id                 INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name               TEXT NOT NULL,
  preferred_name          TEXT,
  phone                   TEXT,
  photo                   TEXT,
  qualifications          TEXT,
  experience              TEXT,
  notes                   TEXT,
  max_students            INTEGER NOT NULL DEFAULT 12,
  session_frequency       TEXT,
  preferred_session_times TEXT,
  updated_at              TEXT
);

CREATE TABLE IF NOT EXISTS tutee_profiles (
  user_id                 INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name               TEXT NOT NULL,
  preferred_name          TEXT,
  phone                   TEXT,
  photo                   TEXT,
  year_level              TEXT,
  guardian_name           TEXT,
  guardian_contact        TEXT,
  notes                   TEXT,
  sessions_per_week       INTEGER NOT NULL DEFAULT 1,
  preferred_session_times TEXT,
  updated_at              TEXT
);

CREATE TABLE IF NOT EXISTS subjects (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  slug        TEXT    NOT NULL UNIQUE,
  colour      TEXT    NOT NULL DEFAULT '#2563eb',
  description TEXT,
  active      INTEGER NOT NULL DEFAULT 1,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS user_subjects (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id  INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  kind        TEXT    NOT NULL,            -- 'teach' | 'need'
  level       TEXT,
  created_at  TEXT    NOT NULL,
  UNIQUE(user_id, subject_id, kind)
);

CREATE TABLE IF NOT EXISTS availability (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind           TEXT    NOT NULL DEFAULT 'weekly',   -- 'weekly' | 'date'
  weekday        INTEGER,                              -- 1..7 for weekly slots
  date           TEXT,                                 -- YYYY-MM-DD for date-specific slots
  start_min      INTEGER NOT NULL,
  end_min        INTEGER NOT NULL,
  state          TEXT    NOT NULL DEFAULT 'available',
  effective_from TEXT,
  effective_to   TEXT,
  note           TEXT,
  created_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at     TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS assignments (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  tutor_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tutee_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id  INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  status      TEXT    NOT NULL DEFAULT 'active',   -- 'active' | 'ended'
  started_at  TEXT    NOT NULL,
  ended_at    TEXT,
  end_reason  TEXT,
  notes       TEXT,
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  tutor_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tutee_id            INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_id          INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
  date                TEXT    NOT NULL,
  start_min           INTEGER NOT NULL,
  end_min             INTEGER NOT NULL,
  mode                TEXT    NOT NULL DEFAULT 'in_person',
  location            TEXT,
  meeting_link        TEXT,
  notes               TEXT,
  status              TEXT    NOT NULL DEFAULT 'scheduled',
  series_id           TEXT,
  rescheduled_from_id INTEGER REFERENCES sessions(id) ON DELETE SET NULL,
  cancel_reason       TEXT,
  created_by          INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at          TEXT    NOT NULL,
  updated_at          TEXT,
  completed_at        TEXT
);

CREATE TABLE IF NOT EXISTS session_status_history (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id   INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  from_status  TEXT,
  to_status    TEXT    NOT NULL,
  note         TEXT,
  actor_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_label  TEXT,
  created_at   TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS session_notes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  author_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  category   TEXT NOT NULL DEFAULT 'general',
  visibility TEXT NOT NULL DEFAULT 'all',
  body       TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS invitations (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash    TEXT    NOT NULL UNIQUE,
  role          TEXT    NOT NULL,             -- 'tutor' | 'tutee'
  email         TEXT    NOT NULL,
  full_name     TEXT,
  subject_ids   TEXT,                          -- optional pre-selected subjects (JSON array)
  note          TEXT,
  expires_at    TEXT    NOT NULL,
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TEXT    NOT NULL,
  used_at       TEXT,
  used_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
  revoked_at    TEXT,
  revoked_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  revoke_reason TEXT,
  send_count    INTEGER NOT NULL DEFAULT 0,
  last_sent_at  TEXT
);

CREATE TABLE IF NOT EXISTS password_resets (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT    NOT NULL UNIQUE,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT    NOT NULL,
  expires_at TEXT    NOT NULL,
  used_at    TEXT
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   TEXT    NOT NULL UNIQUE,
  csrf_token   TEXT    NOT NULL,
  ip           TEXT,
  user_agent   TEXT,
  created_at   TEXT    NOT NULL,
  last_seen_at TEXT    NOT NULL,
  expires_at   TEXT    NOT NULL,
  revoked_at   TEXT
);

CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type       TEXT    NOT NULL,
  title      TEXT    NOT NULL,
  body       TEXT,
  link       TEXT,
  level      TEXT    NOT NULL DEFAULT 'info',
  read_at    TEXT,
  created_at TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_label TEXT,
  actor_role  TEXT,
  action      TEXT NOT NULL,
  entity_type TEXT,
  entity_id   INTEGER,
  summary     TEXT,
  details     TEXT,
  ip          TEXT,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS email_outbox (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  to_email   TEXT NOT NULL,
  subject    TEXT NOT NULL,
  body       TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'queued',
  error      TEXT,
  meta       TEXT,
  created_at TEXT NOT NULL,
  sent_at    TEXT
);

CREATE TABLE IF NOT EXISTS login_attempts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  identifier TEXT NOT NULL,
  ip         TEXT,
  success    INTEGER NOT NULL DEFAULT 0,
  reason     TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_preferences (
  user_id    INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  theme      TEXT NOT NULL DEFAULT 'system',
  email_digest INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_user_subjects_user ON user_subjects(user_id, kind);
CREATE INDEX IF NOT EXISTS idx_availability_user ON availability(user_id, kind, weekday);
CREATE INDEX IF NOT EXISTS idx_sessions_date ON sessions(date);
CREATE INDEX IF NOT EXISTS idx_sessions_tutor ON sessions(tutor_id, date);
CREATE INDEX IF NOT EXISTS idx_sessions_tutee ON sessions(tutee_id, date);
CREATE INDEX IF NOT EXISTS idx_sessions_status ON sessions(status);
CREATE INDEX IF NOT EXISTS idx_assignments_tutor ON assignments(tutor_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_tutee ON assignments(tutee_id, status);
CREATE INDEX IF NOT EXISTS idx_invitations_status ON invitations(revoked_at, used_at);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read_at);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_login_attempts_identifier ON login_attempts(identifier, created_at);
CREATE INDEX IF NOT EXISTS idx_password_resets_user ON password_resets(user_id);
`;

db.exec(SCHEMA);

/* -------------------------------------------------------------------------- */
/* Query helpers                                                              */
/* -------------------------------------------------------------------------- */

const cache = new Map();

function prepare(sql) {
  let stmt = cache.get(sql);
  if (!stmt) {
    stmt = db.prepare(sql);
    cache.set(sql, stmt);
  }
  return stmt;
}

function toParam(value) {
  if (value === undefined || value === null) return null;
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (value instanceof Date) return nowSQL(value);
  if (typeof value === 'number' || typeof value === 'string' || typeof value === 'bigint') return value;
  return JSON.stringify(value);
}

export function get(sql, params = []) {
  return prepare(sql).get(...params.map(toParam));
}

export function all(sql, params = []) {
  return prepare(sql).all(...params.map(toParam));
}

export function run(sql, params = []) {
  return prepare(sql).run(...params.map(toParam));
}

export function pluck(sql, params = []) {
  const row = get(sql, params);
  return row ? Object.values(row)[0] : null;
}

/**
 * Run `fn` inside a transaction. Rolls back on throw. Nested calls join the
 * outer transaction instead of trying (and failing) to start a second one.
 */
let txDepth = 0;

export function tx(fn) {
  if (txDepth > 0) {
    txDepth += 1;
    try {
      return fn();
    } finally {
      txDepth -= 1;
    }
  }
  db.exec('BEGIN IMMEDIATE');
  txDepth = 1;
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    throw error;
  } finally {
    txDepth = 0;
  }
}

export const lastId = (result) => Number(result.lastInsertRowid);

export function tableCount(sql, params = []) {
  return Number(pluck(sql, params) || 0);
}

/* -------------------------------------------------------------------------- */
/* Settings                                                                   */
/* -------------------------------------------------------------------------- */

export function getSettings() {
  const rows = all('SELECT key, value FROM settings');
  const stored = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return { ...DEFAULT_SETTINGS, ...stored };
}

export function getSetting(key, fallback = null) {
  const row = get('SELECT value FROM settings WHERE key = ?', [key]);
  if (row) return row.value;
  return DEFAULT_SETTINGS[key] ?? fallback;
}

export function setSetting(key, value, actorId = null) {
  run(
    `INSERT INTO settings (key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at, updated_by = excluded.updated_by`,
    [key, String(value ?? ''), nowSQL(), actorId],
  );
}

export function settingInt(key, fallback = 0) {
  const n = Number.parseInt(getSetting(key, String(fallback)), 10);
  return Number.isFinite(n) ? n : fallback;
}

export function settingBool(key, fallback = false) {
  const raw = String(getSetting(key, fallback ? 'true' : 'false')).toLowerCase();
  return raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on';
}

/* -------------------------------------------------------------------------- */
/* Id helpers                                                                 */
/* -------------------------------------------------------------------------- */

export function uniqueSlug(table, name, column = 'slug') {
  const base = slugify(name) || 'item';
  let candidate = base;
  let i = 2;
  while (get(`SELECT id FROM ${table} WHERE ${column} = ?`, [candidate])) {
    candidate = `${base}-${i++}`;
  }
  return candidate;
}

export const hashToken = (token) => sha256(token);

/* -------------------------------------------------------------------------- */
/* Bootstrap: subjects, settings, initial super admin                         */
/* -------------------------------------------------------------------------- */

const INITIAL_SUBJECTS = [
  { name: 'English', colour: '#7c3aed', description: 'Reading, writing and comprehension' },
  { name: 'Maths', colour: '#2563eb', description: 'Numeracy, algebra and problem solving' },
  { name: 'Science', colour: '#0d9488', description: 'Biology, chemistry and physics' },
];

export function ensureSubjects() {
  for (const [i, subject] of INITIAL_SUBJECTS.entries()) {
    if (!get('SELECT id FROM subjects WHERE name = ? COLLATE NOCASE', [subject.name])) {
      run(
        'INSERT INTO subjects (name, slug, colour, description, active, sort_order, created_at) VALUES (?, ?, ?, ?, 1, ?, ?)',
        [subject.name, uniqueSlug('subjects', subject.name), subject.colour, subject.description, i, nowSQL()],
      );
    }
  }
}

export function ensureSettings() {
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    if (!get('SELECT key FROM settings WHERE key = ?', [key])) {
      run('INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)', [key, value, nowSQL()]);
    }
  }
  // Migrate the pre-launch product name so existing databases immediately use
  // the current brand without losing any administrator settings.
  const organisation = get('SELECT value FROM settings WHERE key = ?', ['organisation_name']);
  if (organisation && /^(tutorhub|inspirelink)$/i.test(String(organisation.value).trim())) {
    setSetting('organisation_name', 'InspireConnect');
  }
}

/**
 * Create the initial super administrator. The password comes from the
 * environment (ADMIN_PASSWORD, default "inspire") and is stored only as a
 * scrypt hash — it is never written to the UI, logs or the client bundle.
 */
export async function ensureInitialAdmin({ force = false } = {}) {
  const { username, password, email } = config.initialAdmin;
  const existing = get('SELECT id FROM users WHERE username = ?', [username]);
  if (existing && !force) return { created: false, id: existing.id };

  const { hashPassword } = await import('./auth.mjs');
  const hash = await hashPassword(password);
  if (existing) {
    run('UPDATE users SET password_hash = ?, must_change_password = 1, updated_at = ? WHERE id = ?', [hash, nowSQL(), existing.id]);
    return { created: false, id: existing.id, reset: true };
  }
  const result = run(
    `INSERT INTO users (role, username, email, password_hash, status, must_change_password, created_at, updated_at, password_changed_at)
     VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)`,
    [ROLES.SUPER_ADMIN, username, email, hash, ACCOUNT_STATUS.ACTIVE, nowSQL(), nowSQL(), nowSQL()],
  );
  return { created: true, id: lastId(result) };
}

export { ROLES, ACCOUNT_STATUS, AVAILABILITY_KIND, AVAILABILITY_STATE, SESSION_STATUS, INVITATION_STATUS };
