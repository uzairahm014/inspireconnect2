// Vercel serverless adapter.
// SQLite is placed in /tmp because Vercel's deployment filesystem is read-only.
// Configure a persistent external database before using this for production data.
process.env.DATA_DIR ||= '/tmp/inspireconnect-data';
process.env.DATABASE_PATH ||= '/tmp/inspireconnect-data/inspireconnect.db';

let application;
let loadError;

async function loadApplication() {
  if (!application && !loadError) {
    try {
      application = await import('../src/server.mjs');
    } catch (error) {
      loadError = error;
      console.error('[InspireConnect] startup failed:', error);
    }
  }
  if (loadError) throw loadError;
  return application;
}

export default async function handler(req, res) {
  try {
    const { handleRequest } = await loadApplication();
    await handleRequest(req, res);
  } catch (error) {
    console.error('[InspireConnect] function invocation failed:', error);
    if (res.headersSent) return;
    res.statusCode = 500;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.end('InspireConnect could not start. Check the Vercel function logs for the startup error.');
  }
}
