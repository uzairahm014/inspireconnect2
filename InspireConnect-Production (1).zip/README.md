# InspireConnect

A secure tutor & tutee management platform: tutor and tutee records, weekly
availability, subjects, a subject+availability matching engine, a session
timetable, weekly session tracking, reporting and full administration — with
invitation-only registration and role-based access control enforced on the
server.

Built on the Node.js standard library only (`node:http`, `node:sqlite`,
`node:crypto`). There is nothing to `npm install`, no build step, and data is
stored in a real SQLite database file that survives restarts.

---

## Requirements

- **Node.js 22.5 or newer** (uses the built-in `node:sqlite` module). Node 24 is
  recommended.
- No other dependencies.

```bash
node --version   # must be >= 22.5
```

## Quick start

```bash
cp .env.example .env     # optional — every value has a safe default
npm run seed             # subjects, settings and the initial administrator
npm start                # http://127.0.0.1:4600
```

Then sign in at `/login` with the initial administrator account:

| Username | Password  |
| -------- | --------- |
| `admin`  | `inspire` |

The initial password is **single-use in practice**: the account is flagged
`must_change_password`, so the dashboard stays closed until a new password is
chosen. Nothing about the password is rendered anywhere in the UI.

To explore a populated instance instead:

```bash
npm run demo             # adds 3 tutors, 4 tutees, availability and sessions
```

Demo tutor/tutee accounts share the `DEMO_PASSWORD` value (default
`InspireDemo2026!`) shown in the seed output.

## Scripts

| Script              | What it does                                                        |
| ------------------- | ------------------------------------------------------------------- |
| `npm start`         | Run the server                                                      |
| `npm run dev`       | Run with `--watch` (restart on file change)                         |
| `npm run seed`      | Create subjects, settings and the initial administrator             |
| `npm run demo`      | Seed realistic demo tutors, tutees, availability and sessions       |
| `npm run reset`     | Delete the database file so the schema is rebuilt on next start     |
| `npm test`          | Unit tests + end-to-end HTTP tests (real server, real database)      |
| `npm run backup`    | Consistent SQLite snapshot into `data/backups/` (keeps the newest 30)|

## Configuration

All settings are environment variables (see `.env.example`). Highlights:

| Variable                    | Default              | Notes                                                        |
| --------------------------- | -------------------- | ------------------------------------------------------------ |
| `PORT` / `HOST`             | `4600` / `127.0.0.1` | `PORT=0` picks any free port and the banner prints it         |
| `APP_BASE_URL`              | *(empty)*            | Set in production so invitation and reset links are absolute  |
| `DATABASE_PATH`             | `data/inspireconnect.db`| SQLite file, created automatically                            |
| `SESSION_SECRET`            | auto-generated       | Persisted to `data/.session-secret` if unset                  |
| `COOKIE_SECURE`             | `false`              | Set `true` when serving over HTTPS                            |
| `TRUST_PROXY`               | `false`              | Set `true` behind a reverse proxy                             |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD` | `admin` / `inspire` | Seeded once, then replaced in-app                    |
| `MIN_PASSWORD_LENGTH`       | `10`                 | Also editable in **Settings**                                 |
| `INVITATION_EXPIRY_HOURS`   | `72`                 | Also editable in **Settings**                                 |
| `EMAIL_TRANSPORT`           | `log`                | `log` uses the in-app outbox; set `smtp` for real delivery    |

### Deploying

1. Set `NODE_ENV=production`, `APP_BASE_URL=https://your-domain`,
   `COOKIE_SECURE=true` and a strong `ADMIN_PASSWORD`.
2. Put a TLS-terminating reverse proxy in front and set `TRUST_PROXY=true` so
   client IPs (used for login rate limiting) are read correctly.
3. Keep `data/` on persistent storage and schedule `npm run backup`.
4. Change the seeded administrator password at first sign-in, then create the
   rest of the administrator accounts in **Administrators**.

### Vercel deployment

The repository includes `api/index.mjs` and `vercel.json` so Vercel can route
browser, asset and favicon requests through the application. Set these Vercel
environment variables before deploying: `NODE_ENV=production`,
`APP_BASE_URL=https://your-project.vercel.app`, `ADMIN_PASSWORD`,
`SESSION_SECRET`, and `COOKIE_SECURE=true`.

Important: Vercel functions have ephemeral local storage. The included adapter
uses `/tmp` only to prevent 500 errors during a fresh deployment; it is suitable
for a live preview, not durable production records. For real production use,
connect the persistence layer to a managed database/storage service before
accepting real tutor or student data.

## How it works

### Registration is invitation-only

There is no public sign-up route. An administrator creates an invitation
(**Invitations → Create**), which produces a single-use link:

- the token is 256 bits of CSPRNG output, delivered once and stored **only** as
  a SHA-256 hash;
- it has an expiry, can be revoked, and is consumed on first successful
  registration;
- visiting it reports precisely why it failed — invalid, expired, revoked or
  already used — and the attempt is written to the audit log.

The invitee completes their own profile, picks subjects and (optionally) enters
availability, then sets their own password. Passwords are hashed with scrypt
(N=32768, r=8, p=1) with a per-account salt.

### Availability drives everything

Tutors and tutees each record recurring weekly availability (multiple periods
per day, all seven days), plus date-specific overrides for one-off changes.
Availability is stored as minute ranges, so it can be intersected exactly:

- **Matching** compares a tutee's required subjects against tutor subjects
  *and* intersects their availability to produce concrete candidate windows,
  ranked with workload, capacity, existing bookings and match status
  (Available / Partially available / Busy / No matching availability /
  Already assigned).
- **Conflict detection** refuses sessions that double-book a tutor or a tutee,
  that fall outside availability, or that end before they start. Conflicts are
  shown before saving, with the clashing session quoted back.

### Sessions and history

Sessions carry a status throughout their life (scheduled, confirmed, running,
completed, cancelled, missed, rescheduled) with a guarded transition map, a
status history, categorised notes with per-note visibility, and rescheduling
that keeps the original record linked to its replacement. Nothing is deleted,
so weekly tracking and reports stay accurate.

## Project structure

```
src/
  config.mjs        Configuration, roles, permissions, session statuses
  db.mjs            Schema, migrations, seed helpers, settings store
  auth.mjs          Password hashing, sessions, CSRF, RBAC, audit log
  http.mjs          Router, cookies, body parsing, flash, security headers
  people.mjs        Tutors, tutees, subjects, availability queries
  sessions.mjs      Sessions, conflicts, notes, assignments, weekly stats
  matching.mjs      Subject + availability matching engine
  invitations.mjs   Invitation lifecycle and token handling
  notify.mjs        In-app notifications (email-ready)
  reports.mjs       Reports with CSV and PDF export
  resets.mjs        Single-use password reset links
  mail.mjs          Pluggable transport (log or SMTP)
  server.mjs        Wiring, middleware, request lifecycle
  seed.mjs          Bootstrap and demo data
  backup.mjs        SQLite snapshot utility
  routes/           public (auth) · admin · portal (tutor + tutee)
  views/            Server-rendered HTML templates and partials
public/             Stylesheet, client-side JavaScript, favicon
tests/              Unit tests and end-to-end HTTP tests
data/               SQLite database, uploads, secret, backups (gitignored)
```

## Security model

- **Authorisation is server-side.** Every admin route calls `ensureCan()` and
  the request pipeline applies route-prefix guards, so hiding a button is never
  the only protection. Roles: Super Admin, Admin, Scheduler, Viewer, Tutor,
  Tutee — each with an explicit permission set.
- **Sessions** are opaque random tokens stored server-side with an expiry and a
  revocation flag; disabling an account revokes its sessions immediately.
  Cookies are `HttpOnly`, `SameSite=Lax`, and `Secure` when configured.
- **CSRF** uses a signed double-submit token on every state-changing form;
  an unverifiable token is replaced rather than locking the user out.
- **Login protection**: per-account lockout plus per-IP rate limiting, with an
  equalised response time for unknown accounts (no user enumeration).
- **Headers**: strict `Content-Security-Policy` with no inline scripts, plus
  `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff` and a strict
  referrer policy.
- **Input handling** is validated server-side on every form, and all SQL uses
  bound parameters.
- **Audit log** records sign-ins, failures, record changes, session changes,
  invitation activity, administrator changes and account status changes
  (CSV exportable).

## Testing

```bash
npm test
```

52 tests: date/time and validation units, the availability interval engine,
password hashing, the RBAC matrix, PDF/CSV writers, and an end-to-end suite that
boots the real server against a throwaway database and drives registration,
matching, scheduling, conflicts, rescheduling, notes, reports, exports and the
security controls over real HTTP.
